// Misst echte öffentliche Produktseiten mit dem Wettkiesel-Extraktor.
// Aufruf: npx tsx scripts/measure-examples.ts <urls.json> <out.json>
import { readFileSync, writeFileSync } from 'node:fs';
import { extractStructuredProductData } from '../src/lib/business/html-extraction';

type Item = {
  product: string;
  shop: string;
  url: string;
  variantGtin?: string;
  variantName?: string;
};

// Seiten mit mehreren Varianten (z. B. Farbe/Größe) liefern pro Variante ein eigenes
// JSON-LD-Product mit GTIN. Ist variantGtin gesetzt, wird genau diese Variante gelesen.
function readVariant(html: string, gtin: string) {
  const norm = (g: unknown) => String(g ?? '').replace(/^0+/, '');
  const found: Array<Record<string, any>> = [];
  const walk = (x: any) => {
    if (Array.isArray(x)) return x.forEach(walk);
    if (x && typeof x === 'object') {
      if (x['@type'] === 'Product' && norm(x.gtin13 ?? x.gtin ?? x.gtin14) === norm(gtin))
        found.push(x);
      Object.values(x).forEach(walk);
    }
  };
  for (const m of html.matchAll(/<script[^>]*application\/ld\+json[^>]*>([\s\S]*?)<\/script>/gi)) {
    try {
      walk(JSON.parse(m[1] as string));
    } catch {
      /* ignore */
    }
  }
  const offer = found
    .map((p) => (Array.isArray(p.offers) ? p.offers[0] : p.offers))
    .find((o) => o && o.price != null);
  if (!offer) return null;
  return {
    price: String(offer.price),
    currency: offer.priceCurrency ?? null,
    availability:
      String(offer.availability ?? '')
        .split('/')
        .pop() || null,
  };
}
const UA = 'Mozilla/5.0 (compatible; WettkieselBot/1.0; +https://wettkiesel.onrender.com)';

(async () => {
  const [, , input, output] = process.argv;
  const items: Item[] = JSON.parse(readFileSync(input as string, 'utf8'));
  const results = [];
  for (const it of items) {
    const measuredAt = new Date().toISOString();
    try {
      const res = await fetch(it.url, {
        headers: { 'user-agent': UA, 'accept-language': 'de-DE' },
        signal: AbortSignal.timeout(25000),
      });
      const html = await res.text();
      if (it.variantGtin) {
        const v = readVariant(html, it.variantGtin);
        results.push({
          ...it,
          measuredAt,
          httpStatus: res.status,
          price: v?.price ?? null,
          currency: v?.currency ?? null,
          priceSource: v ? 'json-ld' : null,
          availability: v?.availability ?? null,
          priceConflict: false,
          availabilityConflict: false,
        });
        console.log(JSON.stringify(results.at(-1)));
        continue;
      }
      const x = extractStructuredProductData(html);
      results.push({
        ...it,
        measuredAt,
        httpStatus: res.status,
        price: x.price?.value ?? null,
        currency: x.price?.currency ?? null,
        priceSource: x.price?.source ?? null,
        availability: x.availability?.availability ?? null,
        priceConflict: x.priceConflict,
        availabilityConflict: x.availabilityConflict,
      });
    } catch (e) {
      results.push({ ...it, measuredAt, httpStatus: null, error: String((e as Error).name) });
    }
    console.log(JSON.stringify(results.at(-1)));
  }
  writeFileSync(output as string, JSON.stringify(results, null, 2));
})();
