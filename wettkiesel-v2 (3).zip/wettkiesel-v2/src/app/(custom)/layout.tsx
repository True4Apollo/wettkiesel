import { LpFooter, LpHeader } from '@/components/custom/lp-chrome';

export default function PublicLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="lp lp-page">
      <LpHeader />
      <div className="lp-page-body">{children}</div>
      <LpFooter />
    </div>
  );
}
