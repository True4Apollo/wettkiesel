import { Check } from 'lucide-react';
import Link from 'next/link';
import { checkoutHref, isTierKey } from '@/lib/payments';
import {
  founderDiscount,
  pilotOffer,
  pricingIsProposal,
  pricingTiers,
} from '@/lib/wettkiesel-config';

export function PricingSection() {
  return (
    <section className="lp-section" id="preise" aria-labelledby="preise-title">
      <div className="lp-container">
        <div className="lp-heading lp-heading-center">
          <p className="lp-eyebrow">Preise</p>
          <h2 id="preise-title">Weniger als eine Stunde Handrecherche im Monat.</h2>
          <p>{pilotOffer} Monatlich kündbar.</p>
        </div>
        <div className="lp-pricing">
          {pricingTiers.map((tier) => {
            const highlighted = 'highlighted' in tier && tier.highlighted;
            const key = tier.name.toLowerCase();
            const buy = isTierKey(key) ? checkoutHref(key) : null;
            return (
              <article key={tier.name} className={`lp-price${highlighted ? ' lp-price-hl' : ''}`}>
                {highlighted ? <span className="lp-price-flag">Beliebt</span> : null}
                <h3>{tier.name}</h3>
                <p className="lp-muted">{tier.tagline}</p>
                <p className="lp-price-amount">
                  {tier.priceEur} €<small>/Monat</small>
                </p>
                <ul className="lp-checks">
                  {tier.features.map((f) => (
                    <li key={f}>
                      <Check size={16} aria-hidden="true" /> {f}
                    </li>
                  ))}
                </ul>
                <Link
                  href={`/pilot?tarif=${tier.name.toLowerCase()}`}
                  className={`lp-btn ${highlighted ? 'lp-btn-primary' : 'lp-btn-ghost'}`}
                >
                  14 Tage kostenlos testen
                </Link>
                {buy ? (
                  <a href={buy} className="lp-link-strong lp-buy" rel="nofollow">
                    Oder direkt buchen
                  </a>
                ) : null}
              </article>
            );
          })}
        </div>
        <div className="lp-price-notes">
          {founderDiscount.enabled ? <p>★ {founderDiscount.text}</p> : null}
          {pricingIsProposal ? (
            <p>Preise in der Pilotphase, Änderungen vorbehalten. Alle Preise zzgl. ggf. USt.</p>
          ) : null}
        </div>
      </div>
    </section>
  );
}
