// Produkt-Mockup des Tagesberichts für die Startseite (illustrativ, klar als Beispiel markiert).
const rows = [
  {
    name: 'Espressomühle Modell A',
    shop: 'Wettbewerber 1',
    price: '229,00 €',
    delta: '−8 %',
    tone: 'down',
    stock: 'Auf Lager',
  },
  {
    name: 'Milchkännchen 350 ml',
    shop: 'Wettbewerber 2',
    price: '19,90 €',
    delta: '±0',
    tone: 'flat',
    stock: 'Ausverkauft',
  },
  {
    name: 'Tamper 58 mm',
    shop: 'Wettbewerber 3',
    price: '34,90 €',
    delta: '+5 %',
    tone: 'up',
    stock: 'Auf Lager',
  },
] as const;

export function ReportMockup() {
  return (
    <figure className="lp-mock" aria-label="Beispielhafte Vorschau eines Wettkiesel-Tagesberichts">
      <div className="lp-mock-bar" aria-hidden="true">
        <span />
        <span />
        <span />
        <em>Tagesbericht · 07:00 Uhr</em>
      </div>
      <div className="lp-mock-body">
        <div className="lp-mock-head">
          <div>
            <p className="lp-mock-kicker">Dein Markt heute</p>
            <p className="lp-mock-title">3 Änderungen bei deinen Wettbewerbern</p>
          </div>
          <span className="lp-badge">Beispiel</span>
        </div>
        <div className="lp-mock-stats">
          <div>
            <strong>1</strong>
            <span>Preissenkung</span>
          </div>
          <div>
            <strong>1</strong>
            <span>neu ausverkauft</span>
          </div>
          <div>
            <strong>1</strong>
            <span>Preiserhöhung</span>
          </div>
        </div>
        <ul className="lp-mock-rows">
          {rows.map((r) => (
            <li key={r.name}>
              <span className={`lp-dot lp-dot-${r.tone}`} aria-hidden="true" />
              <span className="lp-mock-name">
                {r.name}
                <small>{r.shop}</small>
              </span>
              <span className="lp-mock-price">
                {r.price}
                <small className={`lp-delta lp-delta-${r.tone}`}>{r.delta}</small>
              </span>
              <span className={`lp-stock${r.stock === 'Ausverkauft' ? ' lp-stock-out' : ''}`}>
                {r.stock}
              </span>
            </li>
          ))}
        </ul>
        <div className="lp-mock-hint">
          <strong>Vorschlag:</strong> Modell A auf 229,00 € – innerhalb deiner Untergrenze (225,00
          €). Du entscheidest.
        </div>
      </div>
      <figcaption className="lp-mock-caption">Illustration mit Beispieldaten</figcaption>
    </figure>
  );
}
