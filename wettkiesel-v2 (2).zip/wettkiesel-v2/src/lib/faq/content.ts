// @polsia:user-owned — FAQ content AND its shape. Edit the questions/answers and
// the CTA below. You may also EXTEND these types (e.g. add a `category` field) to
// support a richer layout — the sealed <FaqJsonLd> only reads `question` +
// `answer`, so extending FaqItem is safe. This is your content file.

export interface FaqItem {
  /** Stable identifier used by the accordion. */
  id: string;
  /** Shown in the accordion AND emitted as the JSON-LD Question name. */
  question: string;
  /** Shown in the accordion AND emitted as the JSON-LD Answer text. Plain text. */
  answer: string;
}

/** Call-to-action under the FAQ. Set the content's `cta` to null to hide it. */
export interface FaqCta {
  label: string;
  href: string;
}

export interface FaqContent {
  /** Optional intro paragraph under the H1. */
  intro?: string;
  /** The question/answer pairs — rendered in the accordion AND as FAQPage JSON-LD. */
  items: FaqItem[];
  /** The CTA under the list, or `null` for a CTA-free FAQ page. */
  cta: FaqCta | null;
}

const faqItems: FaqItem[] = [
  {
    id: 'was',
    question: 'Was beobachtet Wettkiesel genau?',
    answer:
      'Öffentlich sichtbare Preise und Verfügbarkeiten auf den Produktseiten deiner Wettbewerber. Wir lesen dafür die strukturierten Produktdaten (JSON-LD, Microdata), die Shops ohnehin für Google bereitstellen. Jede Messung wird mit Zeitpunkt und Quelle gespeichert.',
  },
  {
    id: 'nutzen',
    question: 'Lohnt sich das für einen kleinen Shop?',
    answer:
      'Wenn du vergleichbare Markenware verkaufst: oft ja. In unserem echten Beispielbericht kostete dieselbe Handmühle je nach Shop zwischen 204,99 € und 229,00 €. Ob sich das für dich rechnet, siehst du im kostenlosen 14-Tage-Test mit deinen eigenen Produkten.',
  },
  {
    id: 'automatisch',
    question: 'Ändert Wettkiesel automatisch Preise in meinem Shop?',
    answer:
      'Nein. Heute bekommst du Hinweise und unverbindliche Vorschläge innerhalb deiner Preisgrenzen – entscheiden und ändern tust du. Automatische Anpassung ist geplant und kommt zuerst für Pilotpartner.',
  },
  {
    id: 'zugang',
    question: 'Brauche ich Zugangsdaten oder eine Integration?',
    answer:
      'Nein. Für die Beobachtung reichen öffentliche Produktseiten. Bitte teile keine Passwörter oder API-Schlüssel.',
  },
  {
    id: 'nicht-lesbar',
    question: 'Was, wenn eine Wettbewerberseite nicht ausgelesen werden kann?',
    answer:
      'Dann steht das im Bericht als „keine Messung“ – nicht als „unverändert“. Manche Seiten laden Preise erst per JavaScript oder blockieren Bots; das sagen wir dir bei der Einrichtung ehrlich.',
  },
  {
    id: 'rechtlich',
    question: 'Ist das erlaubt?',
    answer:
      'Wettkiesel ruft nur öffentlich zugängliche Seiten in geringer Frequenz (einmal täglich) ab und speichert keine personenbezogenen Daten. Ob das für deinen Anwendungsfall passt, solltest du im Zweifel rechtlich prüfen lassen.',
  },
  {
    id: 'kosten',
    question: 'Was kostet Wettkiesel?',
    answer:
      'Ab 29 € im Monat, monatlich kündbar. Der 14-Tage-Test ist kostenlos und endet automatisch – ohne Abo-Falle.',
  },
  {
    id: 'unterschied',
    question: 'Warum nicht Prisync, Price2Spy & Co.?',
    answer:
      'Die sind gute Werkzeuge – meist englischsprachig, zum Selbereinrichten und eher für größere Kataloge. Wettkiesel ist für kleine deutsche Shops gedacht: persönliche Einrichtung, deutscher Tagesbericht, ein Ansprechpartner.',
  },
];

export const faqContent: FaqContent = {
  intro: 'Kurz und ehrlich: was Wettkiesel heute kann, was nicht, und was es kostet.',
  items: faqItems,
  cta: { label: '14 Tage kostenlos testen', href: '/pilot' },
};
