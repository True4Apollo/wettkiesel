// Bezahlung über Stripe – vollständig optional.
// Variante A (Checkout): STRIPE_SECRET_KEY + STRIPE_PRICE_START / _SHOP / _PRO (Preis-IDs eines Abos).
// Variante B (Payment Links): STRIPE_LINK_START / _SHOP / _PRO (https://buy.stripe.com/...).
// Ist nichts gesetzt, wird kein Bezahl-Button angezeigt.
export type TierKey = 'start' | 'shop' | 'pro';
export const TIER_KEYS: TierKey[] = ['start', 'shop', 'pro'];

const envName = (prefix: string, tier: TierKey) => `${prefix}_${tier.toUpperCase()}`;

export function stripePriceId(tier: TierKey): string | null {
  if (!process.env.STRIPE_SECRET_KEY) return null;
  return process.env[envName('STRIPE_PRICE', tier)] || null;
}

export function paymentLink(tier: TierKey): string | null {
  const link = process.env[envName('STRIPE_LINK', tier)];
  return link && /^https:\/\/(buy\.stripe\.com|checkout\.stripe\.com)\//.test(link) ? link : null;
}

/** URL für den „Jetzt buchen“-Button oder null, wenn Bezahlung nicht konfiguriert ist. */
export function checkoutHref(tier: TierKey): string | null {
  if (stripePriceId(tier)) return `/api/checkout?tarif=${tier}`;
  return paymentLink(tier);
}

export function isTierKey(value: unknown): value is TierKey {
  return typeof value === 'string' && (TIER_KEYS as string[]).includes(value);
}
