// Eigener Seitenabruf (ersetzt den Polsia-Fetch-Proxy).
import 'server-only';
import { assertPublicHttpTarget } from '@/lib/business/public-http-target';

export const PAGE_FETCH_USER_AGENT =
  process.env.PAGE_FETCH_USER_AGENT ??
  'Mozilla/5.0 (compatible; WettkieselBot/1.0; +https://wettkiesel.de/bot)';
export const PAGE_FETCH_MAX_BYTES = 3 * 1024 * 1024;
const MAX_REDIRECTS = 5;

export class PageFetchError extends Error {
  constructor(
    public readonly code:
      | 'http_error'
      | 'not_html'
      | 'too_large'
      | 'too_many_redirects'
      | 'network',
    message: string,
    public readonly status?: number,
  ) {
    super(message);
    this.name = 'PageFetchError';
  }
}

export interface FetchedPage {
  url: string;
  html: string;
  status: number;
  fetchedAt: string;
  truncated: boolean;
}

async function readLimited(res: Response, limit: number) {
  const reader = res.body?.getReader();
  if (!reader) return { text: '', truncated: false };
  const chunks: Uint8Array[] = [];
  let total = 0;
  let truncated = false;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > limit) {
      truncated = true;
      await reader.cancel();
      break;
    }
    chunks.push(value);
  }
  return { text: Buffer.concat(chunks).toString('utf8'), truncated };
}

export async function fetchProductPage(
  url: string,
  options: { signal?: AbortSignal; timeoutMs?: number } = {},
): Promise<FetchedPage> {
  const signal = AbortSignal.any(
    [AbortSignal.timeout(options.timeoutMs ?? 20_000), options.signal].filter(
      (s): s is AbortSignal => Boolean(s),
    ),
  );
  let current = url;
  for (let hop = 0; hop <= MAX_REDIRECTS; hop += 1) {
    await assertPublicHttpTarget(current);
    let res: Response;
    try {
      res = await fetch(current, {
        redirect: 'manual',
        signal,
        cache: 'no-store',
        headers: {
          'user-agent': PAGE_FETCH_USER_AGENT,
          accept: 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.5',
          'accept-language': 'de-DE,de;q=0.9,en;q=0.6',
        },
      });
    } catch (error) {
      if (signal.aborted) throw error;
      throw new PageFetchError('network', 'Netzwerkfehler beim Seitenabruf.');
    }
    if (res.status >= 300 && res.status < 400) {
      const location = res.headers.get('location');
      if (!location) throw new PageFetchError('http_error', 'Weiterleitung ohne Ziel.', res.status);
      current = new URL(location, current).toString();
      continue;
    }
    if (!res.ok) throw new PageFetchError('http_error', `HTTP ${res.status}`, res.status);
    const type = res.headers.get('content-type') ?? '';
    if (type && !/html|xml/i.test(type)) {
      throw new PageFetchError('not_html', `Kein HTML (${type}).`, res.status);
    }
    const { text, truncated } = await readLimited(res, PAGE_FETCH_MAX_BYTES);
    return {
      url: current,
      html: text,
      status: res.status,
      fetchedAt: new Date().toISOString(),
      truncated,
    };
  }
  throw new PageFetchError('too_many_redirects', 'Zu viele Weiterleitungen.');
}
