// Deterministische Auswertung von Produktseiten-HTML ohne KI.
// Reihenfolge: JSON-LD (Product/Offer) → Microdata (itemprop) → OpenGraph/Meta.
// Gibt nur Werte zurück, die explizit im HTML stehen; erfindet nichts.
import {
  type CompetitorAvailabilityStatus as AvailabilityStatus,
  CompetitorAvailabilityStatus,
} from '@/lib/contracts/competitor-checks';

export type StructuredSource = 'json-ld' | 'microdata' | 'meta';

export interface StructuredPrice {
  value: string;
  currency: string;
  source: StructuredSource;
  evidence: string;
}

export interface StructuredAvailability {
  availability: AvailabilityStatus;
  source: StructuredSource;
  evidence: string;
}

export interface StructuredExtraction {
  prices: StructuredPrice[];
  availabilities: StructuredAvailability[];
  /** Eindeutiger Preis (erste Quelle mit Treffern, ohne Widerspruch innerhalb dieser Quelle). */
  price: StructuredPrice | null;
  availability: StructuredAvailability | null;
  priceConflict: boolean;
  availabilityConflict: boolean;
}

const SOURCE_ORDER: StructuredSource[] = ['json-ld', 'microdata', 'meta'];

const AVAILABILITY_ALIASES: Record<string, AvailabilityStatus | undefined> = {
  instock: 'InStock',
  in_stock: 'InStock',
  'in stock': 'InStock',
  available: 'InStock',
  outofstock: 'OutOfStock',
  out_of_stock: 'OutOfStock',
  'out of stock': 'OutOfStock',
  oos: 'OutOfStock',
  soldout: 'SoldOut',
  preorder: 'PreOrder',
  'pre-order': 'PreOrder',
  backorder: 'BackOrder',
  discontinued: 'Discontinued',
  limitedavailability: 'LimitedAvailability',
  onlineonly: 'OnlineOnly',
  instoreonly: 'InStoreOnly',
  presale: 'PreSale',
};

export function decodeEntities(input: string): string {
  return input
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(Number.parseInt(n, 16)))
    .replace(/&nbsp;/g, ' ')
    .replace(/&euro;/g, '€')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&');
}

export function normalizeAvailability(raw: unknown): AvailabilityStatus | null {
  if (typeof raw === 'object' && raw !== null && '@id' in raw) {
    return normalizeAvailability(Reflect.get(raw, '@id'));
  }
  if (typeof raw !== 'string') return null;
  let value = raw.trim();
  if (!value) return null;
  const url = value.match(/schema\.org\/([A-Za-z]+)\/?$/i);
  if (url?.[1]) value = url[1];
  value = value.replace(/^schema:/i, '');
  const direct = CompetitorAvailabilityStatus.safeParse(value);
  if (direct.success) return direct.data;
  const caseInsensitive = CompetitorAvailabilityStatus.options.find(
    (o) => o.toLowerCase() === value.toLowerCase(),
  );
  if (caseInsensitive) return caseInsensitive;
  return AVAILABILITY_ALIASES[value.toLowerCase()] ?? null;
}

/** Normalisiert einen Betrag aus strukturierten Daten ("19.99", "1.299,00", 19.9). */
export function normalizePrice(raw: unknown): string | null {
  if (typeof raw === 'number') {
    if (!Number.isFinite(raw) || raw < 0 || raw > 1_000_000_000) return null;
    return String(Number(raw.toFixed(4)));
  }
  if (typeof raw !== 'string') return null;
  let value = raw.replace(/[^\d.,]/g, '');
  if (!/\d/.test(value)) return null;
  const comma = value.lastIndexOf(',');
  const dot = value.lastIndexOf('.');
  if (comma >= 0 && dot >= 0) {
    const decimal = comma > dot ? ',' : '.';
    const thousands = decimal === ',' ? '.' : ',';
    value = value.split(thousands).join('').replace(decimal, '.');
  } else if (comma >= 0) {
    const parts = value.split(',');
    value = parts.length === 2 && (parts[1] ?? '').length !== 3 ? parts.join('.') : parts.join('');
  } else if (dot >= 0) {
    const parts = value.split('.');
    if (parts.length > 2) value = parts.join('');
  }
  const number = Number(value);
  if (!Number.isFinite(number) || number < 0 || number > 1_000_000_000) return null;
  return String(Number(number.toFixed(4)));
}

function normalizeCurrency(raw: unknown): string | null {
  if (typeof raw !== 'string') return null;
  const value = raw.trim().toUpperCase();
  if (value === '€') return 'EUR';
  if (value === '£') return 'GBP';
  return /^[A-Z]{3}$/.test(value) ? value : null;
}

function typeMatches(node: Record<string, unknown>, names: string[]): boolean {
  const type = node['@type'];
  const list = Array.isArray(type) ? type : [type];
  return list.some(
    (t) => typeof t === 'string' && names.includes(t.replace(/^.*[/:]/, '').toLowerCase()),
  );
}

function collectOffers(node: unknown, out: Record<string, unknown>[], inProduct: boolean) {
  if (Array.isArray(node)) {
    for (const item of node) collectOffers(item, out, inProduct);
    return;
  }
  if (typeof node !== 'object' || node === null) return;
  const obj = node as Record<string, unknown>;
  const isProduct = typeMatches(obj, ['product', 'productgroup', 'individualproduct']);
  const isOffer = typeMatches(obj, ['offer', 'aggregateoffer']);
  if (isOffer && (inProduct || isOffer)) out.push(obj);
  for (const [key, value] of Object.entries(obj)) {
    if (key === '@context') continue;
    collectOffers(value, out, inProduct || isProduct);
  }
}

function snippet(value: unknown): string {
  return JSON.stringify(value).slice(0, 300);
}

function fromJsonLd(html: string): {
  prices: StructuredPrice[];
  availabilities: StructuredAvailability[];
} {
  const prices: StructuredPrice[] = [];
  const availabilities: StructuredAvailability[] = [];
  const blocks = html.matchAll(
    /<script\b[^>]*type\s*=\s*["']?application\/ld\+json["']?[^>]*>([\s\S]*?)<\/script>/gi,
  );
  for (const block of blocks) {
    let data: unknown;
    try {
      data = JSON.parse(decodeEntities((block[1] ?? '').trim()));
    } catch {
      continue;
    }
    const offers: Record<string, unknown>[] = [];
    collectOffers(data, offers, false);
    for (const offer of offers) {
      const isAggregate = typeMatches(offer, ['aggregateoffer']);
      const spec = offer.priceSpecification as Record<string, unknown> | undefined;
      const rawPrice =
        offer.price ??
        (isAggregate ? offer.lowPrice : undefined) ??
        (spec && !Array.isArray(spec) ? spec.price : undefined);
      const currency = normalizeCurrency(
        offer.priceCurrency ?? (spec && !Array.isArray(spec) ? spec.priceCurrency : undefined),
      );
      const value = normalizePrice(rawPrice);
      if (value && currency) {
        prices.push({
          value,
          currency,
          source: 'json-ld',
          evidence: snippet({ price: rawPrice, priceCurrency: currency }),
        });
      }
      const availability = normalizeAvailability(offer.availability);
      if (availability) {
        availabilities.push({
          availability,
          source: 'json-ld',
          evidence: snippet({ availability: offer.availability }),
        });
      }
    }
  }
  return { prices, availabilities };
}

function attr(tag: string, name: string): string | null {
  const m = tag.match(new RegExp(`\\s${name}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s>]+))`, 'i'));
  return m ? decodeEntities(m[1] ?? m[2] ?? m[3] ?? '') : null;
}

function itempropValues(html: string, prop: string): string[] {
  const values: string[] = [];
  const re = new RegExp(`<([a-z0-9]+)\\b[^>]*\\sitemprop\\s*=\\s*["']?${prop}["']?[^>]*>`, 'gi');
  for (const match of html.matchAll(re)) {
    const tag = match[0];
    const content = attr(tag, 'content') ?? attr(tag, 'href') ?? attr(tag, 'value');
    if (content !== null) {
      values.push(content);
      continue;
    }
    const rest = html.slice((match.index ?? 0) + tag.length, (match.index ?? 0) + tag.length + 200);
    const text = rest.split('<')[0]?.trim();
    if (text) values.push(decodeEntities(text));
  }
  return values;
}

function fromMicrodata(html: string) {
  const prices: StructuredPrice[] = [];
  const availabilities: StructuredAvailability[] = [];
  const priceValues = itempropValues(html, 'price');
  const currencies = itempropValues(html, 'priceCurrency').map(normalizeCurrency).filter(Boolean);
  const currency = currencies[0] ?? null;
  if (currency) {
    for (const raw of priceValues) {
      const value = normalizePrice(raw);
      if (value)
        prices.push({ value, currency, source: 'microdata', evidence: `itemprop=price: ${raw}` });
    }
  }
  for (const raw of itempropValues(html, 'availability')) {
    const availability = normalizeAvailability(raw);
    if (availability) {
      availabilities.push({
        availability,
        source: 'microdata',
        evidence: `itemprop=availability: ${raw}`,
      });
    }
  }
  return { prices, availabilities };
}

function metaContent(html: string, keys: string[]): string[] {
  const out: string[] = [];
  for (const match of html.matchAll(/<meta\b[^>]*>/gi)) {
    const tag = match[0];
    const key = (
      attr(tag, 'property') ??
      attr(tag, 'name') ??
      attr(tag, 'itemprop') ??
      ''
    ).toLowerCase();
    if (keys.includes(key)) {
      const content = attr(tag, 'content');
      if (content !== null) out.push(content);
    }
  }
  return out;
}

function fromMeta(html: string) {
  const prices: StructuredPrice[] = [];
  const availabilities: StructuredAvailability[] = [];
  const amounts = metaContent(html, ['product:price:amount', 'og:price:amount', 'twitter:data1']);
  const currency =
    metaContent(html, ['product:price:currency', 'og:price:currency'])
      .map(normalizeCurrency)
      .find(Boolean) ?? null;
  if (currency) {
    for (const raw of amounts) {
      const value = normalizePrice(raw);
      if (value)
        prices.push({
          value,
          currency,
          source: 'meta',
          evidence: `meta price: ${raw} ${currency}`,
        });
    }
  }
  for (const raw of metaContent(html, ['product:availability', 'og:availability'])) {
    const availability = normalizeAvailability(raw);
    if (availability)
      availabilities.push({ availability, source: 'meta', evidence: `meta availability: ${raw}` });
  }
  return { prices, availabilities };
}

function pickBySource<T extends { source: StructuredSource }>(
  items: T[],
  key: (item: T) => string,
): { value: T | null; conflict: boolean } {
  for (const source of SOURCE_ORDER) {
    const fromSource = items.filter((i) => i.source === source);
    if (fromSource.length === 0) continue;
    const unique = new Map(fromSource.map((i) => [key(i), i]));
    if (unique.size === 1) return { value: fromSource[0] ?? null, conflict: false };
    return { value: null, conflict: true };
  }
  return { value: null, conflict: false };
}

export function extractStructuredProductData(html: string): StructuredExtraction {
  const parts = [fromJsonLd(html), fromMicrodata(html), fromMeta(html)];
  const prices = parts.flatMap((p) => p.prices);
  const availabilities = parts.flatMap((p) => p.availabilities);
  const price = pickBySource(prices, (p) => `${p.value}|${p.currency}`);
  const availability = pickBySource(availabilities, (a) => a.availability);
  return {
    prices,
    availabilities,
    price: price.value,
    availability: availability.value,
    priceConflict: price.conflict,
    availabilityConflict: availability.conflict,
  };
}

/** Einfacher HTML→Text-Konverter für den optionalen KI-Fallback. */
export function htmlToText(html: string): { title: string; text: string } {
  const title = decodeEntities(html.match(/<title\b[^>]*>([\s\S]*?)<\/title>/i)?.[1]?.trim() ?? '');
  const text = decodeEntities(
    html
      .replace(/<(script|style|noscript|svg|template)\b[\s\S]*?<\/\1>/gi, ' ')
      .replace(/<!--[\s\S]*?-->/g, ' ')
      .replace(/<(br|\/p|\/div|\/li|\/h[1-6]|\/tr|\/section|\/article)\b[^>]*>/gi, '\n')
      .replace(/<[^>]+>/g, ' '),
  )
    .replace(/[ \t\u00a0]+/g, ' ')
    .replace(/\n\s*\n+/g, '\n')
    .trim();
  return { title, text };
}
