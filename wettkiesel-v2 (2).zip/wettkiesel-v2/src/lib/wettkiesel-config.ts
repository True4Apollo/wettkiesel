// Zentrale, einfach editierbare Inhalte für Wettkiesel.
// Alles mit [PLATZHALTER ...] MUSS vor dem Livegang durch echte Angaben ersetzt werden.

export const pricingIsProposal = true; // auf false setzen, sobald die Preise final sind

export const founderDiscount = {
  enabled: true,
  text: 'Gründungskunden (die ersten 10 Shops): 50 % Rabatt für 12 Monate.',
};

export const pilotOffer =
  '14 Tage kostenlos testen – wir richten bis zu 25 Produkte gemeinsam mit dir ein.';

export const pricingTiers = [
  {
    name: 'Start',
    priceEur: 29,
    tagline: 'Für den Einstieg',
    features: ['Bis 50 Produkte', 'Je bis zu 3 Wettbewerber', 'Tägliche Prüfung', 'Tagesbericht'],
  },
  {
    name: 'Shop',
    priceEur: 79,
    tagline: 'Für wachsende Shops',
    highlighted: true,
    features: [
      'Bis 250 Produkte',
      'Je bis zu 5 Wettbewerber',
      'Messverlauf mit Beleg',
      'Preisvorschläge innerhalb deiner Grenzen',
      'CSV-Export',
    ],
  },
  {
    name: 'Pro',
    priceEur: 149,
    tagline: 'Mit persönlicher Einrichtung',
    features: [
      'Bis 1.000 Produkte',
      'Persönliche Einrichtung',
      'Alles aus „Shop“',
      'Vorrang bei neuen Funktionen (Roadmap)',
    ],
  },
] as const;

export const legal = {
  name: 'Augustin Schätzle',
  street: 'Hauptstr. 145',
  city: '68799 Reilingen',
  country: 'Deutschland',
  email: 'schaetzle.augustin199@gmail.com',
  /** Optional – leer lassen, wenn keine Telefonnummer angegeben werden soll. */
  phone: '',
  /** Optional – leer lassen, wenn keine USt-IdNr. vorhanden ist. */
  vatId: '',
  responsibleForContent: 'Augustin Schätzle, Hauptstr. 145, 68799 Reilingen',
  hosting: 'Render Services, Inc. (Rechenzentrumsregion Frankfurt am Main)',
  database: 'Render Services, Inc. (PostgreSQL, Rechenzentrumsregion Frankfurt am Main)',
};

export const founder = {
  name: '[PLATZHALTER: Dein Name]',
  role: 'Gründer von Wettkiesel',
  text: '[PLATZHALTER: 2–3 Sätze, warum du Wettkiesel baust und welchen Bezug du zum Onlinehandel hast.]',
  photo: '', // z. B. '/founder.jpg' in /public ablegen
};
