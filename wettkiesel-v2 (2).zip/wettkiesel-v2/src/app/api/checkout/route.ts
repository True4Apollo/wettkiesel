// GET /api/checkout?tarif=shop – erstellt eine Stripe-Checkout-Session (Abo) und leitet weiter.
// Ohne STRIPE_SECRET_KEY / Preis-ID: Weiterleitung zum Pilotformular.
import 'server-only';
import { NextResponse } from 'next/server';
import { isTierKey, paymentLink, stripePriceId } from '@/lib/payments';

export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  const url = new URL(req.url);
  const tier = url.searchParams.get('tarif');
  const origin = (process.env.NEXT_PUBLIC_APP_URL ?? url.origin).replace(/\/+$/, '');
  if (!isTierKey(tier)) return NextResponse.redirect(`${origin}/#preise`, 303);

  const price = stripePriceId(tier);
  if (!price) {
    const link = paymentLink(tier);
    return NextResponse.redirect(link ?? `${origin}/pilot?tarif=${tier}`, 303);
  }

  const body = new URLSearchParams({
    mode: 'subscription',
    'line_items[0][price]': price,
    'line_items[0][quantity]': '1',
    success_url: `${origin}/danke?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${origin}/#preise`,
    allow_promotion_codes: 'true',
    billing_address_collection: 'required',
    locale: 'de',
    'tax_id_collection[enabled]': 'true',
    'metadata[tarif]': tier,
  });
  const res = await fetch('https://api.stripe.com/v1/checkout/sessions', {
    method: 'POST',
    headers: {
      authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
      'content-type': 'application/x-www-form-urlencoded',
    },
    body,
    signal: AbortSignal.timeout(15_000),
  }).catch(() => null);
  const data = res?.ok ? ((await res.json()) as { url?: string }) : null;
  if (!data?.url) return NextResponse.redirect(`${origin}/pilot?tarif=${tier}&zahlung=fehler`, 303);
  return NextResponse.redirect(data.url, 303);
}
