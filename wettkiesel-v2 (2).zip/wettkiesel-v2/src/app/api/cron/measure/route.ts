// POST/GET /api/cron/measure – startet den täglichen Messlauf.
// Geschützt über CRON_SECRET (Header: Authorization: Bearer <CRON_SECRET>).
// Ohne gesetztes CRON_SECRET ist der Endpunkt deaktiviert (503).
import 'server-only';
import { timingSafeEqual } from 'node:crypto';
import { NextResponse } from 'next/server';
import { refreshDailyCompetitorChecks } from '@/lib/business/daily-competitor-checks';

export const dynamic = 'force-dynamic';
export const maxDuration = 300;

function authorized(req: Request, secret: string): boolean {
  const header = req.headers.get('authorization') ?? '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  const a = Buffer.from(token);
  const b = Buffer.from(secret);
  return a.length === b.length && timingSafeEqual(a, b);
}

async function handle(req: Request) {
  const secret = process.env.CRON_SECRET;
  if (!secret) return NextResponse.json({ error: 'cron_disabled' }, { status: 503 });
  if (!authorized(req, secret))
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const startedAt = new Date().toISOString();
  try {
    const result = await refreshDailyCompetitorChecks();
    return NextResponse.json({ ok: true, startedAt, finishedAt: new Date().toISOString(), result });
  } catch (error) {
    const kind = error instanceof Error ? error.name : 'UnknownError';
    return NextResponse.json({ ok: false, startedAt, error: kind }, { status: 500 });
  }
}

export const POST = handle;
export const GET = handle;
