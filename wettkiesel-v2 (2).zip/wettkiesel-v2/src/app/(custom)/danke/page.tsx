import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = { title: 'Danke für deine Buchung', robots: { index: false } };

export default function DankePage() {
  return (
    <main className="wk-legal">
      <h1>Danke – deine Buchung ist eingegangen.</h1>
      <p>
        Du erhältst von Stripe eine Bestätigung per E-Mail. Wir melden uns in Kürze, um deine
        Produkte und Wettbewerber einzurichten.
      </p>
      <p>
        <Link href="/">Zurück zur Startseite</Link>
      </p>
    </main>
  );
}
