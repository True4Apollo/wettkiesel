import type { Metadata } from 'next';
import Link from 'next/link';
import measurements from '../../../../data/beispielbericht.json';

export const metadata: Metadata = {
  title: 'Beispiel-Tagesbericht mit echten öffentlichen Preisen – Kaffee-Zubehör',
  description:
    'Ein echter Wettkiesel-Bericht: öffentliche Preise und Verfügbarkeiten von Kaffee-Zubehör bei drei deutschen Onlineshops, mit Zeitpunkt und Quelle.',
  alternates: { canonical: '/beispielbericht' },
};

type Measurement = {
  product: string;
  shop: string;
  url: string;
  measuredAt: string;
  httpStatus: number | null;
  price?: string | null;
  currency?: string | null;
  priceSource?: string | null;
  availability?: string | null;
  error?: string;
};

const SHOPS = ['roastmarket.de', 'frogcoffee.de', 'kaffeezentrale.de'];
const AVAIL: Record<string, string> = {
  InStock: 'Auf Lager',
  OutOfStock: 'Nicht verfügbar',
  LimitedAvailability: 'Begrenzt verfügbar',
  PreOrder: 'Vorbestellbar',
  BackOrder: 'Nachbestellt',
  SoldOut: 'Ausverkauft',
};
const SOURCE: Record<string, string> = {
  'json-ld': 'JSON-LD',
  microdata: 'Microdata',
  meta: 'Meta-Tags',
};

const eur = (v: string) =>
  new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(Number(v));
const fmtDate = (iso: string) =>
  new Intl.DateTimeFormat('de-DE', {
    dateStyle: 'long',
    timeStyle: 'short',
    timeZone: 'Europe/Berlin',
  }).format(new Date(iso));

export default function BeispielberichtPage() {
  const data = measurements as Measurement[];
  const products = [...new Set(data.map((m) => m.product))];
  const first = data.map((m) => m.measuredAt).sort()[0] ?? '';
  const day = first
    ? new Intl.DateTimeFormat('de-DE', { dateStyle: 'long', timeZone: 'Europe/Berlin' }).format(
        new Date(first),
      )
    : '';
  const ok = data.filter((m) => m.price);

  return (
    <main className="wk-legal" style={{ maxWidth: 1080 }}>
      <p className="wk-placeholder-note" style={{ borderColor: '#1d5a43', background: '#e4efe8' }}>
        <strong>Echte öffentliche Daten vom {day}.</strong> Gemessen mit dem Wettkiesel-Extraktor
        auf öffentlich zugänglichen Produktseiten. Momentaufnahme – Preise können sich inzwischen
        geändert haben. Keine Verbindung zu den genannten Shops.
      </p>
      <h1>Tagesbericht: Kaffee- & Espresso-Zubehör</h1>
      <p>
        {products.length} Produkte · {SHOPS.length} Shops · {ok.length} von {data.length} Seiten mit
        lesbarem Preis
      </p>

      <h2>Preisübersicht</h2>
      <div className="wk-table-wrap">
        <table className="wk-report-table">
          <thead>
            <tr>
              <th>Produkt</th>
              {SHOPS.map((s) => (
                <th key={s}>{s}</th>
              ))}
              <th>Spanne</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => {
              const row = data.filter((m) => m.product === p);
              const prices = row.filter((m) => m.price).map((m) => Number(m.price));
              const min = Math.min(...prices);
              const max = Math.max(...prices);
              return (
                <tr key={p}>
                  <td>
                    <strong>{p}</strong>
                  </td>
                  {SHOPS.map((s) => {
                    const m = row.find((r) => r.shop === s);
                    if (!m)
                      return (
                        <td key={s} style={{ color: '#5d6d65' }}>
                          nicht gemessen
                        </td>
                      );
                    if (!m.price)
                      return (
                        <td key={s} style={{ color: '#c2410c' }}>
                          keine Messung
                        </td>
                      );
                    const cheapest = prices.length > 1 && Number(m.price) === min;
                    return (
                      <td key={s}>
                        <a href={m.url} rel="nofollow noopener" target="_blank">
                          {eur(m.price)}
                        </a>
                        {cheapest ? ' ★' : ''}
                        <br />
                        <small style={{ color: '#5d6d65' }}>
                          {AVAIL[m.availability ?? ''] ?? 'Verfügbarkeit unbekannt'}
                        </small>
                      </td>
                    );
                  })}
                  <td>
                    {prices.length > 1
                      ? `${eur(String(max - min))} (${Math.round(((max - min) / min) * 100)} %)`
                      : '–'}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <p>
        <small>
          ★ günstigster gemessener Preis. Preise inkl. MwSt. laut Produktseite, ohne Versand.
        </small>
      </p>

      <h2>Was ein Shopbetreiber daraus lernt</h2>
      <ul>
        <li>
          Bei identischer Markenware liegen die Preise teils deutlich auseinander – siehe Spalte
          „Spanne“.
        </li>
        <li>
          Ist ein Wettbewerber „nicht verfügbar“, ist das ein Signal, beim eigenen Preis nicht
          nachzugeben.
        </li>
        <li>Jeder Wert ist mit Zeitpunkt und Quelle belegt – nachprüfbar per Klick.</li>
      </ul>

      <h2>Messprotokoll</h2>
      <div className="wk-table-wrap">
        <table className="wk-report-table">
          <thead>
            <tr>
              <th>Zeitpunkt</th>
              <th>Shop</th>
              <th>Produkt</th>
              <th>Preis</th>
              <th>Verfügbarkeit</th>
              <th>Quelle im HTML</th>
            </tr>
          </thead>
          <tbody>
            {data.map((m) => (
              <tr key={m.url}>
                <td>{fmtDate(m.measuredAt)}</td>
                <td>
                  <a href={m.url} rel="nofollow noopener" target="_blank">
                    {m.shop}
                  </a>
                </td>
                <td>{m.product}</td>
                <td>{m.price ? eur(m.price) : 'keine Messung'}</td>
                <td>{AVAIL[m.availability ?? ''] ?? '–'}</td>
                <td>{SOURCE[m.priceSource ?? ''] ?? '–'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <h2>Hinweise zur Messung</h2>
      <ul>
        <li>
          Gelesen wurden nur strukturierte Produktdaten (JSON-LD bzw. Microdata), die die Shops
          selbst ausliefern. Es wurde nichts geschätzt.
        </li>
        <li>
          Manche Seiten bieten mehrere Varianten (z. B. Größe 01/02). Gemessen wurde der Preis, den
          die Seite standardmäßig ausweist.
        </li>
        <li>
          „nicht gemessen“ heißt: Für diesen Shop haben wir keine passende Produktseite ermittelt –
          das sagt nichts darüber, ob der Shop das Produkt führt.
        </li>
      </ul>

      <p style={{ marginTop: '2rem' }}>
        <Link href="/pilot">So einen Bericht für deinen Shop – 14 Tage kostenlos testen →</Link>
      </p>
    </main>
  );
}
