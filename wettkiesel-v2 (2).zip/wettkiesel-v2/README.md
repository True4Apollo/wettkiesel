# Wettkiesel

Preisüberwachung für kleine Onlineshops: Wettkiesel beobachtet öffentliche Wettbewerberpreise und
Verfügbarkeiten, speichert Messverläufe und erstellt Tagesberichte mit unverbindlichen
Preisvorschlägen. Automatische Preisänderungen sind (noch) nicht aktiv.

Technik: Next.js 16 (App Router), React 19, TypeScript, Tailwind 4, Prisma 6 + PostgreSQL,
Better Auth (Login), Vitest, Biome.

Die Vorlage für dieses Projekt stammt von Polsia. Diese Version (v2) läuft auch ohne Polsia.
Welche Funktionen noch Polsia-Dienste brauchen, steht weiter unten.

---

## 1. Vor dem Livegang ausfüllen (WICHTIG)

Alle Platzhalter stehen in **`src/lib/wettkiesel-config.ts`**:

| Bereich | Was | Wo sichtbar |
|---|---|---|
| `legal` | Name/Firma, Anschrift, E-Mail, Telefon, USt-IdNr., Hosting- und DB-Anbieter | `/impressum`, `/datenschutz` |
| `founder` | Dein Name, 2–3 Sätze über dich, optional Foto (`/public/founder.jpg`) | Startseite „Wer dahinter steht“ |
| `pricingTiers` | Tarife (Vorschlag: 29 / 79 / 149 €) | Startseite „Preise“ |
| `pricingIsProposal` | `true` = Hinweis „Preise sind ein Vorschlag“ wird angezeigt | Startseite |
| `founderDiscount` | Gründungsrabatt an/aus + Text | Startseite |
| `pilotOffer` | Text des Pilotangebots | Startseite, `/pilot` |

Suche nach übrig gebliebenen Platzhaltern: `grep -rn "PLATZHALTER" src`

Die Datenschutzerklärung ist nur ein **Gerüst**. Prüfe sie mit einem Generator (z. B. eRecht24 oder
Dr. Schwenke) oder lass sie anwaltlich prüfen.

## 2. Lokal starten

Voraussetzungen: Node.js ≥ 20.18, PostgreSQL (lokal oder z. B. kostenlos bei Neon/Supabase).

```bash
npm install
cp .env.example .env        # Werte eintragen (siehe unten)
npx prisma migrate deploy   # Tabellen anlegen
npm run dev                 # http://localhost:3000
```

Postgres schnell per Docker: `docker run -d -p 5432:5432 -e POSTGRES_PASSWORD=wk -e POSTGRES_DB=wettkiesel postgres:17`
→ `DATABASE_URL=postgresql://postgres:wk@localhost:5432/wettkiesel`

Weitere Befehle:

```bash
npm run build && npm start  # Produktionsbuild
npm test                    # Unit-Tests (Vitest)
npm run typecheck           # TypeScript
npm run lint                # Biome
npx prisma studio           # Datenbank im Browser ansehen
```

## 3. Umgebungsvariablen

| Variable | Pflicht | Bedeutung |
|---|---|---|
| `DATABASE_URL` | ja | Postgres-Verbindung |
| `BETTER_AUTH_SECRET` | ja | Langer Zufallswert, z. B. `openssl rand -base64 32` |
| `BETTER_AUTH_URL` | ja | Öffentliche URL der App (lokal `http://localhost:3000`) |
| `NEXT_PUBLIC_APP_URL` | ja | Gleiche URL. Wird auch für Canonical, Sitemap und OG-Bilder genutzt |
| `POLSIA_OWNER_EMAIL` | empfohlen | Wer sich mit dieser E-Mail registriert, wird Admin (`/admin`). Der Name stammt aus der Vorlage, das Feature läuft auch ohne Polsia |
| `BETTER_AUTH_TRUSTED_ORIGINS` | optional | Weitere erlaubte Domains, kommagetrennt |
| `AI_API_KEY` | optional | Schaltet den KI-Fallback für die Preisauslesung und den KI-Chat frei |
| `AI_BASE_URL` | optional | OpenAI-kompatibler Endpunkt (Standard `https://api.openai.com/v1`; geht auch mit Mistral, OpenRouter, lokalem Ollama `http://localhost:11434/v1`) |
| `AI_MODEL` | optional | Modellname (Standard `gpt-4o-mini`) |
| `STRIPE_SECRET_KEY`, `STRIPE_PRICE_*`, `STRIPE_LINK_*` | optional | Bezahlung, siehe 4b |
| `CRON_SECRET` | optional | Schaltet `/api/cron/measure` für den täglichen Messlauf frei |
| `PAGE_FETCH_USER_AGENT` | optional | User-Agent beim Abruf der Wettbewerberseiten |
| `POLSIA_EMAIL_PROXY_URL`, `POLSIA_COMPANY_EMAIL` | optional | E-Mail-Benachrichtigung bei neuen Pilotanfragen über Polsia |
| `POLSIA_ANALYTICS_SLUG` | optional | Polsia-Besucherzähler. Ohne diesen Wert gibt es kein Tracking |

## 4. Deployment

### Vercel + Neon (Postgres)
1. Code in ein eigenes GitHub-Repo pushen.
2. Bei neon.tech eine Datenbank anlegen und die Verbindungs-URL kopieren.
3. Auf vercel.com das Repo importieren und die Variablen aus Abschnitt 3 setzen
   (`BETTER_AUTH_URL` und `NEXT_PUBLIC_APP_URL` = deine Domain).
4. Build-Befehl: `npx prisma migrate deploy && npm run build`
5. Eigene Domain verbinden (z. B. wettkiesel.de).

### Railway
1. Neues Projekt aus dem GitHub-Repo anlegen und ein Postgres-Plugin hinzufügen
   (`DATABASE_URL` wird automatisch gesetzt).
2. Variablen setzen, Build: `npm run build`, Start: `npx prisma migrate deploy && npm start`.

### Täglicher Messlauf (kostenlos über GitHub Actions)

Cron-Jobs auf Render kosten Geld. Darum läuft der tägliche Messlauf kostenlos so:

1. Die App hat den Endpunkt `POST /api/cron/measure`, geschützt mit `Authorization: Bearer <CRON_SECRET>`.
   Ohne gesetztes `CRON_SECRET` antwortet er mit 503 (deaktiviert).
2. Auf Render die Umgebungsvariable `CRON_SECRET` setzen, als langen Zufallswert (`openssl rand -hex 32`).
3. Im GitHub-Repo unter **Settings → Secrets and variables → Actions** zwei Secrets anlegen:
   `WETTKIESEL_URL` = `https://wettkiesel.onrender.com` und `CRON_SECRET` = derselbe Wert wie auf Render.
4. Die Datei `.github/workflows/daily-measure.yml` muss **im Hauptverzeichnis des Repos** liegen
   (nicht nur im Zip). Sie weckt die schlafende Render-Instanz auf und startet den Lauf täglich um 04:00 UTC.
   Über „Actions → Täglicher Messlauf → Run workflow“ kannst du ihn auch manuell starten.

Alternativ: `npx tsx jobs/daily-competitor-checks.ts` auf einem beliebigen Server mit `DATABASE_URL`.

## 4b. Bezahlung (Stripe, optional)

Ohne Stripe-Variablen zeigt die Seite nur „14 Tage kostenlos testen“. Sobald konfiguriert, erscheint unter
jedem Tarif „Oder direkt buchen“.

- **Einfachste Variante – Payment Links:** In Stripe pro Tarif ein Produkt mit monatlichem Preis
  (29/79/149 €) anlegen, dann einen Payment Link erstellen und als `STRIPE_LINK_START/SHOP/PRO` auf Render setzen.
  Als Erfolgs-URL `https://wettkiesel.onrender.com/danke` eintragen.
- **Checkout-Variante:** `STRIPE_SECRET_KEY` (sk_live_… bzw. sk_test_…) und die Preis-IDs
  `STRIPE_PRICE_START/SHOP/PRO` (price_…) setzen. `/api/checkout?tarif=shop` erzeugt dann eine Abo-Checkout-Session.
- Rechnungen, Kündigung und Kundenportal laufen über Stripe. Ein Webhook ist nicht eingebaut. Neue Kunden
  siehst du im Stripe-Dashboard und schaltest sie manuell frei.
- Vor dem Livegang AGB, Widerrufsbelehrung (bei Verbrauchern) und einen Datenschutz-Hinweis zu Stripe ergänzen.

## 5. Pilotanfragen ansehen

Anfragen aus `/pilot` landen in der Tabelle `contact_message`. Als Admin siehst du sie unter
**`/admin/pilotanfragen`**. Eine E-Mail-Benachrichtigung gibt es nur mit den Polsia-E-Mail-Variablen.
Ohne sie schaust du im Admin-Bereich oder mit `npx prisma studio` nach. Eigener Versand
(z. B. Resend/SMTP) lässt sich in `src/app/api/contact/route.ts` → `notifyCompany` ergänzen.

## 6. So funktioniert die Messung

1. **Seitenabruf** (`src/lib/business/page-fetch.ts`): normales `fetch` mit User-Agent, 30 s Timeout,
   max. 3 MB, max. 5 Weiterleitungen. Jede Weiterleitung wird gegen private/interne Adressen geprüft (SSRF-Schutz).
2. **Deterministische Auswertung** (`src/lib/business/html-extraction.ts`), in dieser Reihenfolge:
   JSON-LD (`Product`/`Offer`/`AggregateOffer`, auch in `@graph`) → Microdata (`itemprop="price"`,
   `priceCurrency`, `availability`) → OpenGraph/Meta (`product:price:amount`, `product:availability`).
   Widersprüchliche Preise werden als „inconsistent“ markiert, das Tool rät nicht. Ohne Währung wird kein Preis übernommen.
3. **Optionaler KI-Fallback**: Nur wenn keine strukturierten Daten gefunden wurden **und** `AI_API_KEY`
   gesetzt ist. Die KI liefert wörtliche Preiszitate. Übernommen werden nur Zitate, die wirklich im Seitentext stehen.

Grenzen: Seiten, die Preise erst per JavaScript nachladen oder Bots blockieren (Cloudflare o. Ä.),
liefern ohne Browser-Rendering eventuell keine Daten. Die meisten Shopify-, Shopware- und WooCommerce-Shops
liefern aber JSON-LD aus.

## 6b. Verbliebene Polsia-Teile

| Teil | Status |
|---|---|
| Messung, Website, Login, Dashboard, Admin, Formular | **ohne Polsia** |
| E-Mail bei neuer Pilotanfrage (`src/lib/email/*`) | optional über Polsia. Ohne Polsia wird nichts versendet |
| Besucher-Analytics | nur aktiv, wenn `POLSIA_ANALYTICS_SLUG` gesetzt ist |
| `src/modules/web-search/*` | wird nur noch für den lokalen Helfer `runBatch` und Fehlerklassen genutzt, keine Netzwerkaufrufe |
| `.polsia/*`, `// @polsia:...`-Kommentare | Metadaten der Polsia-Vorlage, ohne Einfluss auf die Laufzeit |

## 7. Bekannte Testfehler

4 von 325 Unit-Tests schlagen fehl, im Original genauso (nicht durch v2 verursacht):
`competitor-price-suggestion`, `manual-competitor-run`, `manual-own-product-run`,
`shop-product-detail-view`.

## 8. Was in v2 geändert wurde

- Neue Startseite: Hero mit klarem Nutzen, Funktionen, kompakter Kasten „Heute / Roadmap“, Ablauf des Pilots,
  Preise (konfigurierbar), Gründer-Abschnitt, FAQ, Footer mit Impressum und Datenschutz.
- Kürzeres Pilotformular: Name, E-Mail, Shop-URL, Shopsystem, 0–5 Wettbewerber-URLs, Budget optional.
- Neue Seiten: `/impressum`, `/datenschutz` (mit Platzhaltern), `/beispielbericht` (fiktive Beispieldaten).
- SEO: neue Titel und Meta-Beschreibungen, die Sitemap enthält jetzt alle öffentlichen Seiten.
- Unabhängigkeit: Polsia-E-Mail optional, Migration für Shop-Produkte ergänzt
  (`prisma/migrations/20261019222607_add_shop_products`), `.env.example`, README.
