import { act } from 'react';
import { createRoot, type Root } from 'react-dom/client';
import { afterEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  apiFetch: vi.fn(),
  toastSuccess: vi.fn(),
  toastError: vi.fn(),
}));

vi.mock('@/lib/api-client', () => ({ apiFetch: mocks.apiFetch }));
vi.mock('sonner', () => ({ toast: { success: mocks.toastSuccess, error: mocks.toastError } }));

import { CompetitorMeasurementPanel } from '@/components/custom/admin/competitor-measurement-panel';

describe('Manuelle Wettbewerber-Prüfrunde', () => {
  let root: Root | null = null;
  let container: HTMLDivElement | null = null;

  afterEach(async () => {
    if (root) await act(async () => root?.unmount());
    container?.remove();
    root = null;
    container = null;
    vi.clearAllMocks();
  });

  it('setzt nach einer als Fehler gespeicherten URL mit der nächsten fort und schließt den Lauf ab', async () => {
    Object.defineProperty(globalThis, 'IS_REACT_ACT_ENVIRONMENT', {
      configurable: true,
      value: true,
    });

    const startedAt = '2026-10-14T12:00:00.000Z';
    const checkedAt = '2026-10-14T12:01:00.000Z';
    const pendingMeasurements = [
      {
        id: 'measurement-timeout',
        targetType: 'own',
        competitorUrl: 'https://shop.example.net/slow-item',
        status: 'pending',
        priceValue: null,
        currency: null,
        priceStatus: 'not_checked',
        priceErrorCode: null,
        priceErrorMessage: null,
        availability: null,
        priceEvidence: null,
        availabilityEvidence: null,
        errorCode: null,
        errorMessage: null,
        checkedAt: null,
        attemptedAt: null,
        sourceCached: null,
      },
      {
        id: 'measurement-next',
        targetType: 'competitor',
        competitorUrl: 'https://shop.example.net/next-item',
        status: 'pending',
        priceValue: null,
        currency: null,
        priceStatus: 'not_checked',
        priceErrorCode: null,
        priceErrorMessage: null,
        availability: null,
        priceEvidence: null,
        availabilityEvidence: null,
        errorCode: null,
        errorMessage: null,
        checkedAt: null,
        attemptedAt: null,
        sourceCached: null,
      },
    ];
    const initialRun = {
      id: 'run-1',
      status: 'running',
      startedAt,
      completedAt: null,
      measurements: pendingMeasurements,
    };
    const timedOutMeasurement = {
      ...pendingMeasurements[0],
      status: 'error',
      errorCode: 'page_read_timeout',
      errorMessage: 'Die Wettbewerberseite antwortete nicht innerhalb von 30 Sekunden.',
      attemptedAt: checkedAt,
    };
    const measuredNext = {
      ...pendingMeasurements[1],
      status: 'observed',
      priceValue: '12.99',
      currency: 'EUR',
      priceStatus: 'observed',
      priceErrorCode: null,
      priceErrorMessage: null,
      availability: 'InStock',
      priceEvidence: 'Preis 12,99 €',
      availabilityEvidence: 'https://schema.org/InStock',
      checkedAt,
      attemptedAt: checkedAt,
    };
    const completedRun = {
      ...initialRun,
      status: 'completed',
      completedAt: checkedAt,
      measurements: [timedOutMeasurement, measuredNext],
    };
    let historyReads = 0;
    mocks.apiFetch.mockImplementation(async (path: string, options?: RequestInit) => {
      if (options?.method === 'POST' && path.endsWith('/competitor-checks')) {
        return { run: initialRun };
      }
      if (options?.method === 'POST' && path.endsWith('/measurement-timeout')) {
        return { measurement: timedOutMeasurement, runStatus: 'running' };
      }
      if (options?.method === 'POST' && path.endsWith('/measurement-next')) {
        return { measurement: measuredNext, runStatus: 'completed' };
      }
      if (!options?.method && path.endsWith('/competitor-checks')) {
        historyReads += 1;
        return historyReads === 1
          ? { run: null, runs: [] }
          : { run: completedRun, runs: [completedRun] };
      }
      throw new Error(`Unerwarteter API-Aufruf: ${options?.method ?? 'GET'} ${path}`);
    });

    let resolveSuccess: () => void = () => {};
    const finished = new Promise<void>((resolve) => {
      resolveSuccess = resolve;
    });
    mocks.toastSuccess.mockImplementation(resolveSuccess);

    container = document.createElement('div');
    document.body.append(container);
    root = createRoot(container);
    await act(async () => {
      root?.render(
        <CompetitorMeasurementPanel productId="product-1" competitorCount={2} isArchived={false} />,
      );
    });

    const startButton = [...container.querySelectorAll('button')].find((button) =>
      button.textContent?.includes('Eigenes Produkt & Wettbewerber prüfen'),
    );
    expect(startButton).toBeDefined();

    await act(async () => {
      startButton?.click();
      await finished;
    });

    expect(mocks.apiFetch).toHaveBeenNthCalledWith(
      3,
      '/api/admin/products/product-1/competitor-checks/measurement-timeout',
      expect.objectContaining({ method: 'POST' }),
    );
    expect(mocks.apiFetch).toHaveBeenNthCalledWith(
      4,
      '/api/admin/products/product-1/competitor-checks/measurement-next',
      expect.objectContaining({ method: 'POST' }),
    );
    expect(mocks.toastSuccess).toHaveBeenCalledWith(
      'Die gespeicherten Produkt- und Wettbewerber-URLs wurden geprüft.',
    );
    expect(mocks.toastError).not.toHaveBeenCalled();
  });

  it('zeigt belegten Preis, nicht lesbaren Preisfehler und gültige Verfügbarkeit getrennt', async () => {
    Object.defineProperty(globalThis, 'IS_REACT_ACT_ENVIRONMENT', {
      configurable: true,
      value: true,
    });
    const run = {
      id: 'run-history',
      status: 'completed',
      startedAt: '2026-10-14T12:00:00.000Z',
      completedAt: '2026-10-14T12:01:00.000Z',
      measurements: [
        {
          id: 'measurement-valid',
          targetType: 'own',
          competitorUrl: 'https://shop.example.net/valid',
          status: 'observed',
          priceValue: '19.99',
          currency: 'EUR',
          priceStatus: 'observed',
          priceErrorCode: null,
          priceErrorMessage: null,
          availability: 'InStock',
          priceEvidence: '19,99 €',
          availabilityEvidence: 'https://schema.org/InStock',
          errorCode: null,
          errorMessage: null,
          checkedAt: '2026-10-14T12:01:00.000Z',
          attemptedAt: '2026-10-14T12:00:00.000Z',
          sourceCached: false,
        },
        {
          id: 'measurement-unreadable',
          targetType: 'competitor',
          competitorUrl: 'https://shop.example.net/unreadable',
          status: 'partial',
          priceValue: null,
          currency: null,
          priceStatus: 'unreadable',
          priceErrorCode: 'price_unreadable',
          priceErrorMessage: 'Preis nicht auslesbar: Mehrere Angaben sind möglich.',
          availability: null,
          priceEvidence: '$579.99',
          availabilityEvidence: null,
          errorCode: 'price_unreadable',
          errorMessage: 'Preis nicht auslesbar: Mehrere Angaben sind möglich.',
          checkedAt: '2026-10-14T12:01:00.000Z',
          attemptedAt: '2026-10-14T12:00:00.000Z',
          sourceCached: false,
        },
      ],
    };
    mocks.apiFetch.mockResolvedValue({ run, runs: [run] });
    container = document.createElement('div');
    document.body.append(container);
    root = createRoot(container);

    await act(async () => {
      root?.render(
        <CompetitorMeasurementPanel productId="product-1" competitorCount={2} isArchived={false} />,
      );
    });

    expect(container.textContent).toContain('19,99 EUR');
    expect(container.textContent).toContain('Eigenes Produkt');
    expect(container.textContent).toContain('Belegter Preis');
    expect(container.textContent).toContain('Nicht auslesbar');
    expect(container.textContent).toContain('Preis nicht auslesbar: Mehrere Angaben sind möglich.');
    expect(container.textContent).toContain('Verfügbarkeit');
    expect(container.textContent).toContain('Auf Lager');
    expect(container.textContent).toContain('Unbekannt');
    expect(container.textContent).toContain(
      `Messzeitpunkt: ${new Intl.DateTimeFormat('de-DE', {
        dateStyle: 'medium',
        timeStyle: 'short',
      }).format(new Date('2026-10-14T12:01:00.000Z'))}`,
    );
  });
});
