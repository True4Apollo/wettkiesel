import { describe, expect, it } from 'vitest';
import { archiveShopProductForOwner } from '@/lib/business/archive-shop-product';

interface TestProduct {
  id: string;
  userId: string;
  isArchived: boolean;
}

function archiveStore(products: TestProduct[]) {
  return {
    shopProduct: {
      async updateMany({
        where,
        data,
      }: {
        where: { id: string; userId: string; isArchived: false };
        data: { isArchived: true };
      }) {
        const product = products.find(
          (candidate) =>
            candidate.id === where.id &&
            candidate.userId === where.userId &&
            candidate.isArchived === where.isArchived,
        );
        if (!product) return { count: 0 };
        product.isArchived = data.isArchived;
        return { count: 1 };
      },
    },
  };
}

describe('archiveShopProductForOwner', () => {
  it('archives an active product only when its userId matches the caller', async () => {
    const product: TestProduct = { id: 'product-1', userId: 'shop-owner-1', isArchived: false };
    const store = archiveStore([product]);

    const otherOwnerResult = await archiveShopProductForOwner(store, product.id, 'shop-owner-2');

    expect(otherOwnerResult).toBe(false);
    expect(product.isArchived).toBe(false);

    const ownerResult = await archiveShopProductForOwner(store, product.id, 'shop-owner-1');

    expect(ownerResult).toBe(true);
    expect(product.isArchived).toBe(true);
  });

  it('does not change the status of an already archived product', async () => {
    const product: TestProduct = { id: 'product-1', userId: 'shop-owner-1', isArchived: true };

    const result = await archiveShopProductForOwner(
      archiveStore([product]),
      product.id,
      product.userId,
    );

    expect(result).toBe(false);
    expect(product.isArchived).toBe(true);
  });
});
