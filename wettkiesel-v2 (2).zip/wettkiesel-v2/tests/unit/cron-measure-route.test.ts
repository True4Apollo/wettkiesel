import { afterEach, describe, expect, it, vi } from 'vitest';

const refresh = vi.hoisted(() => vi.fn());
vi.mock('server-only', () => ({}));
vi.mock('@/lib/business/daily-competitor-checks', () => ({
  refreshDailyCompetitorChecks: refresh,
}));

import { POST } from '@/app/api/cron/measure/route';

const req = (auth?: string) =>
  new Request('http://x/api/cron/measure', {
    method: 'POST',
    headers: auth ? { authorization: auth } : {},
  });

describe('/api/cron/measure', () => {
  afterEach(() => {
    delete process.env.CRON_SECRET;
    refresh.mockReset();
  });
  it('ist ohne CRON_SECRET deaktiviert', async () => {
    expect((await POST(req('Bearer x'))).status).toBe(503);
    expect(refresh).not.toHaveBeenCalled();
  });
  it('lehnt falsches Secret ab', async () => {
    process.env.CRON_SECRET = 'geheim';
    expect((await POST(req('Bearer falsch'))).status).toBe(401);
    expect((await POST(req())).status).toBe(401);
    expect(refresh).not.toHaveBeenCalled();
  });
  it('startet den Messlauf mit korrektem Secret', async () => {
    process.env.CRON_SECRET = 'geheim';
    refresh.mockResolvedValue({ checks: { done: 2, failed: 0, skipped: 0 } });
    const res = await POST(req('Bearer geheim'));
    expect(res.status).toBe(200);
    expect(refresh).toHaveBeenCalledOnce();
  });
});
