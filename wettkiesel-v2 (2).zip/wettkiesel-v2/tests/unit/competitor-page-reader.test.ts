import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  assertPublicHttpTarget: vi.fn(),
  fetchProductPage: vi.fn(),
  generateObject: vi.fn(),
  isAiConfigured: vi.fn(),
}));

vi.mock('server-only', () => ({}));
vi.mock('@/lib/business/public-http-target', () => ({
  assertPublicHttpTarget: mocks.assertPublicHttpTarget,
  InvalidPublicHttpTargetError: class InvalidPublicHttpTargetError extends Error {},
}));
vi.mock('@/lib/ai/client', () => ({
  AiConfigurationError: class AiConfigurationError extends Error {},
  generateObject: mocks.generateObject,
  isAiConfigured: mocks.isAiConfigured,
}));
vi.mock('@/lib/business/page-fetch', () => ({
  fetchProductPage: mocks.fetchProductPage,
  PageFetchError: class PageFetchError extends Error {
    constructor(
      public code: string,
      message: string,
      public status?: number,
    ) {
      super(message);
    }
  },
}));

import { readCompetitorPage } from '@/lib/business/competitor-page-reader';
import { PageFetchError } from '@/lib/business/page-fetch';
import { InvalidPublicHttpTargetError } from '@/lib/business/public-http-target';

const jsonLdPage = `<html><head><title>Mühle</title><script type="application/ld+json">{"@context":"https://schema.org","@type":"Product","offers":{"@type":"Offer","price":"12.99","priceCurrency":"EUR","availability":"https://schema.org/InStock"}}</script></head><body>Preis 12,99 €</body></html>`;

function page(html: string) {
  return {
    url: 'https://store.example.net/item',
    html,
    status: 200,
    fetchedAt: '2026-10-19T12:00:00.000Z',
    truncated: false,
  };
}

describe('readCompetitorPage (eigener Abruf, deterministisch + optional KI)', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.assertPublicHttpTarget.mockResolvedValue(undefined);
    mocks.isAiConfigured.mockReturnValue(false);
  });

  it('liest Preis und Verfügbarkeit aus JSON-LD ohne KI', async () => {
    mocks.fetchProductPage.mockResolvedValue(page(jsonLdPage));
    const r = await readCompetitorPage({
      url: 'https://store.example.net/item',
      productName: 'Mühle',
    });
    expect(mocks.assertPublicHttpTarget).toHaveBeenCalledWith('https://store.example.net/item');
    expect(r).toMatchObject({
      status: 'observed',
      priceValue: '12.99',
      currency: 'EUR',
      availability: 'InStock',
      priceStatus: 'observed',
      checkedAt: '2026-10-19T12:00:00.000Z',
    });
    expect(mocks.generateObject).not.toHaveBeenCalled();
  });

  it('ohne strukturierte Daten und ohne KI-Schlüssel: no_data, keine KI', async () => {
    mocks.fetchProductPage.mockResolvedValue(page('<html><body>Preis 12,99 €</body></html>'));
    const r = await readCompetitorPage({ url: 'https://store.example.net/item', productName: 'X' });
    expect(r.status).toBe('no_data');
    expect(r.priceValue).toBeNull();
    expect(mocks.generateObject).not.toHaveBeenCalled();
  });

  it('mit KI-Schlüssel: Fallback mit belegtem Zitat', async () => {
    mocks.isAiConfigured.mockReturnValue(true);
    mocks.generateObject.mockResolvedValue({ priceQuotes: ['Preis 12,99 €'] });
    mocks.fetchProductPage.mockResolvedValue(
      page('<html><body><p>Preis 12,99 €</p></body></html>'),
    );
    const r = await readCompetitorPage({ url: 'https://store.example.net/item', productName: 'X' });
    expect(mocks.generateObject).toHaveBeenCalledOnce();
    expect(r).toMatchObject({ priceValue: '12.99', currency: 'EUR' });
  });

  it('KI-Zitat, das nicht im Text steht, wird verworfen', async () => {
    mocks.isAiConfigured.mockReturnValue(true);
    mocks.generateObject.mockResolvedValue({ priceQuotes: ['Preis 9,99 €'] });
    mocks.fetchProductPage.mockResolvedValue(
      page('<html><body><p>Preis 12,99 €</p></body></html>'),
    );
    const r = await readCompetitorPage({ url: 'https://store.example.net/item', productName: 'X' });
    expect(r.priceValue).toBeNull();
  });

  it('nicht öffentliches Ziel → invalid_target', async () => {
    mocks.assertPublicHttpTarget.mockRejectedValue(new InvalidPublicHttpTargetError());
    const r = await readCompetitorPage({ url: 'http://127.0.0.1/', productName: 'X' });
    expect(r.status).toBe('invalid_target');
    expect(mocks.fetchProductPage).not.toHaveBeenCalled();
  });

  it('HTTP-Fehler → unreadable mit Statuscode', async () => {
    mocks.fetchProductPage.mockRejectedValue(new PageFetchError('http_error', 'HTTP 403', 403));
    const r = await readCompetitorPage({ url: 'https://store.example.net/item', productName: 'X' });
    expect(r).toMatchObject({ status: 'unreadable', errorCode: 'page_http_403' });
  });

  it('widersprüchliche strukturierte Preise → inconsistent', async () => {
    mocks.fetchProductPage.mockResolvedValue(
      page(
        '<script type="application/ld+json">{"@type":"Product","offers":[{"@type":"Offer","price":"10","priceCurrency":"EUR"},{"@type":"Offer","price":"12","priceCurrency":"EUR"}]}</script>',
      ),
    );
    const r = await readCompetitorPage({ url: 'https://store.example.net/item', productName: 'X' });
    expect(r.status).toBe('inconsistent');
    expect(r.priceValue).toBeNull();
  });
});
