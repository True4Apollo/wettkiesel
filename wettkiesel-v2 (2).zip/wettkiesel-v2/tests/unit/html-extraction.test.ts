import { describe, expect, it } from 'vitest';
import {
  extractStructuredProductData,
  htmlToText,
  normalizeAvailability,
  normalizePrice,
} from '@/lib/business/html-extraction';

describe('normalizePrice', () => {
  it.each([
    ['19.99', '19.99'],
    ['19,99', '19.99'],
    ['1.299,00', '1299'],
    ['1,299.50', '1299.5'],
    ['1.299', '1.299'], // strukturierte Daten: Punkt = Dezimaltrenner
    ['€ 24,90', '24.9'],
    [49, '49'],
  ])('%s → %s', (input, expected) => {
    expect(normalizePrice(input)).toBe(expected);
  });
  it('lehnt Unsinn ab', () => {
    expect(normalizePrice('kostenlos')).toBeNull();
    expect(normalizePrice(undefined)).toBeNull();
  });
});

describe('normalizeAvailability', () => {
  it.each([
    ['https://schema.org/InStock', 'InStock'],
    ['http://schema.org/OutOfStock', 'OutOfStock'],
    ['schema:PreOrder', 'PreOrder'],
    ['instock', 'InStock'],
    ['out of stock', 'OutOfStock'],
  ])('%s → %s', (input, expected) => {
    expect(normalizeAvailability(input)).toBe(expected);
  });
  it('unbekannt → null', () => {
    expect(normalizeAvailability('vielleicht')).toBeNull();
  });
});

describe('extractStructuredProductData', () => {
  it('liest JSON-LD Product/Offer', () => {
    const html = `<html><head><script type="application/ld+json">${JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'Product',
      name: 'Mühle',
      offers: {
        '@type': 'Offer',
        price: '229.00',
        priceCurrency: 'EUR',
        availability: 'https://schema.org/InStock',
      },
    })}</script></head></html>`;
    const r = extractStructuredProductData(html);
    expect(r.price).toMatchObject({ value: '229', currency: 'EUR', source: 'json-ld' });
    expect(r.availability?.availability).toBe('InStock');
    expect(r.priceConflict).toBe(false);
  });

  it('liest JSON-LD in @graph und AggregateOffer.lowPrice', () => {
    const html = `<script type="application/ld+json">{"@context":"https://schema.org","@graph":[{"@type":"WebPage"},{"@type":"Product","offers":{"@type":"AggregateOffer","lowPrice":19.9,"priceCurrency":"EUR"}}]}</script>`;
    expect(extractStructuredProductData(html).price?.value).toBe('19.9');
  });

  it('ignoriert kaputtes JSON-LD und nutzt Microdata', () => {
    const html = `<script type="application/ld+json">{kaputt</script>
      <div itemscope itemtype="https://schema.org/Product">
        <span itemprop="price" content="34.90">34,90 €</span>
        <meta itemprop="priceCurrency" content="EUR">
        <link itemprop="availability" href="https://schema.org/OutOfStock">
      </div>`;
    const r = extractStructuredProductData(html);
    expect(r.price).toMatchObject({ value: '34.9', currency: 'EUR', source: 'microdata' });
    expect(r.availability?.availability).toBe('OutOfStock');
  });

  it('liest OpenGraph/Meta-Preise', () => {
    const html = `<meta property="product:price:amount" content="12,50">
      <meta property="product:price:currency" content="EUR">
      <meta property="product:availability" content="instock">`;
    const r = extractStructuredProductData(html);
    expect(r.price).toMatchObject({ value: '12.5', currency: 'EUR', source: 'meta' });
    expect(r.availability?.availability).toBe('InStock');
  });

  it('JSON-LD hat Vorrang vor Meta', () => {
    const html = `<meta property="product:price:amount" content="99"><meta property="product:price:currency" content="EUR">
      <script type="application/ld+json">{"@type":"Product","offers":{"@type":"Offer","price":"89","priceCurrency":"EUR"}}</script>`;
    expect(extractStructuredProductData(html).price?.value).toBe('89');
  });

  it('meldet widersprüchliche Preise statt zu raten', () => {
    const html = `<script type="application/ld+json">{"@type":"Product","offers":[{"@type":"Offer","price":"10","priceCurrency":"EUR"},{"@type":"Offer","price":"12","priceCurrency":"EUR"}]}</script>`;
    const r = extractStructuredProductData(html);
    expect(r.price).toBeNull();
    expect(r.priceConflict).toBe(true);
  });

  it('ohne Währung kein Preis', () => {
    const html = `<script type="application/ld+json">{"@type":"Product","offers":{"@type":"Offer","price":"10"}}</script>`;
    expect(extractStructuredProductData(html).price).toBeNull();
  });

  it('leere Seite → nichts', () => {
    const r = extractStructuredProductData('<html><body>Hallo</body></html>');
    expect(r.price).toBeNull();
    expect(r.availability).toBeNull();
  });
});

describe('htmlToText', () => {
  it('entfernt Skripte und dekodiert Entities', () => {
    const r = htmlToText(
      '<title>Tamper &amp; Co</title><script>x()</script><p>Preis: 34,90&nbsp;&euro;</p>',
    );
    expect(r.title).toBe('Tamper & Co');
    expect(r.text).toContain('Preis: 34,90 €');
    expect(r.text).not.toContain('x()');
  });
});
