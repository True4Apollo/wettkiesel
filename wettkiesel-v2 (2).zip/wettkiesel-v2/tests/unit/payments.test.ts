import { afterEach, describe, expect, it } from 'vitest';
import { checkoutHref } from '@/lib/payments';

const KEYS = ['STRIPE_SECRET_KEY', 'STRIPE_PRICE_SHOP', 'STRIPE_LINK_SHOP'];
afterEach(() => {
  for (const k of KEYS) delete process.env[k];
});

describe('checkoutHref', () => {
  it('ohne Konfiguration: kein Bezahl-Button', () => {
    expect(checkoutHref('shop')).toBeNull();
  });
  it('Payment Link wird genutzt, wenn gültig', () => {
    process.env.STRIPE_LINK_SHOP = 'https://buy.stripe.com/test_123';
    expect(checkoutHref('shop')).toBe('https://buy.stripe.com/test_123');
  });
  it('ungültiger Link wird ignoriert', () => {
    process.env.STRIPE_LINK_SHOP = 'https://evil.example/pay';
    expect(checkoutHref('shop')).toBeNull();
  });
  it('Checkout hat Vorrang, wenn Secret + Preis-ID gesetzt', () => {
    process.env.STRIPE_SECRET_KEY = 'sk_test_x';
    process.env.STRIPE_PRICE_SHOP = 'price_123';
    process.env.STRIPE_LINK_SHOP = 'https://buy.stripe.com/test_123';
    expect(checkoutHref('shop')).toBe('/api/checkout?tarif=shop');
  });
  it('Preis-ID ohne Secret zählt nicht', () => {
    process.env.STRIPE_PRICE_SHOP = 'price_123';
    expect(checkoutHref('shop')).toBeNull();
  });
});
