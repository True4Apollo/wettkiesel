import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  requireAuth: vi.fn(),
  productFindMany: vi.fn(),
  measurementFindMany: vi.fn(),
}));

vi.mock('server-only', () => ({}));
vi.mock('@/lib/require-auth', () => ({ requireAuth: mocks.requireAuth }));
vi.mock('@/lib/db', () => ({
  prisma: {
    shopProduct: { findMany: mocks.productFindMany },
    competitorCheckMeasurement: { findMany: mocks.measurementFindMany },
  },
}));

import { GET } from '@/app/api/shop/daily-market-report/route';

describe('Shop-Tagesbericht', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.productFindMany.mockResolvedValue([{ id: 'product-1', name: 'Eigenes Produkt' }]);
    mocks.requireAuth.mockResolvedValue({ id: 'owner-1' });
  });

  it('weist anonyme Aufrufe ab, bevor Shop- oder Messdaten gelesen werden', async () => {
    mocks.requireAuth.mockRejectedValue(Response.json({ error: 'Unauthorized' }, { status: 401 }));

    const response = await GET(new Request('https://app.example/api/shop/daily-market-report'));

    expect(response.status).toBe(401);
    expect(mocks.productFindMany).not.toHaveBeenCalled();
    expect(mocks.measurementFindMany).not.toHaveBeenCalled();
  });

  it('fragt nur Produkte des Sitzungsinhabers ab und ignoriert fremde Owner-Parameter', async () => {
    mocks.measurementFindMany
      .mockResolvedValueOnce([
        {
          id: 'current-measurement',
          competitorUrl: 'https://shop.example/item',
          status: 'observed',
          priceValue: '12.00',
          currency: 'EUR',
          availability: 'InStock',
          checkedAt: new Date('2026-10-15T10:00:00.000Z'),
          run: { productId: 'product-1' },
        },
      ])
      .mockResolvedValueOnce([
        {
          id: 'previous-measurement',
          competitorUrl: 'https://shop.example/item',
          status: 'observed',
          priceValue: '10.00',
          currency: 'EUR',
          availability: 'InStock',
          checkedAt: new Date('2026-10-14T10:00:00.000Z'),
          run: { productId: 'product-1' },
        },
      ]);

    const response = await GET(
      new Request(
        'https://app.example/api/shop/daily-market-report?date=2026-10-15&userId=owner-2',
      ),
    );

    expect(response.status).toBe(200);
    expect(mocks.productFindMany).toHaveBeenCalledWith({
      where: { userId: 'owner-1', isArchived: false },
      select: { id: true, name: true },
    });
    expect(mocks.measurementFindMany).toHaveBeenCalledTimes(2);
    for (const call of mocks.measurementFindMany.mock.calls) {
      expect(call[0].where.run).toEqual({ productId: { in: ['product-1'] } });
    }
    await expect(response.json()).resolves.toMatchObject({
      date: '2026-10-15',
      changes: [
        {
          productId: 'product-1',
          productHref: '/admin/products/product-1',
          competitorUrl: 'https://shop.example/item',
          price: { previousValue: '10.00', currentValue: '12.00', currency: 'EUR' },
        },
      ],
    });
  });
});
