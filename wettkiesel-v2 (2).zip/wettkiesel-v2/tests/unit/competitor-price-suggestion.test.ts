import { describe, expect, it } from 'vitest';
import { selectCompetitorPriceSuggestion } from '@/lib/business/competitor-price-suggestion';
import type { CompetitorCheckRun, CompetitorMeasurement } from '@/lib/contracts/competitor-checks';

const checkedAt = '2026-10-15T10:30:00.000Z';
const firstUrl = 'https://shop.example/first';
const secondUrl = 'https://shop.example/second';

function measurement(overrides: Partial<CompetitorMeasurement> = {}): CompetitorMeasurement {
  return {
    id: 'measurement-1',
    targetType: 'competitor',
    competitorUrl: firstUrl,
    status: 'observed',
    priceValue: '42.50',
    currency: 'EUR',
    priceStatus: 'observed',
    priceErrorCode: null,
    priceErrorMessage: null,
    availability: null,
    priceEvidence: null,
    availabilityEvidence: null,
    errorCode: null,
    errorMessage: null,
    checkedAt,
    attemptedAt: checkedAt,
    sourceCached: false,
    ...overrides,
  };
}

function run(...measurements: CompetitorMeasurement[]): CompetitorCheckRun {
  return {
    id: 'run-1',
    status: 'completed',
    startedAt: checkedAt,
    completedAt: checkedAt,
    measurements,
  };
}

describe('selectCompetitorPriceSuggestion', () => {
  it('nimmt den niedrigsten passenden Messwert und begrenzt ihn auf beide Preisgrenzen', () => {
    const result = selectCompetitorPriceSuggestion({
      competitorUrls: [firstUrl, secondUrl],
      minPriceCents: 3000,
      maxPriceCents: 4000,
      runs: [
        run(
          measurement({ id: 'higher', priceValue: '55.00', competitorUrl: firstUrl }),
          measurement({ id: 'lowest', priceValue: '24.99', competitorUrl: secondUrl }),
          measurement({ id: 'own', targetType: 'own', priceValue: '10.00' }),
        ),
      ],
    });

    expect(result).toEqual({
      priceCents: 3000,
      currency: 'EUR',
      observation: {
        measurementId: 'lowest',
        competitorUrl: secondUrl,
        priceValue: '24.99',
        checkedAt,
      },
    });

    const upperBound = selectCompetitorPriceSuggestion({
      competitorUrls: [firstUrl],
      minPriceCents: 3000,
      maxPriceCents: 4000,
      runs: [run(measurement({ priceValue: '55.00' }))],
    });
    expect(upperBound?.priceCents).toBe(4000);
  });

  it('liefert bei ungültigen Preisgrenzen oder fehlender passender Messung keinen Vorschlag', () => {
    const validRuns = [run(measurement())];
    expect(
      selectCompetitorPriceSuggestion({
        competitorUrls: [firstUrl],
        minPriceCents: 0,
        maxPriceCents: 4000,
        runs: validRuns,
      }),
    ).toBeNull();
    expect(
      selectCompetitorPriceSuggestion({
        competitorUrls: [firstUrl],
        minPriceCents: 5000,
        maxPriceCents: 4000,
        runs: validRuns,
      }),
    ).toBeNull();
    expect(
      selectCompetitorPriceSuggestion({
        competitorUrls: [secondUrl],
        minPriceCents: 3000,
        maxPriceCents: 4000,
        runs: validRuns,
      }),
    ).toBeNull();
  });

  it('ignoriert nicht belegte, ungültige und nicht in Euro gemessene Preise', () => {
    const result = selectCompetitorPriceSuggestion({
      competitorUrls: [firstUrl],
      minPriceCents: 3000,
      maxPriceCents: 4000,
      runs: [
        run(
          measurement({ id: 'not-observed', priceStatus: 'not_checked' }),
          measurement({ id: 'other-currency', currency: 'USD', priceValue: '2.00' }),
          measurement({ id: 'missing-time', checkedAt: null }),
          measurement({ id: 'bad-price', priceValue: 'not-a-price' }),
        ),
      ],
    });
    expect(result).toBeNull();
  });
});
