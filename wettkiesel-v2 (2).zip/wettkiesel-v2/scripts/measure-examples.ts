// Misst echte öffentliche Produktseiten mit dem Wettkiesel-Extraktor.
// Aufruf: npx tsx scripts/measure-examples.ts <urls.json> <out.json>
import { readFileSync, writeFileSync } from 'node:fs';
import { extractStructuredProductData } from '../src/lib/business/html-extraction';

type Item = { product: string; shop: string; url: string };
const UA = 'Mozilla/5.0 (compatible; WettkieselBot/1.0; +https://wettkiesel.onrender.com)';

(async () => {
  const [, , input, output] = process.argv;
  const items: Item[] = JSON.parse(readFileSync(input as string, 'utf8'));
  const results = [];
  for (const it of items) {
    const measuredAt = new Date().toISOString();
    try {
      const res = await fetch(it.url, { headers: { 'user-agent': UA, 'accept-language': 'de-DE' }, signal: AbortSignal.timeout(25000) });
      const html = await res.text();
      const x = extractStructuredProductData(html);
      results.push({ ...it, measuredAt, httpStatus: res.status, price: x.price?.value ?? null, currency: x.price?.currency ?? null, priceSource: x.price?.source ?? null, availability: x.availability?.availability ?? null, priceConflict: x.priceConflict, availabilityConflict: x.availabilityConflict });
    } catch (e) {
      results.push({ ...it, measuredAt, httpStatus: null, error: String((e as Error).name) });
    }
    console.log(JSON.stringify(results.at(-1)));
  }
  writeFileSync(output as string, JSON.stringify(results, null, 2));
})();
