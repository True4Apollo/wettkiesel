-- CreateTable
CREATE TABLE "ShopProduct" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "ownUrl" TEXT NOT NULL,
    "competitorUrls" TEXT[],
    "minPriceCents" INTEGER NOT NULL,
    "maxPriceCents" INTEGER NOT NULL,
    "isArchived" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ShopProduct_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CompetitorCheckRun" (
    "id" TEXT NOT NULL,
    "productId" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'running',
    "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completedAt" TIMESTAMP(3),

    CONSTRAINT "CompetitorCheckRun_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CompetitorCheckMeasurement" (
    "id" TEXT NOT NULL,
    "runId" TEXT NOT NULL,
    "targetType" TEXT NOT NULL DEFAULT 'competitor',
    "competitorUrl" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "priceValue" TEXT,
    "currency" TEXT,
    "priceStatus" TEXT,
    "priceErrorCode" TEXT,
    "priceErrorMessage" TEXT,
    "availability" TEXT,
    "priceEvidence" TEXT,
    "availabilityEvidence" TEXT,
    "errorCode" TEXT,
    "errorMessage" TEXT,
    "checkedAt" TIMESTAMP(3),
    "attemptedAt" TIMESTAMP(3),
    "sourceCached" BOOLEAN,
    "processingAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "CompetitorCheckMeasurement_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CompetitorCheckDailySchedule" (
    "id" TEXT NOT NULL,
    "productId" TEXT NOT NULL,
    "runId" TEXT NOT NULL,
    "dateKey" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "CompetitorCheckDailySchedule_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ShopMarketReport" (
    "id" TEXT NOT NULL,
    "productId" TEXT NOT NULL,
    "dateKey" TEXT NOT NULL,
    "report" JSONB NOT NULL,
    "generatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ShopMarketReport_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ShopMarketReportFeedback" (
    "id" TEXT NOT NULL,
    "reportId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "isUseful" BOOLEAN NOT NULL,
    "reason" VARCHAR(300),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ShopMarketReportFeedback_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "ShopProduct_userId_updatedAt_idx" ON "ShopProduct"("userId", "updatedAt");

-- CreateIndex
CREATE INDEX "CompetitorCheckRun_productId_startedAt_idx" ON "CompetitorCheckRun"("productId", "startedAt");

-- CreateIndex
CREATE INDEX "CompetitorCheckMeasurement_runId_createdAt_idx" ON "CompetitorCheckMeasurement"("runId", "createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "CompetitorCheckDailySchedule_runId_key" ON "CompetitorCheckDailySchedule"("runId");

-- CreateIndex
CREATE INDEX "CompetitorCheckDailySchedule_dateKey_idx" ON "CompetitorCheckDailySchedule"("dateKey");

-- CreateIndex
CREATE UNIQUE INDEX "CompetitorCheckDailySchedule_productId_dateKey_key" ON "CompetitorCheckDailySchedule"("productId", "dateKey");

-- CreateIndex
CREATE INDEX "ShopMarketReport_productId_dateKey_idx" ON "ShopMarketReport"("productId", "dateKey");

-- CreateIndex
CREATE UNIQUE INDEX "ShopMarketReport_productId_dateKey_key" ON "ShopMarketReport"("productId", "dateKey");

-- CreateIndex
CREATE INDEX "ShopMarketReportFeedback_userId_idx" ON "ShopMarketReportFeedback"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "ShopMarketReportFeedback_reportId_userId_key" ON "ShopMarketReportFeedback"("reportId", "userId");

-- AddForeignKey
ALTER TABLE "CompetitorCheckRun" ADD CONSTRAINT "CompetitorCheckRun_productId_fkey" FOREIGN KEY ("productId") REFERENCES "ShopProduct"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CompetitorCheckMeasurement" ADD CONSTRAINT "CompetitorCheckMeasurement_runId_fkey" FOREIGN KEY ("runId") REFERENCES "CompetitorCheckRun"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CompetitorCheckDailySchedule" ADD CONSTRAINT "CompetitorCheckDailySchedule_productId_fkey" FOREIGN KEY ("productId") REFERENCES "ShopProduct"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CompetitorCheckDailySchedule" ADD CONSTRAINT "CompetitorCheckDailySchedule_runId_fkey" FOREIGN KEY ("runId") REFERENCES "CompetitorCheckRun"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ShopMarketReport" ADD CONSTRAINT "ShopMarketReport_productId_fkey" FOREIGN KEY ("productId") REFERENCES "ShopProduct"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ShopMarketReportFeedback" ADD CONSTRAINT "ShopMarketReportFeedback_reportId_fkey" FOREIGN KEY ("reportId") REFERENCES "ShopMarketReport"("id") ON DELETE CASCADE ON UPDATE CASCADE;
