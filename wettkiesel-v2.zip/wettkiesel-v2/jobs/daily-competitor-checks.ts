// @polsia:user-owned — scheduled entrypoint for daily saved-URL measurements.
import { refreshDailyCompetitorChecks } from '@/lib/business/daily-competitor-checks';

refreshDailyCompetitorChecks().then(
  () => process.exit(0),
  (error: unknown) => {
    const kind = error instanceof Error ? error.name : 'UnknownError';
    process.stderr.write(`daily-competitor-checks failed: ${kind}\n`);
    process.exit(1);
  },
);
