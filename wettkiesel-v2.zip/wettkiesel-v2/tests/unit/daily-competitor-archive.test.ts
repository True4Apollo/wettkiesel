import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  productFindMany: vi.fn(),
  scheduleFindMany: vi.fn(),
  measurementFindMany: vi.fn(),
  measurementUpdateMany: vi.fn(),
  runUpdateMany: vi.fn(),
  transaction: vi.fn(),
  runBatch: vi.fn(),
}));

vi.mock('server-only', () => ({}));
vi.mock('@/lib/db', () => ({
  prisma: {
    shopProduct: { findMany: mocks.productFindMany },
    competitorCheckDailySchedule: { findMany: mocks.scheduleFindMany },
    competitorCheckMeasurement: {
      findMany: mocks.measurementFindMany,
      updateMany: mocks.measurementUpdateMany,
    },
    competitorCheckRun: { updateMany: mocks.runUpdateMany },
    $transaction: mocks.transaction,
  },
}));
vi.mock('@/lib/business/competitor-check-persistence', () => ({
  persistCompetitorMeasurement: vi.fn(),
}));
vi.mock('@/lib/business/competitor-page-reader', () => ({ readCompetitorPage: vi.fn() }));
vi.mock('@/modules/web-search/client', () => ({
  QuotaExceededError: class extends Error {},
  runBatch: mocks.runBatch,
  WebSearchConfigurationError: class extends Error {},
  WebSearchError: class extends Error {},
  WebSearchNotEnabledError: class extends Error {},
}));

import { refreshDailyCompetitorChecks } from '@/lib/business/daily-competitor-checks';

describe('daily competitor archive filtering', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.productFindMany.mockResolvedValue([]);
    mocks.scheduleFindMany.mockResolvedValue([]);
    mocks.measurementFindMany.mockResolvedValue([]);
    mocks.runBatch.mockImplementation(async (items: unknown[]) => ({
      done: items.length,
      failed: 0,
      skipped: 0,
    }));
  });

  it('excludes archived products from new schedules and resumed daily work', async () => {
    const now = new Date('2026-10-14T12:00:00.000Z');

    const result = await refreshDailyCompetitorChecks(now);

    expect(mocks.productFindMany).toHaveBeenCalledWith({
      where: { isArchived: false },
      select: { id: true, ownUrl: true, competitorUrls: true },
    });
    expect(mocks.scheduleFindMany).toHaveBeenCalledWith({
      where: { dateKey: { lt: '2026-10-14' }, product: { isArchived: false } },
      select: { runId: true },
    });
    expect(mocks.scheduleFindMany).toHaveBeenLastCalledWith({
      where: { dateKey: '2026-10-14', product: { isArchived: false } },
      select: { runId: true },
    });
    expect(mocks.transaction).not.toHaveBeenCalled();
    expect(result.schedules.done).toBe(0);
    expect(result.checks.done).toBe(0);
  });
});
