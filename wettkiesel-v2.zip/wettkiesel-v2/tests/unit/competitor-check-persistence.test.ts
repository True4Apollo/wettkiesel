import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => {
  const measurementUpdate = vi.fn(async () => ({ id: 'measurement-1' }));
  const measurementCount = vi.fn(async () => 0);
  const runUpdate = vi.fn(async () => ({ status: 'completed' }));
  const transactionClient = {
    competitorCheckMeasurement: { update: measurementUpdate, count: measurementCount },
    competitorCheckRun: { update: runUpdate },
  };
  return {
    measurementUpdate,
    measurementCount,
    runUpdate,
    transaction: vi.fn(
      async (operation: (client: typeof transactionClient) => Promise<unknown>) =>
        operation(transactionClient),
    ),
  };
});

vi.mock('server-only', () => ({}));
vi.mock('@/lib/db', () => ({ prisma: { $transaction: mocks.transaction } }));

import { persistCompetitorMeasurement } from '@/lib/business/competitor-check-persistence';

describe('Persistenz blockierter Wettbewerberziele', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('speichert den Prüfversuch terminal als invalid_target ohne Messwerte oder Messzeit', async () => {
    const attemptedAt = new Date('2026-10-14T12:00:00.000Z');
    const result = await persistCompetitorMeasurement({
      measurementId: 'measurement-1',
      runId: 'run-1',
      attemptedAt,
      result: {
        status: 'invalid_target',
        priceValue: '99.99',
        currency: 'EUR',
        priceStatus: 'not_checked',
        priceErrorCode: null,
        priceErrorMessage: null,
        availability: 'InStock',
        priceEvidence: 'Preis 99,99 €',
        availabilityEvidence: 'https://schema.org/InStock',
        errorCode: 'invalid_public_target',
        errorMessage: 'Das Ziel ist nicht öffentlich erreichbar.',
        checkedAt: '2026-10-14T12:01:00.000Z',
        sourceCached: true,
      },
    });

    expect(mocks.measurementUpdate).toHaveBeenCalledWith({
      where: { id: 'measurement-1' },
      data: expect.objectContaining({
        status: 'invalid_target',
        priceValue: null,
        currency: null,
        availability: null,
        priceEvidence: null,
        availabilityEvidence: null,
        checkedAt: null,
        attemptedAt,
        sourceCached: null,
        processingAt: null,
        errorCode: 'invalid_public_target',
      }),
    });
    expect(result.runStatus).toBe('completed');
    expect(mocks.runUpdate).toHaveBeenCalledWith({
      where: { id: 'run-1' },
      data: { status: 'completed', completedAt: expect.any(Date) },
    });
  });

  it('speichert Größen- und Zeitüberschreitungen ohne erfolgreiche Preis- oder Verfügbarkeitswerte', async () => {
    const attemptedAt = new Date('2026-10-14T12:00:00.000Z');
    const failures = [
      {
        errorCode: 'page_too_large',
        errorMessage: 'Die Wettbewerberseite überschritt das Größenlimit.',
      },
      {
        errorCode: 'page_read_timeout',
        errorMessage: 'Die Wettbewerberseite antwortete nicht innerhalb von 30 Sekunden.',
      },
    ] as const;

    for (const [index, failure] of failures.entries()) {
      const result = await persistCompetitorMeasurement({
        measurementId: `measurement-${index + 1}`,
        runId: 'run-1',
        attemptedAt,
        result: {
          status: 'error',
          priceValue: '99.99',
          currency: 'EUR',
          priceStatus: 'not_checked',
          priceErrorCode: null,
          priceErrorMessage: null,
          availability: 'InStock',
          priceEvidence: 'Preis 99,99 €',
          availabilityEvidence: 'https://schema.org/InStock',
          ...failure,
          checkedAt: null,
          sourceCached: null,
        },
      });

      expect(result.runStatus).toBe('completed');
      expect(mocks.measurementUpdate).toHaveBeenNthCalledWith(
        index + 1,
        expect.objectContaining({
          where: { id: `measurement-${index + 1}` },
          data: expect.objectContaining({
            status: 'error',
            priceValue: null,
            currency: null,
            availability: null,
            priceEvidence: null,
            availabilityEvidence: null,
            errorCode: failure.errorCode,
            errorMessage: failure.errorMessage,
            attemptedAt,
            processingAt: null,
          }),
        }),
      );
    }
  });

  it('speichert den fehlenden Preisfehler getrennt und erhält eine belegte Verfügbarkeit', async () => {
    const attemptedAt = new Date('2026-10-14T12:00:00.000Z');
    const result = await persistCompetitorMeasurement({
      measurementId: 'measurement-1',
      runId: 'run-1',
      attemptedAt,
      result: {
        status: 'partial',
        priceValue: null,
        currency: null,
        priceStatus: 'unreadable',
        priceErrorCode: 'price_unreadable',
        priceErrorMessage: 'Preis nicht auslesbar: Im Seitentext wurde kein Preis gefunden.',
        availability: 'InStock',
        priceEvidence: null,
        availabilityEvidence: 'https://schema.org/InStock',
        errorCode: 'price_unreadable',
        errorMessage: 'Preis nicht auslesbar: Im Seitentext wurde kein Preis gefunden.',
        checkedAt: '2026-10-14T12:01:00.000Z',
        sourceCached: false,
      },
    });

    expect(mocks.measurementUpdate).toHaveBeenCalledWith({
      where: { id: 'measurement-1' },
      data: expect.objectContaining({
        status: 'partial',
        priceValue: null,
        currency: null,
        priceStatus: 'unreadable',
        priceErrorCode: 'price_unreadable',
        priceErrorMessage: expect.stringContaining('Preis nicht auslesbar'),
        availability: 'InStock',
        availabilityEvidence: 'https://schema.org/InStock',
        errorCode: 'price_unreadable',
        attemptedAt,
      }),
    });
    expect(result.runStatus).toBe('completed');
  });

  it('speichert unbekannte Verfügbarkeit zusammen mit dem Messzeitpunkt', async () => {
    const attemptedAt = new Date('2026-10-14T12:00:00.000Z');
    const checkedAt = '2026-10-14T12:01:00.000Z';
    await persistCompetitorMeasurement({
      measurementId: 'measurement-unknown',
      runId: 'run-1',
      attemptedAt,
      result: {
        status: 'partial',
        priceValue: '12.99',
        currency: 'EUR',
        priceStatus: 'observed',
        priceErrorCode: null,
        priceErrorMessage: null,
        availability: null,
        priceEvidence: '12,99 EUR',
        availabilityEvidence: null,
        errorCode: null,
        errorMessage: null,
        checkedAt,
        sourceCached: false,
      },
    });

    expect(mocks.measurementUpdate).toHaveBeenCalledWith({
      where: { id: 'measurement-unknown' },
      data: expect.objectContaining({
        availability: null,
        checkedAt: new Date(checkedAt),
        attemptedAt,
      }),
    });
  });
});
