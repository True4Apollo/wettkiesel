import { describe, expect, it } from 'vitest';
import { toCompetitorMeasurement } from '@/lib/business/competitor-check-wire';

const measurement = {
  id: 'measurement-1',
  targetType: 'competitor',
  competitorUrl: 'https://store.example.net/item',
  status: 'partial',
  priceValue: '12.99',
  currency: 'EUR',
  priceStatus: 'observed',
  priceErrorCode: null,
  priceErrorMessage: null,
  availability: 'InStock',
  priceEvidence: '12,99 EUR',
  availabilityEvidence: 'https://schema.org/InStock',
  errorCode: null,
  errorMessage: null,
  checkedAt: new Date('2026-10-14T12:01:00.000Z'),
  attemptedAt: new Date('2026-10-14T12:00:00.000Z'),
  sourceCached: false,
};

describe('Validierung gespeicherter Wettbewerbermessungen beim Auslesen', () => {
  it('gibt einen gespeicherten Schema.org-Status zurück', () => {
    expect(toCompetitorMeasurement(measurement)).toMatchObject({
      availability: 'InStock',
      availabilityEvidence: 'https://schema.org/InStock',
      checkedAt: '2026-10-14T12:01:00.000Z',
    });
  });

  it('gibt einen ungültigen nichtleeren Altwert nicht als Status aus', () => {
    expect(
      toCompetitorMeasurement({
        ...measurement,
        availability: 'Auf Lager',
        availabilityEvidence: 'Auf Lager',
      }),
    ).toMatchObject({ availability: null, availabilityEvidence: null });
  });
});
