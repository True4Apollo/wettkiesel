import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => {
  const transactionClient = {
    shopProduct: { findFirst: vi.fn(async () => ({ id: 'product-1' })) },
    competitorCheckDailySchedule: {
      findUnique: vi.fn(async () => null),
      create: vi.fn(async () => ({ runId: 'run-1' })),
    },
    competitorCheckRun: {
      create: vi.fn(async () => ({ id: 'run-1' })),
      update: vi.fn(async () => ({ id: 'run-1' })),
    },
    competitorCheckMeasurement: { createMany: vi.fn(async () => ({ count: 1 })) },
  };

  return {
    transactionClient,
    productFindMany: vi.fn(),
    scheduleFindMany: vi.fn(),
    measurementFindMany: vi.fn(),
    measurementUpdateMany: vi.fn(),
    measurementCreateMany: vi.fn(async () => ({ count: 1 })),
    runUpdate: vi.fn(async () => ({ id: 'run-1' })),
    runUpdateMany: vi.fn(async () => ({ count: 1 })),
    persistCompetitorMeasurement: vi.fn(),
    readCompetitorPage: vi.fn(),
    runBatch: vi.fn(),
    transaction: vi.fn(),
  };
});

vi.mock('server-only', () => ({}));
vi.mock('@/lib/db', () => ({
  prisma: {
    shopProduct: { findMany: mocks.productFindMany },
    competitorCheckDailySchedule: {
      findMany: mocks.scheduleFindMany,
      findUnique: mocks.transactionClient.competitorCheckDailySchedule.findUnique,
      create: mocks.transactionClient.competitorCheckDailySchedule.create,
    },
    competitorCheckMeasurement: {
      findMany: mocks.measurementFindMany,
      updateMany: mocks.measurementUpdateMany,
      createMany: mocks.measurementCreateMany,
    },
    competitorCheckRun: {
      updateMany: mocks.runUpdateMany,
      create: mocks.transactionClient.competitorCheckRun.create,
      update: mocks.runUpdate,
    },
    $transaction: mocks.transaction,
  },
}));
vi.mock('@/lib/business/competitor-check-persistence', () => ({
  persistCompetitorMeasurement: mocks.persistCompetitorMeasurement,
}));
vi.mock('@/lib/business/competitor-page-reader', () => ({
  readCompetitorPage: mocks.readCompetitorPage,
}));
vi.mock('@/modules/web-search/client', () => ({
  QuotaExceededError: class extends Error {},
  runBatch: mocks.runBatch,
  WebSearchConfigurationError: class extends Error {},
  WebSearchError: class extends Error {},
  WebSearchNotEnabledError: class extends Error {},
}));

import { refreshDailyCompetitorChecks } from '@/lib/business/daily-competitor-checks';

describe('Täglicher Wettbewerberabruf bei blockiertem Weiterleitungsziel', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.productFindMany.mockResolvedValue([
      { id: 'product-1', ownUrl: 'https://shop.example.net/item', competitorUrls: [] },
    ]);
    mocks.scheduleFindMany.mockResolvedValueOnce([]).mockResolvedValueOnce([{ runId: 'run-1' }]);
    mocks.measurementFindMany.mockResolvedValueOnce([]).mockResolvedValueOnce([
      {
        id: 'measurement-1',
        runId: 'run-1',
        targetType: 'own',
        competitorUrl: 'https://shop.example.net/item',
        status: 'pending',
        attemptedAt: null,
        createdAt: new Date('2026-10-14T00:00:00.000Z'),
        run: { id: 'run-1', product: { name: 'Produkt' } },
      },
    ]);
    mocks.measurementUpdateMany.mockResolvedValue({ count: 1 });
    mocks.readCompetitorPage.mockResolvedValue({
      status: 'invalid_target',
      priceValue: null,
      currency: null,
      availability: null,
      priceEvidence: null,
      availabilityEvidence: null,
      errorCode: 'invalid_public_target',
      errorMessage: 'Das Ziel ist nicht öffentlich erreichbar.',
      checkedAt: null,
      sourceCached: null,
    });
    mocks.persistCompetitorMeasurement.mockResolvedValue({
      measurement: { id: 'measurement-1', status: 'invalid_target' },
      runStatus: 'completed',
    });
    mocks.runBatch.mockImplementation(
      async (items: unknown[], handler: (item: unknown) => Promise<unknown>) => {
        for (const item of items) await handler(item);
        return { done: items.length, failed: 0, skipped: 0 };
      },
    );
    mocks.transaction.mockImplementation(async (operation: unknown) => {
      if (Array.isArray(operation)) return Promise.all(operation);
      if (typeof operation === 'function') {
        return operation(mocks.transactionClient);
      }
      throw new Error('Unexpected transaction shape');
    });
  });

  it('speichert das blockierte Ziel über den täglichen Verlauf ohne Messdaten', async () => {
    await refreshDailyCompetitorChecks(new Date('2026-10-14T12:00:00.000Z'));

    expect(mocks.readCompetitorPage).toHaveBeenCalledWith({
      url: 'https://shop.example.net/item',
      productName: 'Produkt',
      targetType: 'own',
    });
    expect(mocks.transactionClient.competitorCheckRun.create).toHaveBeenCalledWith({
      data: {
        productId: 'product-1',
        measurements: {
          create: [{ targetType: 'own', competitorUrl: 'https://shop.example.net/item' }],
        },
      },
    });
    expect(mocks.persistCompetitorMeasurement).toHaveBeenCalledWith({
      measurementId: 'measurement-1',
      runId: 'run-1',
      attemptedAt: expect.any(Date),
      result: expect.objectContaining({
        status: 'invalid_target',
        priceValue: null,
        currency: null,
        availability: null,
        priceEvidence: null,
        availabilityEvidence: null,
        checkedAt: null,
      }),
    });
  });

  it('setzt die geplante URL-Prüfrunde nach einem begrenzten Seitenfehler mit der nächsten URL fort', async () => {
    mocks.measurementFindMany.mockReset();
    mocks.productFindMany.mockResolvedValue([
      {
        id: 'product-1',
        ownUrl: 'https://shop.example.net/own-product',
        competitorUrls: ['https://shop.example.net/slow-item', 'https://shop.example.net/next-item'],
      },
    ]);
    mocks.measurementFindMany
      .mockResolvedValueOnce([
        { targetType: 'own', competitorUrl: 'https://shop.example.net/own-product' },
        { targetType: 'competitor', competitorUrl: 'https://shop.example.net/slow-item' },
        { targetType: 'competitor', competitorUrl: 'https://shop.example.net/next-item' },
      ])
      .mockResolvedValueOnce([
        {
          id: 'measurement-own',
          runId: 'run-1',
          targetType: 'own',
          competitorUrl: 'https://shop.example.net/own-product',
          status: 'pending',
          attemptedAt: null,
          createdAt: new Date('2026-10-14T00:00:00.000Z'),
          run: { id: 'run-1', product: { name: 'Produkt' } },
        },
        {
          id: 'measurement-1',
          runId: 'run-1',
          targetType: 'competitor',
          competitorUrl: 'https://shop.example.net/slow-item',
          status: 'pending',
          attemptedAt: null,
          createdAt: new Date('2026-10-14T00:00:00.000Z'),
          run: { id: 'run-1', product: { name: 'Produkt' } },
        },
        {
          id: 'measurement-2',
          runId: 'run-1',
          targetType: 'competitor',
          competitorUrl: 'https://shop.example.net/next-item',
          status: 'pending',
          attemptedAt: null,
          createdAt: new Date('2026-10-14T00:01:00.000Z'),
          run: { id: 'run-1', product: { name: 'Produkt' } },
        },
      ]);
    mocks.readCompetitorPage
      .mockResolvedValueOnce({
        status: 'observed',
        priceValue: '89.00',
        currency: 'EUR',
        availability: null,
        priceEvidence: '89,00 €',
        availabilityEvidence: null,
        errorCode: null,
        errorMessage: null,
        checkedAt: '2026-10-14T11:59:00.000Z',
        sourceCached: false,
      })
      .mockResolvedValueOnce({
        status: 'error',
        priceValue: null,
        currency: null,
        availability: null,
        priceEvidence: null,
        availabilityEvidence: null,
        errorCode: 'page_too_large',
        errorMessage: 'Die Wettbewerberseite überschritt das Größenlimit.',
        checkedAt: '2026-10-14T12:00:00.000Z',
        sourceCached: false,
      })
      .mockResolvedValueOnce({
        status: 'observed',
        priceValue: '12.99',
        currency: 'EUR',
        availability: 'InStock',
        priceEvidence: 'Preis 12,99 €',
        availabilityEvidence: 'https://schema.org/InStock',
        errorCode: null,
        errorMessage: null,
        checkedAt: '2026-10-14T12:01:00.000Z',
        sourceCached: false,
      });
    mocks.persistCompetitorMeasurement.mockResolvedValue({ measurement: {}, runStatus: 'running' });

    await refreshDailyCompetitorChecks(new Date('2026-10-14T12:00:00.000Z'));

    expect(mocks.readCompetitorPage.mock.calls.map(([input]) => input.url)).toEqual([
      'https://shop.example.net/own-product',
      'https://shop.example.net/slow-item',
      'https://shop.example.net/next-item',
    ]);
    expect(mocks.persistCompetitorMeasurement).toHaveBeenCalledTimes(3);
    expect(mocks.persistCompetitorMeasurement).toHaveBeenNthCalledWith(
      1,
      expect.objectContaining({
        measurementId: 'measurement-own',
        result: expect.objectContaining({ status: 'observed', priceValue: '89.00' }),
      }),
    );
    expect(mocks.persistCompetitorMeasurement).toHaveBeenNthCalledWith(
      2,
      expect.objectContaining({
        measurementId: 'measurement-1',
        result: expect.objectContaining({ status: 'error', errorCode: 'page_too_large' }),
      }),
    );
    expect(mocks.persistCompetitorMeasurement).toHaveBeenNthCalledWith(
      3,
      expect.objectContaining({
        measurementId: 'measurement-2',
        result: expect.objectContaining({ status: 'observed', priceValue: '12.99' }),
      }),
    );
    expect(mocks.runUpdateMany).toHaveBeenCalledWith({
      where: expect.objectContaining({
        id: { in: ['run-1'] },
        measurements: { none: { status: { in: ['pending', 'processing'] } } },
      }),
      data: { status: 'completed', completedAt: expect.any(Date) },
    });
  });
});
