import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  authorizeProductAdmin: vi.fn(),
}));

vi.mock('server-only', () => ({}));
vi.mock('@/lib/business/product-admin-auth', () => ({
  authorizeProductAdmin: mocks.authorizeProductAdmin,
}));

import { POST } from '@/app/api/admin/products/[productId]/price-change/route';

describe('Shoppreisänderungen ohne Plattform-Zugangsdaten', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.authorizeProductAdmin.mockResolvedValue({ ok: true, userId: 'owner-1' });
  });

  it('weist die Preisänderung zurück und meldet beide fehlenden Voraussetzungen', async () => {
    const response = await POST(new Request('https://app.example/api/price-change'), {
      params: Promise.resolve({ productId: 'product-1' }),
    });

    expect(response.status).toBe(403);
    await expect(response.json()).resolves.toMatchObject({
      error: 'price_changes_disabled',
      reasons: ['shop_platform_not_connected', 'operator_api_credentials_missing'],
      message: expect.stringContaining('Preisänderungen bleiben gesperrt'),
    });
  });
});
