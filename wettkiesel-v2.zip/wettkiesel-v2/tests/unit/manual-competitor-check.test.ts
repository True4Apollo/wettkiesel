import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  authorizeProductAdmin: vi.fn(),
  measurementFindFirst: vi.fn(),
  measurementUpdateMany: vi.fn(),
  readCompetitorPage: vi.fn(),
  persistCompetitorMeasurement: vi.fn(),
}));

vi.mock('server-only', () => ({}));
vi.mock('@/lib/business/product-admin-auth', () => ({
  authorizeProductAdmin: mocks.authorizeProductAdmin,
}));
vi.mock('@/lib/db', () => ({
  prisma: {
    competitorCheckMeasurement: {
      findFirst: mocks.measurementFindFirst,
      updateMany: mocks.measurementUpdateMany,
    },
  },
}));
vi.mock('@/lib/business/competitor-page-reader', () => ({
  readCompetitorPage: mocks.readCompetitorPage,
}));
vi.mock('@/lib/business/competitor-check-persistence', () => ({
  persistCompetitorMeasurement: mocks.persistCompetitorMeasurement,
}));

import { POST } from '@/app/api/admin/products/[productId]/competitor-checks/[measurementId]/route';

describe('Manuelle Wettbewerberprüfung', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.authorizeProductAdmin.mockResolvedValue({ ok: true, userId: 'owner-1' });
    mocks.measurementFindFirst.mockResolvedValue({
      id: 'measurement-1',
      targetType: 'competitor',
      competitorUrl: 'https://shop.example.net/item',
      status: 'pending',
      run: {
        id: 'run-1',
        product: { name: 'Produkt', isArchived: false },
      },
    });
    mocks.measurementUpdateMany.mockResolvedValue({ count: 1 });
    mocks.readCompetitorPage.mockResolvedValue({
      status: 'observed',
      priceValue: '12.99',
      currency: 'EUR',
      priceStatus: 'observed',
      priceErrorCode: null,
      priceErrorMessage: null,
      availability: 'InStock',
      priceEvidence: 'Preis 12,99 €',
      availabilityEvidence: 'https://schema.org/InStock',
      errorCode: null,
      errorMessage: null,
      checkedAt: '2026-10-14T12:00:00.000Z',
      sourceCached: false,
    });
    mocks.persistCompetitorMeasurement.mockResolvedValue({
      measurement: {
        id: 'measurement-1',
        targetType: 'competitor',
        competitorUrl: 'https://shop.example.net/item',
        status: 'observed',
        priceValue: '12.99',
        currency: 'EUR',
        priceStatus: 'observed',
        priceErrorCode: null,
        priceErrorMessage: null,
        availability: 'InStock',
        priceEvidence: 'Preis 12,99 €',
        availabilityEvidence: 'https://schema.org/InStock',
        errorCode: null,
        errorMessage: null,
        checkedAt: new Date('2026-10-14T12:00:00.000Z'),
        attemptedAt: new Date('2026-10-14T11:59:00.000Z'),
        sourceCached: false,
      },
      runStatus: 'completed',
    });
  });

  it('übergibt die gespeicherte öffentliche URL an den vorhandenen Abruf und liefert den Verlaufseintrag', async () => {
    const response = await POST(new Request('https://app.example/api/check'), {
      params: Promise.resolve({ productId: 'product-1', measurementId: 'measurement-1' }),
    });
    const body: unknown = await response.json();

    expect(response.status).toBe(200);
    expect(mocks.readCompetitorPage).toHaveBeenCalledWith({
      url: 'https://shop.example.net/item',
      productName: 'Produkt',
      targetType: 'competitor',
    });
    expect(body).toMatchObject({
      measurement: {
        status: 'observed',
        priceValue: '12.99',
        priceStatus: 'observed',
        availability: 'InStock',
      },
      runStatus: 'completed',
    });
  });

  it('misst die gespeicherte eigene Produkt-URL und behält Preis, Währung und Messzeitpunkt', async () => {
    const checkedAt = '2026-10-14T12:34:56.000Z';
    mocks.measurementFindFirst.mockResolvedValue({
      id: 'measurement-own',
      targetType: 'own',
      competitorUrl: 'https://store.example.net/products/item',
      status: 'pending',
      run: { id: 'run-1', product: { name: 'Produkt', isArchived: false } },
    });
    mocks.readCompetitorPage.mockResolvedValue({
      status: 'observed',
      priceValue: '42.50',
      currency: 'EUR',
      priceStatus: 'observed',
      priceErrorCode: null,
      priceErrorMessage: null,
      availability: null,
      priceEvidence: '42,50 €',
      availabilityEvidence: null,
      errorCode: null,
      errorMessage: null,
      checkedAt,
      sourceCached: false,
    });
    mocks.persistCompetitorMeasurement.mockResolvedValue({
      measurement: {
        id: 'measurement-own',
        targetType: 'own',
        competitorUrl: 'https://store.example.net/products/item',
        status: 'observed',
        priceValue: '42.50',
        currency: 'EUR',
        priceStatus: 'observed',
        priceErrorCode: null,
        priceErrorMessage: null,
        availability: null,
        priceEvidence: '42,50 €',
        availabilityEvidence: null,
        errorCode: null,
        errorMessage: null,
        checkedAt: new Date(checkedAt),
        attemptedAt: new Date('2026-10-14T12:34:00.000Z'),
        sourceCached: false,
      },
      runStatus: 'completed',
    });

    const response = await POST(new Request('https://app.example/api/check'), {
      params: Promise.resolve({ productId: 'product-1', measurementId: 'measurement-own' }),
    });
    const body: unknown = await response.json();

    expect(response.status).toBe(200);
    expect(mocks.readCompetitorPage).toHaveBeenCalledWith({
      url: 'https://store.example.net/products/item',
      productName: 'Produkt',
      targetType: 'own',
    });
    expect(body).toMatchObject({
      measurement: {
        targetType: 'own',
        priceValue: '42.50',
        currency: 'EUR',
        checkedAt,
      },
      runStatus: 'completed',
    });
  });

  it('liefert einen nicht auslesbaren Preis mit gültigem Verfügbarkeitsbeleg in der API zurück', async () => {
    const priceErrorMessage =
      'Preis nicht auslesbar: Die gefundenen Textstellen belegen keinen eindeutigen Betrag.';
    mocks.readCompetitorPage.mockResolvedValue({
      status: 'partial',
      priceValue: null,
      currency: null,
      priceStatus: 'unreadable',
      priceErrorCode: 'price_unreadable',
      priceErrorMessage,
      availability: 'InStock',
      priceEvidence: '$579.99',
      availabilityEvidence: 'https://schema.org/InStock',
      errorCode: 'price_unreadable',
      errorMessage: priceErrorMessage,
      checkedAt: '2026-10-14T12:00:00.000Z',
      sourceCached: false,
    });
    mocks.persistCompetitorMeasurement.mockResolvedValue({
      measurement: {
        id: 'measurement-1',
        competitorUrl: 'https://shop.example.net/item',
        status: 'partial',
        priceValue: null,
        currency: null,
        priceStatus: 'unreadable',
        priceErrorCode: 'price_unreadable',
        priceErrorMessage,
        availability: 'InStock',
        priceEvidence: '$579.99',
        availabilityEvidence: 'https://schema.org/InStock',
        errorCode: 'price_unreadable',
        errorMessage: priceErrorMessage,
        checkedAt: new Date('2026-10-14T12:00:00.000Z'),
        attemptedAt: new Date('2026-10-14T11:59:00.000Z'),
        sourceCached: false,
      },
      runStatus: 'completed',
    });

    const response = await POST(new Request('https://app.example/api/check'), {
      params: Promise.resolve({ productId: 'product-1', measurementId: 'measurement-1' }),
    });

    expect(response.status).toBe(200);
    await expect(response.json()).resolves.toMatchObject({
      measurement: {
        priceValue: null,
        currency: null,
        priceStatus: 'unreadable',
        priceErrorCode: 'price_unreadable',
        priceErrorMessage,
        availability: 'InStock',
        availabilityEvidence: 'https://schema.org/InStock',
      },
    });
  });

  it('liefert ein blockiertes Weiterleitungsziel als fehlgeschlagene Messung ohne Beobachtung zurück', async () => {
    mocks.readCompetitorPage.mockResolvedValue({
      status: 'invalid_target',
      priceValue: null,
      currency: null,
      priceStatus: 'not_checked',
      priceErrorCode: null,
      priceErrorMessage: null,
      availability: null,
      priceEvidence: null,
      availabilityEvidence: null,
      errorCode: 'invalid_public_target',
      errorMessage: 'Das Ziel ist nicht öffentlich erreichbar.',
      checkedAt: null,
      sourceCached: null,
    });
    mocks.persistCompetitorMeasurement.mockResolvedValue({
      measurement: {
        id: 'measurement-1',
        competitorUrl: 'https://shop.example.net/item',
        status: 'invalid_target',
        priceValue: null,
        currency: null,
        priceStatus: 'not_checked',
        priceErrorCode: null,
        priceErrorMessage: null,
        availability: null,
        priceEvidence: null,
        availabilityEvidence: null,
        errorCode: 'invalid_public_target',
        errorMessage: 'Das Ziel ist nicht öffentlich erreichbar.',
        checkedAt: null,
        attemptedAt: new Date('2026-10-14T11:59:00.000Z'),
        sourceCached: null,
      },
      runStatus: 'completed',
    });

    const response = await POST(new Request('https://app.example/api/check'), {
      params: Promise.resolve({ productId: 'product-1', measurementId: 'measurement-1' }),
    });
    const body: unknown = await response.json();

    expect(response.status).toBe(200);
    expect(mocks.persistCompetitorMeasurement).toHaveBeenCalledWith({
      measurementId: 'measurement-1',
      runId: 'run-1',
      attemptedAt: expect.any(Date),
      result: expect.objectContaining({
        status: 'invalid_target',
        priceValue: null,
        availability: null,
        priceEvidence: null,
        availabilityEvidence: null,
        checkedAt: null,
      }),
    });
    expect(body).toMatchObject({
      measurement: {
        status: 'invalid_target',
        priceValue: null,
        availability: null,
        priceEvidence: null,
        availabilityEvidence: null,
        checkedAt: null,
      },
      runStatus: 'completed',
    });
  });

  it('speichert eine begrenzte Abruffehlmessung als Abschluss des manuellen URL-Schritts', async () => {
    mocks.readCompetitorPage.mockResolvedValue({
      status: 'error',
      priceValue: null,
      currency: null,
      priceStatus: 'not_checked',
      priceErrorCode: null,
      priceErrorMessage: null,
      availability: null,
      priceEvidence: null,
      availabilityEvidence: null,
      errorCode: 'page_read_timeout',
      errorMessage: 'Die Wettbewerberseite antwortete nicht innerhalb von 30 Sekunden.',
      checkedAt: null,
      sourceCached: null,
    });
    mocks.persistCompetitorMeasurement.mockResolvedValue({
      measurement: {
        id: 'measurement-1',
        competitorUrl: 'https://shop.example.net/item',
        status: 'error',
        priceValue: null,
        currency: null,
        priceStatus: 'not_checked',
        priceErrorCode: null,
        priceErrorMessage: null,
        availability: null,
        priceEvidence: null,
        availabilityEvidence: null,
        errorCode: 'page_read_timeout',
        errorMessage: 'Die Wettbewerberseite antwortete nicht innerhalb von 30 Sekunden.',
        checkedAt: new Date('2026-10-14T12:00:00.000Z'),
        attemptedAt: new Date('2026-10-14T12:00:00.000Z'),
        sourceCached: null,
      },
      runStatus: 'completed',
    });

    const response = await POST(new Request('https://app.example/api/check'), {
      params: Promise.resolve({ productId: 'product-1', measurementId: 'measurement-1' }),
    });
    const body: unknown = await response.json();

    expect(response.status).toBe(200);
    expect(mocks.persistCompetitorMeasurement).toHaveBeenCalledWith({
      measurementId: 'measurement-1',
      runId: 'run-1',
      attemptedAt: expect.any(Date),
      result: expect.objectContaining({ status: 'error', errorCode: 'page_read_timeout' }),
    });
    expect(body).toMatchObject({
      measurement: {
        status: 'error',
        priceValue: null,
        availability: null,
        errorCode: 'page_read_timeout',
      },
      runStatus: 'completed',
    });
  });
});
