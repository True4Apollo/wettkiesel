import { describe, expect, it } from 'vitest';
import {
  parseCompetitorExtraction,
  parseSchemaAvailability,
} from '@/lib/business/competitor-extraction';

const jsonLd = (availability: string) =>
  `<script type="application/ld+json">{"@context":"https://schema.org","@type":"Product","offers":{"@type":"Offer","availability":"https://schema.org/${availability}"}}</script>`;

describe('Schema.org-Verfügbarkeit aus Wettbewerberseiten', () => {
  it('erkennt einen eindeutigen Status aus JSON-LD und Microdata', () => {
    expect(parseSchemaAvailability(jsonLd('InStock'))).toMatchObject({
      availability: 'InStock',
      evidence: 'https://schema.org/InStock',
      conflicting: false,
    });
    expect(
      parseSchemaAvailability(
        '<link itemprop="availability" href="https://schema.org/OutOfStock">',
      ),
    ).toMatchObject({ availability: 'OutOfStock', conflicting: false });
  });

  it('lässt fehlende strukturierte Angaben ausdrücklich unbekannt', () => {
    expect(parseSchemaAvailability('Produktseite: In stock, sofort lieferbar')).toEqual({
      availability: null,
      evidence: null,
      conflicting: false,
    });
  });

  it('lässt widersprüchliche strukturierte Angaben ausdrücklich unbekannt', () => {
    const source = `${jsonLd('InStock')}<link itemprop="availability" href="https://schema.org/OutOfStock">`;
    expect(parseSchemaAvailability(source)).toMatchObject({
      availability: null,
      conflicting: true,
    });
    expect(
      parseCompetitorExtraction('19,99 EUR', { priceQuotes: ['19,99 EUR'] }),
    ).toMatchObject({ status: 'partial', availability: null });
    expect(
      parseCompetitorExtraction(`${source}19,99 EUR`, { priceQuotes: ['19,99 EUR'] }),
    ).toMatchObject({
      status: 'inconsistent',
      availability: null,
      errorCode: 'conflicting_signals',
    });
  });

  it('speichert den erkannten Schema.org-Status statt eines Textzitats', () => {
    const source = `Preis 1.299,00 EUR ${jsonLd('InStock')}`;
    const result = parseCompetitorExtraction(source, { priceQuotes: ['1.299,00 EUR'] });

    expect(result).toMatchObject({
      status: 'observed',
      priceValue: '1299',
      currency: 'EUR',
      availability: 'InStock',
      availabilityEvidence: 'https://schema.org/InStock',
    });
  });
});

describe('Auswertung öffentlicher Preisangaben', () => {
  it('weist einen fehlenden Preis als nicht auslesbar aus und speichert keinen Ersatzwert', () => {
    const result = parseCompetitorExtraction('Produktseite ohne Preis oder Lagerstatus', {
      priceQuotes: [],
    });

    expect(result).toMatchObject({
      status: 'no_data',
      priceValue: null,
      currency: null,
      priceStatus: 'unreadable',
      priceErrorCode: 'price_unreadable',
      priceErrorMessage: expect.stringContaining('Preis nicht auslesbar'),
      availability: null,
      errorCode: 'price_unreadable',
    });
  });

  it('speichert keinen Preis ohne eindeutig belegte Währung und keinen Textstatus als Verfügbarkeit', () => {
    const source = '$579.99 · In stock';
    const result = parseCompetitorExtraction(source, { priceQuotes: ['$579.99'] });

    expect(result).toMatchObject({
      status: 'no_data',
      priceValue: null,
      currency: null,
      priceStatus: 'unreadable',
      priceErrorCode: 'price_unreadable',
      priceErrorMessage: expect.stringContaining('bestimmbarer Währung'),
      availability: null,
      priceEvidence: '$579.99',
    });
  });

  it('übernimmt ungültige oder nicht im Seitentext belegte Preiswerte nicht', () => {
    const source = '"price":"NaN EUR"';
    const result = parseCompetitorExtraction(source, {
      priceQuotes: [source, '99,99 EUR'],
    });

    expect(result).toMatchObject({
      status: 'no_data',
      priceValue: null,
      currency: null,
      priceStatus: 'unreadable',
      priceErrorCode: 'price_unreadable',
      priceEvidence: null,
    });
  });

  it('markiert mehrere belegte Preisangaben als widersprüchlich', () => {
    const source = 'Aktuell 19,99 EUR, vorher 24,99 EUR';
    const result = parseCompetitorExtraction(source, {
      priceQuotes: ['19,99 EUR', '24,99 EUR'],
    });

    expect(result).toMatchObject({
      status: 'inconsistent',
      priceValue: null,
      priceStatus: 'unreadable',
      priceErrorCode: 'conflicting_prices',
      errorCode: 'conflicting_signals',
    });
  });

  it('bewahrt einen eindeutigen Verfügbarkeitsstatus trotz widersprüchlicher Preise', () => {
    const source = `19,99 EUR · vorher 24,99 EUR ${jsonLd('InStock')}`;
    const result = parseCompetitorExtraction(source, {
      priceQuotes: ['19,99 EUR', '24,99 EUR'],
    });

    expect(result).toMatchObject({
      status: 'inconsistent',
      priceValue: null,
      priceStatus: 'unreadable',
      priceErrorCode: 'conflicting_prices',
      availability: 'InStock',
      availabilityEvidence: 'https://schema.org/InStock',
    });
  });
});
