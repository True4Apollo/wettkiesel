// @polsia:user-owned
import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  requireAuth: vi.fn(),
  productCreate: vi.fn(),
  getShopProductOverview: vi.fn(),
}));

vi.mock('server-only', () => ({}));
vi.mock('@/lib/require-auth', () => ({ requireAuth: mocks.requireAuth }));
vi.mock('@/lib/db', () => ({ prisma: { shopProduct: { create: mocks.productCreate } } }));
vi.mock('@/lib/business/shop-product-overview', () => ({
  getShopProductOverview: mocks.getShopProductOverview,
}));

import { POST } from '@/app/api/shop/products/route';

const input = {
  name: 'Erstes Produkt',
  ownUrl: 'https://shop.example.net/produkt',
  competitorUrls: ['https://wettbewerb.example.net/produkt'],
  minPrice: 19.99,
  maxPrice: 29.99,
};

function productWithCompetitorUrl(url: string) {
  return {
    id: 'product-1',
    isArchived: false,
    name: input.name,
    ownUrl: input.ownUrl,
    competitorUrls: [url],
    minPriceCents: 1999,
    maxPriceCents: 2999,
    createdAt: new Date('2026-10-15T10:00:00.000Z'),
    updatedAt: new Date('2026-10-15T10:00:00.000Z'),
  };
}

describe('Shop-Produktanlage', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.requireAuth.mockResolvedValue({ id: 'shop-user-1' });
    mocks.productCreate.mockImplementation(
      async ({ data }: { data: { competitorUrls: string[] } }) =>
        productWithCompetitorUrl(data.competitorUrls[0] ?? ''),
    );
  });

  it('weist eine ungültige Wettbewerber-URL ohne Produktanlage ab', async () => {
    const response = await POST(
      new Request('https://app.example/api/shop/products', {
        method: 'POST',
        body: JSON.stringify({ ...input, competitorUrls: ['ftp://wettbewerb.example.net/produkt'] }),
      }),
    );

    expect(response.status).toBe(400);
    await expect(response.json()).resolves.toMatchObject({
      errors: { competitorUrls: expect.stringContaining('HTTP- oder HTTPS-Adresse') },
    });
    expect(mocks.productCreate).not.toHaveBeenCalled();
  });

  it.each([
    'http://wettbewerb.example.net/produkt',
    'https://wettbewerb.example.net/produkt',
    'HTTP://wettbewerb.example.net/produkt',
    'HTTPS://wettbewerb.example.net/produkt',
  ])(
    'speichert eine gültige Wettbewerber-URL %s',
    async (url) => {
      const response = await POST(
        new Request('https://app.example/api/shop/products', {
          method: 'POST',
          body: JSON.stringify({ ...input, competitorUrls: [url] }),
        }),
      );

      expect(response.status).toBe(201);
      expect(mocks.productCreate).toHaveBeenCalledWith({
        data: expect.objectContaining({ competitorUrls: [url] }),
      });
      await expect(response.json()).resolves.toMatchObject({ item: { competitorUrls: [url] } });
    },
  );
});
