// @polsia:user-owned — verifies chart data comes only from saved competitor price observations.
import { describe, expect, it } from 'vitest';
import type { CompetitorCheckRun, CompetitorMeasurement } from '@/lib/contracts/competitor-checks';
import { selectCompetitorPriceHistory } from '@/lib/business/competitor-price-history';

function measurement(
  overrides: Partial<CompetitorMeasurement> & Pick<CompetitorMeasurement, 'id' | 'competitorUrl'>,
): CompetitorMeasurement {
  return {
    targetType: 'competitor',
    status: 'observed',
    priceValue: '19.90',
    currency: 'EUR',
    priceStatus: 'observed',
    priceErrorCode: null,
    priceErrorMessage: null,
    availability: null,
    priceEvidence: null,
    availabilityEvidence: null,
    errorCode: null,
    errorMessage: null,
    checkedAt: '2026-10-01T10:00:00.000Z',
    attemptedAt: null,
    sourceCached: false,
    ...overrides,
  };
}

function run(id: string, measurements: CompetitorMeasurement[]): CompetitorCheckRun {
  return {
    id,
    status: 'completed',
    startedAt: '2026-10-01T10:00:00.000Z',
    completedAt: '2026-10-01T10:01:00.000Z',
    measurements,
  };
}

describe('selectCompetitorPriceHistory', () => {
  it('ordnet gespeicherte Wettbewerberpreise nach Messdatum und erhält Datum sowie Preiswert', () => {
    const older = measurement({
      id: 'older',
      competitorUrl: 'https://shop.example/product',
      checkedAt: '2026-09-20T10:00:00.000Z',
      priceValue: '25.50',
    });
    const newer = measurement({
      id: 'newer',
      competitorUrl: 'https://shop.example/product',
      checkedAt: '2026-10-01T10:00:00.000Z',
      priceValue: '23.90',
    });
    const secondCompetitor = measurement({
      id: 'other',
      competitorUrl: 'https://other.example/item',
      checkedAt: '2026-09-25T10:00:00.000Z',
      priceValue: '31.00',
    });

    const result = selectCompetitorPriceHistory([
      run('new-run', [newer, secondCompetitor]),
      run('old-run', [older]),
    ]);

    expect(result).toHaveLength(2);
    expect(result[0]).toMatchObject({
      competitorUrl: 'https://other.example/item',
      points: [{ id: 'other', checkedAt: secondCompetitor.checkedAt, priceValue: '31.00' }],
    });
    expect(result[1]).toMatchObject({
      competitorUrl: 'https://shop.example/product',
      points: [
        { id: 'older', checkedAt: older.checkedAt, priceValue: '25.50' },
        { id: 'newer', checkedAt: newer.checkedAt, priceValue: '23.90' },
      ],
    });
  });

  it('schließt Eigenpreise, nicht beobachtete, undatierte oder ungültige Preise aus', () => {
    const result = selectCompetitorPriceHistory([
      run('run', [
        measurement({ id: 'own', competitorUrl: 'https://shop.example/product', targetType: 'own' }),
        measurement({
          id: 'pending',
          competitorUrl: 'https://shop.example/product',
          priceStatus: 'not_checked',
        }),
        measurement({ id: 'undated', competitorUrl: 'https://shop.example/product', checkedAt: null }),
        measurement({ id: 'invalid', competitorUrl: 'https://shop.example/product', priceValue: 'unbekannt' }),
        measurement({ id: 'non-decimal', competitorUrl: 'https://shop.example/product', priceValue: '0x10' }),
      ]),
    ]);

    expect(result).toEqual([]);
  });

  it('liefert ohne gespeicherte Preis-Messungen keine Serien', () => {
    expect(selectCompetitorPriceHistory([])).toEqual([]);
    expect(
      selectCompetitorPriceHistory([
        run('empty', [
          measurement({
            id: 'no-price',
            competitorUrl: 'https://shop.example/product',
            priceValue: null,
            priceStatus: 'not_checked',
          }),
        ]),
      ]),
    ).toEqual([]);
  });
});
