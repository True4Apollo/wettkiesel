import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  authorizeProductAdmin: vi.fn(),
  productFindFirst: vi.fn(),
  runFindMany: vi.fn(),
  runCreate: vi.fn(),
}));

vi.mock('server-only', () => ({}));
vi.mock('@/lib/business/product-admin-auth', () => ({
  authorizeProductAdmin: mocks.authorizeProductAdmin,
}));
vi.mock('@/lib/db', () => ({
  prisma: {
    shopProduct: { findFirst: mocks.productFindFirst },
    competitorCheckRun: { findMany: mocks.runFindMany, create: mocks.runCreate },
  },
}));

import { GET, POST } from '@/app/api/admin/products/[productId]/competitor-checks/route';

describe('Manuelle Prüfrunde des eigenen Produkts', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.authorizeProductAdmin.mockResolvedValue({ ok: true, userId: 'owner-1' });
    mocks.productFindFirst.mockResolvedValue({
      id: 'product-1',
      isArchived: false,
      ownUrl: 'https://store.example.net/products/item',
      competitorUrls: [],
    });
    mocks.runCreate.mockResolvedValue({
      id: 'run-1',
      status: 'running',
      startedAt: new Date('2026-10-14T12:00:00.000Z'),
      completedAt: null,
      measurements: [
        {
          id: 'measurement-own',
          targetType: 'own',
          competitorUrl: 'https://store.example.net/products/item',
          status: 'pending',
          priceValue: null,
          currency: null,
          priceStatus: 'not_checked',
          priceErrorCode: null,
          priceErrorMessage: null,
          availability: null,
          priceEvidence: null,
          availabilityEvidence: null,
          errorCode: null,
          errorMessage: null,
          checkedAt: null,
          attemptedAt: null,
          sourceCached: null,
        },
      ],
    });
  });

  it('startet die Messung der gespeicherten Produkt-URL auch ohne Wettbewerber', async () => {
    const response = await POST(new Request('https://app.example/api/check'), {
      params: Promise.resolve({ productId: 'product-1' }),
    });
    const body: unknown = await response.json();

    expect(response.status).toBe(201);
    expect(mocks.runCreate).toHaveBeenCalledWith({
      data: {
        productId: 'product-1',
        measurements: {
          create: [
            { targetType: 'own', competitorUrl: 'https://store.example.net/products/item' },
          ],
        },
      },
      include: { measurements: { orderBy: { createdAt: 'asc' } } },
    });
    expect(body).toMatchObject({
      run: { measurements: [{ targetType: 'own', competitorUrl: 'https://store.example.net/products/item' }] },
    });
  });

  it('liefert den gespeicherten Eigenpreis, seine Währung und seinen Messzeitpunkt im geschützten Verlauf', async () => {
    const checkedAt = new Date('2026-10-14T12:00:00.000Z');
    mocks.productFindFirst.mockResolvedValue({
      id: 'product-1',
      ownUrl: 'https://store.example.net/products/item',
    });
    mocks.runFindMany.mockResolvedValue([
      {
        id: 'run-1',
        status: 'completed',
        startedAt: new Date('2026-10-14T11:59:00.000Z'),
        completedAt: checkedAt,
        measurements: [
          {
            id: 'own-measurement',
            targetType: 'own',
            competitorUrl: 'https://store.example.net/products/item',
            status: 'observed',
            priceValue: '31.25',
            currency: 'EUR',
            priceStatus: 'observed',
            priceErrorCode: null,
            priceErrorMessage: null,
            availability: null,
            priceEvidence: '31,25 €',
            availabilityEvidence: null,
            errorCode: null,
            errorMessage: null,
            checkedAt,
            attemptedAt: checkedAt,
            sourceCached: false,
            processingAt: null,
            createdAt: checkedAt,
            runId: 'run-1',
          },
        ],
      },
    ]);

    const response = await GET(new Request('https://app.example/api/check'), {
      params: Promise.resolve({ productId: 'product-1' }),
    });
    const body: unknown = await response.json();

    expect(response.status).toBe(200);
    expect(mocks.productFindFirst).toHaveBeenCalledWith({
      where: { id: 'product-1', userId: 'owner-1' },
      select: { id: true, ownUrl: true },
    });
    expect(mocks.runFindMany).toHaveBeenCalledWith({
      where: { productId: 'product-1' },
      orderBy: { startedAt: 'desc' },
      include: { measurements: { orderBy: { createdAt: 'asc' } } },
    });
    expect(body).toMatchObject({
      ownUrl: 'https://store.example.net/products/item',
      runs: [
        {
          measurements: [
            {
              id: 'own-measurement',
              targetType: 'own',
              priceValue: '31.25',
              currency: 'EUR',
              checkedAt: '2026-10-14T12:00:00.000Z',
            },
          ],
        },
      ],
    });
  });
});
