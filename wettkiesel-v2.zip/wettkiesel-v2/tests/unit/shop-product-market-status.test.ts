// @polsia:user-owned — focused tests for consecutive saved competitor readings.
import { describe, expect, it } from 'vitest';
import {
  summarizeShopProductMarketStatus,
  type ShopProductObservation,
} from '@/lib/business/shop-product-market-status';

const competitorUrl = 'https://rival.example/item';
const older = '2024-01-01T10:00:00.000Z';
const recent = '2026-10-15T10:00:00.000Z';

function observation(
  id: string,
  checkedAt: string,
  changes: Partial<ShopProductObservation> = {},
): ShopProductObservation {
  return {
    id,
    targetType: 'competitor',
    competitorUrl,
    status: 'observed',
    checkedAt,
    createdAt: checkedAt,
    priceValue: '10.00',
    currency: 'EUR',
    priceStatus: 'observed',
    availability: 'InStock',
    ...changes,
  };
}

function summarize(
  measurements: ShopProductObservation[],
  competitorUrls: string[] = [competitorUrl],
) {
  return summarizeShopProductMarketStatus(competitorUrls, measurements);
}

describe('Wettbewerber-Preisstatus', () => {
  it('meldet unveränderten Preis bei zwei passenden Beobachtungen', () => {
    const status = summarize([observation('new', recent), observation('old', older)]);

    expect(status.priceChange).toEqual({ changed: false, comparedCompetitors: 1 });
  });

  it('erkennt eine Preisänderung desselben Wettbewerbers', () => {
    const status = summarize([
      observation('new', recent, { priceValue: '12.00' }),
      observation('old', older, { priceValue: '10.00' }),
    ]);

    expect(status.priceChange).toEqual({ changed: true, comparedCompetitors: 1 });
  });

  it('behauptet bei fehlendem neuesten Preis keine Änderung und überspringt ihn nicht', () => {
    const status = summarize([
      observation('new', recent, { priceValue: null, priceStatus: 'unreadable' }),
      observation('middle', older, { priceValue: '10.00' }),
      observation('old', '2023-01-01T10:00:00.000Z', { priceValue: '9.00' }),
    ]);

    expect(status.priceChange).toEqual({ changed: null, comparedCompetitors: 0 });
  });

  it('vergleicht auch bei großem Zeitabstand', () => {
    const status = summarize([
      observation('new', recent, { priceValue: '12.00' }),
      observation('old', '2020-01-01T10:00:00.000Z', { priceValue: '10.00' }),
    ]);

    expect(status.priceChange).toEqual({ changed: true, comparedCompetitors: 1 });
  });

  it('vergleicht Preise nicht zwischen verschiedenen Wettbewerbern', () => {
    const status = summarize([
      observation('first', recent, { competitorUrl: 'https://rival.example/first' }),
      observation('second', older, { competitorUrl: 'https://rival.example/second' }),
    ], ['https://rival.example/first', 'https://rival.example/second']);

    expect(status.priceChange).toEqual({ changed: null, comparedCompetitors: 0 });
  });
});

describe('Wettbewerber-Verfügbarkeitsstatus', () => {
  it('meldet unveränderte Verfügbarkeit bei zwei passenden Beobachtungen', () => {
    const status = summarize([observation('new', recent), observation('old', older)]);

    expect(status.availabilityChange).toEqual({ changed: false, comparedCompetitors: 1 });
  });

  it('erkennt eine Verfügbarkeitsänderung desselben Wettbewerbers', () => {
    const status = summarize([
      observation('new', recent, { availability: 'OutOfStock' }),
      observation('old', older, { availability: 'InStock' }),
    ]);

    expect(status.availabilityChange).toEqual({ changed: true, comparedCompetitors: 1 });
  });

  it('behauptet bei fehlender neuester Verfügbarkeit keine Änderung und überspringt sie nicht', () => {
    const status = summarize([
      observation('new', recent, { availability: null }),
      observation('middle', older, { availability: 'InStock' }),
      observation('old', '2023-01-01T10:00:00.000Z', { availability: 'OutOfStock' }),
    ]);

    expect(status.availabilityChange).toEqual({ changed: null, comparedCompetitors: 0 });
  });

  it('vergleicht auch bei großem Zeitabstand', () => {
    const status = summarize([
      observation('new', recent, { availability: 'OutOfStock' }),
      observation('old', '2020-01-01T10:00:00.000Z', { availability: 'InStock' }),
    ]);

    expect(status.availabilityChange).toEqual({ changed: true, comparedCompetitors: 1 });
  });
});

describe('Vorhandene auswertbare Messwerte', () => {
  it('zeigt fehlende Messwerte statt abgeleiteter Ergebnisse an', () => {
    const status = summarize([]);

    expect(status).toEqual({
      measurementsAvailable: false,
      competitorsWithMeasurements: 0,
      priceChange: { changed: null, comparedCompetitors: 0 },
      availabilityChange: { changed: null, comparedCompetitors: 0 },
    });
  });

  it('zählt nur auswertbare Wettbewerbermessungen für konfigurierte URLs', () => {
    const status = summarize([
      observation('own', recent, { targetType: 'own' }),
      observation('unconfigured', recent, { competitorUrl: 'https://other.example/item' }),
      observation('empty', recent, {
        priceValue: null,
        priceStatus: 'unreadable',
        availability: null,
      }),
      observation('usable', recent, { availability: 'InStock', priceValue: null }),
    ]);

    expect(status.measurementsAvailable).toBe(true);
    expect(status.competitorsWithMeasurements).toBe(1);
  });
});
