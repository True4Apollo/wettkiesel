import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  authorizeProductAdmin: vi.fn(),
  productCreate: vi.fn(),
  productFindFirst: vi.fn(),
  productFindMany: vi.fn(),
  productUpdateMany: vi.fn(),
  measurementFindMany: vi.fn(),
}));

vi.mock('server-only', () => ({}));
vi.mock('@/lib/business/product-admin-auth', () => ({
  authorizeProductAdmin: mocks.authorizeProductAdmin,
}));
vi.mock('@/lib/db', () => ({
  prisma: {
    shopProduct: {
      create: mocks.productCreate,
      findFirst: mocks.productFindFirst,
      findMany: mocks.productFindMany,
      updateMany: mocks.productUpdateMany,
    },
    competitorCheckMeasurement: { findMany: mocks.measurementFindMany },
  },
}));

import { GET as getProduct, PATCH } from '@/app/api/admin/products/[productId]/route';
import { GET as getProducts, POST } from '@/app/api/admin/products/route';
import { getShopProductOverview } from '@/lib/business/shop-product-overview';
import { ShopProductOverviewList } from '@/lib/contracts/shop-product-overview';
import {
  isValidProductPriceRange,
  ShopProductInput,
  ShopProductList,
} from '@/lib/contracts/shop-products';

const input = {
  name: 'Erstes Produkt',
  ownUrl: 'https://shop.example.net/produkt',
  competitorUrls: ['https://wettbewerb.example.net/produkt'],
  minPrice: 19.99,
  maxPrice: 29.99,
};

const product = {
  id: 'product-1',
  userId: 'owner-1',
  isArchived: false,
  name: input.name,
  ownUrl: input.ownUrl,
  competitorUrls: input.competitorUrls,
  minPriceCents: 1999,
  maxPriceCents: 2999,
  createdAt: new Date('2026-10-15T10:00:00.000Z'),
  updatedAt: new Date('2026-10-15T10:00:00.000Z'),
};

const invalidRanges = [
  { changes: { minPrice: 0 }, field: 'minPrice' },
  { changes: { minPrice: -1 }, field: 'minPrice' },
  { changes: { maxPrice: 0 }, field: 'maxPrice' },
  { changes: { maxPrice: -1 }, field: 'maxPrice' },
  { changes: { minPrice: 30 }, field: 'maxPrice' },
] as const;

const invalidCompetitorUrls = [
  'keine-url',
  'ftp://wettbewerb.example.net/produkt',
  'javascript:alert(1)',
] as const;

const validCompetitorUrls = [
  'http://wettbewerb.example.net/produkt',
  'https://wettbewerb.example.net/produkt',
  'HTTP://wettbewerb.example.net/produkt',
  'HTTPS://wettbewerb.example.net/produkt',
] as const;

describe('Produktpreisgrenzen', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.authorizeProductAdmin.mockResolvedValue({ ok: true, userId: 'owner-1' });
    mocks.productCreate.mockResolvedValue(product);
    mocks.productUpdateMany.mockResolvedValue({ count: 1 });
    mocks.productFindFirst.mockResolvedValue(product);
    mocks.productFindMany.mockResolvedValue([product]);
    mocks.measurementFindMany.mockResolvedValue([]);
  });

  it('akzeptiert positive Preisgrenzen einschließlich gleicher Werte', () => {
    expect(ShopProductInput.safeParse({ ...input, minPrice: 10, maxPrice: 10 }).success).toBe(true);
    expect(isValidProductPriceRange(10, 10)).toBe(true);
  });

  it.each(invalidRanges)('ordnet ungültige Werte dem Feld $field zu', ({ changes, field }) => {
    const result = ShopProductInput.safeParse({ ...input, ...changes });

    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.flatten().fieldErrors[field]?.[0]).toBeTruthy();
    }
  });

  it.each(invalidRanges)(
    'lehnt POST mit einem Feldfehler für $field ab',
    async ({ changes, field }) => {
      const response = await POST(
        new Request('https://app.example/api/admin/products', {
          method: 'POST',
          body: JSON.stringify({ ...input, ...changes }),
        }),
      );

      expect(response.status).toBe(400);
      await expect(response.json()).resolves.toMatchObject({
        errors: { [field]: expect.any(String) },
      });
      expect(mocks.productCreate).not.toHaveBeenCalled();
    },
  );

  it.each(invalidRanges)(
    'lehnt PATCH mit einem Feldfehler für $field ab',
    async ({ changes, field }) => {
      const response = await PATCH(
        new Request('https://app.example/api/admin/products/product-1', {
          method: 'PATCH',
          body: JSON.stringify({ ...input, ...changes }),
        }),
        { params: Promise.resolve({ productId: 'product-1' }) },
      );

      expect(response.status).toBe(400);
      await expect(response.json()).resolves.toMatchObject({
        errors: { [field]: expect.any(String) },
      });
      expect(mocks.productUpdateMany).not.toHaveBeenCalled();
    },
  );

  it('liefert ungültige gespeicherte Preise in Adminlisten und Bearbeitungsantworten aus', async () => {
    const legacyProduct = { ...product, minPriceCents: -500, maxPriceCents: 0 };
    mocks.productFindMany.mockResolvedValue([legacyProduct]);
    mocks.productFindFirst.mockResolvedValue(legacyProduct);

    const listResponse = await getProducts(new Request('https://app.example/api/admin/products'));
    const editResponse = await getProduct(
      new Request('https://app.example/api/admin/products/product-1'),
      {
        params: Promise.resolve({ productId: 'product-1' }),
      },
    );

    expect(listResponse.status).toBe(200);
    await expect(listResponse.json()).resolves.toMatchObject({
      items: [{ minPrice: -5, maxPrice: 0 }],
    });
    expect(editResponse.status).toBe(200);
    await expect(editResponse.json()).resolves.toMatchObject({
      item: { minPrice: -5, maxPrice: 0 },
    });
    expect(isValidProductPriceRange(-5, 0)).toBe(false);
  });

  it('liefert ungültige Altgrenzen auch in der Shopbetreiberübersicht aus', async () => {
    mocks.productFindMany.mockResolvedValue([
      { ...product, minPriceCents: 0, maxPriceCents: -250 },
    ]);

    const items = await getShopProductOverview('owner-1');

    expect(ShopProductList.parse({ items }).items[0]).toMatchObject({
      minPrice: 0,
      maxPrice: -2.5,
    });
    expect(ShopProductOverviewList.parse({ items }).items[0]).toMatchObject({
      minPrice: 0,
      maxPrice: -2.5,
    });
    expect(isValidProductPriceRange(0, -2.5)).toBe(false);
  });

  it.each(invalidCompetitorUrls)(
    'weist POST mit ungültiger Wettbewerber-URL %s ohne Anlage ab',
    async (url) => {
      const response = await POST(
        new Request('https://app.example/api/admin/products', {
          method: 'POST',
          body: JSON.stringify({ ...input, competitorUrls: [url] }),
        }),
      );

      expect(response.status).toBe(400);
      await expect(response.json()).resolves.toMatchObject({
        errors: { competitorUrls: expect.stringContaining('HTTP- oder HTTPS-Adresse') },
      });
      expect(mocks.productCreate).not.toHaveBeenCalled();
    },
  );

  it.each(invalidCompetitorUrls)(
    'weist PATCH mit ungültiger Wettbewerber-URL %s ohne Änderung ab',
    async (url) => {
      const response = await PATCH(
        new Request('https://app.example/api/admin/products/product-1', {
          method: 'PATCH',
          body: JSON.stringify({ ...input, competitorUrls: [url] }),
        }),
        { params: Promise.resolve({ productId: 'product-1' }) },
      );

      expect(response.status).toBe(400);
      await expect(response.json()).resolves.toMatchObject({
        errors: { competitorUrls: expect.stringContaining('HTTP- oder HTTPS-Adresse') },
      });
      expect(mocks.productUpdateMany).not.toHaveBeenCalled();
    },
  );

  it.each(validCompetitorUrls)(
    'speichert gültige Wettbewerber-URL %s bei Anlage und Bearbeitung',
    async (url) => {
      mocks.productCreate.mockResolvedValue({ ...product, competitorUrls: [url] });
      const createResponse = await POST(
        new Request('https://app.example/api/admin/products', {
          method: 'POST',
          body: JSON.stringify({ ...input, competitorUrls: [url] }),
        }),
      );

      expect(createResponse.status).toBe(201);
      expect(mocks.productCreate).toHaveBeenCalledWith({
        data: expect.objectContaining({ competitorUrls: [url] }),
      });
      await expect(createResponse.json()).resolves.toMatchObject({
        item: { competitorUrls: [url] },
      });

      mocks.productFindFirst.mockResolvedValue({ ...product, competitorUrls: [url] });
      const updateResponse = await PATCH(
        new Request('https://app.example/api/admin/products/product-1', {
          method: 'PATCH',
          body: JSON.stringify({ ...input, competitorUrls: [url] }),
        }),
        { params: Promise.resolve({ productId: 'product-1' }) },
      );

      expect(updateResponse.status).toBe(200);
      expect(mocks.productUpdateMany).toHaveBeenCalledWith({
        where: { id: 'product-1', userId: 'owner-1' },
        data: expect.objectContaining({ competitorUrls: [url] }),
      });
      await expect(updateResponse.json()).resolves.toMatchObject({
        item: { competitorUrls: [url] },
      });
    },
  );
});
