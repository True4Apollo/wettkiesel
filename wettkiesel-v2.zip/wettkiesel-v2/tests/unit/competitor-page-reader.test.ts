import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  assertPublicHttpTarget: vi.fn(),
  fetchPage: vi.fn(),
  generateObject: vi.fn(),
}));

vi.mock('server-only', () => ({}));
vi.mock('@/lib/business/public-http-target', () => ({
  assertPublicHttpTarget: mocks.assertPublicHttpTarget,
  InvalidPublicHttpTargetError: class InvalidPublicHttpTargetError extends Error {},
}));
vi.mock('@/lib/ai/client', () => ({
  AiConfigurationError: class AiConfigurationError extends Error {},
  generateObject: mocks.generateObject,
}));
vi.mock('@/modules/web-search/client', () => ({
  fetchPage: mocks.fetchPage,
  InvalidUrlError: class InvalidUrlError extends Error {},
  PageUnavailableError: class PageUnavailableError extends Error {},
  QuotaExceededError: class QuotaExceededError extends Error {},
  WebSearchConfigurationError: class WebSearchConfigurationError extends Error {},
  WebSearchError: class WebSearchError extends Error {
    status = 400;
  },
  WebSearchNotEnabledError: class WebSearchNotEnabledError extends Error {},
  WebSearchUnavailableError: class WebSearchUnavailableError extends Error {},
}));

import { InvalidUrlError } from '@/modules/web-search/client';
import {
  COMPETITOR_PAGE_MAX_BYTES,
  COMPETITOR_PAGE_TIMEOUT_MS,
  readCompetitorPage,
} from '@/lib/business/competitor-page-reader';

describe('Abruf öffentlicher Wettbewerberseiten', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.assertPublicHttpTarget.mockResolvedValue(undefined);
    mocks.fetchPage.mockResolvedValue({
      markdown:
        'Preis 12,99 €\nAuf Lager\n<script type="application/ld+json">{"@context":"https://schema.org","@type":"Product","offers":{"@type":"Offer","availability":"https://schema.org/InStock"}}</script>',
      title: 'Produktseite',
      truncated: false,
      cached: false,
      fetchedAt: '2026-10-14T12:00:00.000Z',
    });
    mocks.generateObject.mockResolvedValue({
      priceQuotes: ['Preis 12,99 €'],
    });
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('prüft eine gespeicherte öffentliche URL vor dem Abruf und liefert eine normale Messung', async () => {
    const result = await readCompetitorPage({
      url: 'https://store.example.net/item',
      productName: 'Produkt',
    });

    expect(mocks.assertPublicHttpTarget).toHaveBeenCalledWith('https://store.example.net/item');
    expect(mocks.assertPublicHttpTarget.mock.invocationCallOrder[0]).toBeLessThan(
      mocks.fetchPage.mock.invocationCallOrder[0] ?? Number.POSITIVE_INFINITY,
    );
    expect(result).toMatchObject({
      status: 'observed',
      priceValue: '12.99',
      currency: 'EUR',
      availability: 'InStock',
      checkedAt: '2026-10-14T12:00:00.000Z',
      sourceCached: false,
    });
  });

  it('wandelt die Proxy-Ablehnung eines privaten Redirect-Ziels in einen leeren Endfehler um', async () => {
    mocks.fetchPage.mockRejectedValue(new InvalidUrlError('private redirect target rejected'));

    const result = await readCompetitorPage({
      url: 'https://store.example.net/redirect',
      productName: 'Produkt',
    });

    expect(result).toMatchObject({
      status: 'invalid_target',
      priceValue: null,
      currency: null,
      priceStatus: 'unreadable',
      priceErrorCode: 'price_unreadable',
      availability: null,
      priceEvidence: null,
      availabilityEvidence: null,
      errorCode: 'invalid_public_target',
      checkedAt: null,
      sourceCached: null,
    });
    expect(mocks.generateObject).not.toHaveBeenCalled();
  });

  it('kennzeichnet eine nicht lesbare Produktseite ohne Preiswert als nicht auslesbar', async () => {
    mocks.fetchPage.mockRejectedValue(new (class extends Error {})());

    const result = await readCompetitorPage({
      url: 'https://store.example.net/products/item',
      productName: 'Produkt',
      targetType: 'own',
    });

    expect(result).toMatchObject({
      status: 'error',
      priceValue: null,
      currency: null,
      priceStatus: 'unreadable',
      priceErrorCode: 'price_unreadable',
      priceErrorMessage: expect.stringContaining('Preis nicht auslesbar'),
      errorCode: 'page_read_failed',
      checkedAt: null,
    });
    expect(mocks.generateObject).not.toHaveBeenCalled();
  });

  it('weist eine Antwort oberhalb des festen Byte-Limits ohne Preisauswertung zurück', async () => {
    mocks.fetchPage.mockResolvedValue({
      markdown: 'x'.repeat(COMPETITOR_PAGE_MAX_BYTES),
      title: 'x',
      truncated: false,
      cached: true,
      fetchedAt: '2026-10-14T12:00:00.000Z',
    });

    const result = await readCompetitorPage({
      url: 'https://store.example.net/large-item',
      productName: 'Produkt',
    });

    expect(result).toMatchObject({
      status: 'error',
      priceValue: null,
      currency: null,
      priceStatus: 'unreadable',
      priceErrorCode: 'price_unreadable',
      availability: null,
      priceEvidence: null,
      availabilityEvidence: null,
      errorCode: 'page_too_large',
      errorMessage: `Die Wettbewerberseite überschritt das Größenlimit von ${COMPETITOR_PAGE_MAX_BYTES} Bytes.`,
      checkedAt: '2026-10-14T12:00:00.000Z',
      sourceCached: true,
    });
    expect(mocks.generateObject).not.toHaveBeenCalled();
  });

  it('beendet einen verzögerten Seitenabruf nach dem festen Zeitlimit als nachvollziehbaren Fehler', async () => {
    vi.useFakeTimers();
    mocks.fetchPage.mockReturnValue(new Promise(() => {}));

    const pending = readCompetitorPage({
      url: 'https://store.example.net/slow-item',
      productName: 'Produkt',
    });
    await vi.advanceTimersByTimeAsync(COMPETITOR_PAGE_TIMEOUT_MS);
    const result = await pending;

    expect(result).toMatchObject({
      status: 'error',
      priceValue: null,
      priceStatus: 'unreadable',
      availability: null,
      errorCode: 'page_read_timeout',
      errorMessage: 'Die Wettbewerberseite antwortete nicht innerhalb von 30 Sekunden.',
      checkedAt: null,
      sourceCached: null,
    });
    expect(mocks.generateObject).not.toHaveBeenCalled();
  });

  it('begrenzt auch eine verzögerte Prüfung des öffentlichen URL-Ziels', async () => {
    vi.useFakeTimers();
    mocks.assertPublicHttpTarget.mockReturnValue(new Promise(() => {}));

    const pending = readCompetitorPage({
      url: 'https://store.example.net/slow-dns',
      productName: 'Produkt',
    });
    await vi.advanceTimersByTimeAsync(COMPETITOR_PAGE_TIMEOUT_MS);
    const result = await pending;

    expect(result).toMatchObject({
      status: 'error',
      errorCode: 'page_read_timeout',
      checkedAt: null,
    });
    expect(mocks.fetchPage).not.toHaveBeenCalled();
    expect(mocks.generateObject).not.toHaveBeenCalled();
  });
});
