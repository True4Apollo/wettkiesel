// @polsia:user-owned — checks the competitor empty state without creating product data.
import { act } from 'react';
import { createRoot, type Root } from 'react-dom/client';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({ apiFetch: vi.fn() }));

vi.mock('@/lib/api-client', () => ({ apiFetch: mocks.apiFetch }));

import { ShopProductDetail } from '@/components/custom/dashboard/shop-product-detail';

describe('Shop-Produktdetail: Wettbewerber-Leerzustand', () => {
  let root: Root | null = null;
  let container: HTMLDivElement | null = null;

  beforeEach(() => {
    Object.defineProperty(globalThis, 'IS_REACT_ACT_ENVIRONMENT', {
      configurable: true,
      value: true,
    });
    container = document.createElement('div');
    document.body.append(container);
    root = createRoot(container);
    mocks.apiFetch.mockResolvedValue({
      item: {
        id: 'product-1',
        isArchived: false,
        name: 'Produkt',
        ownUrl: 'https://shop.example/item',
        competitorUrls: [],
        minPrice: 10,
        maxPrice: 20,
        createdAt: '2026-10-01T10:00:00.000Z',
        updatedAt: '2026-10-02T10:00:00.000Z',
        lastCheck: null,
        competitorLastChecks: [],
        marketStatus: {
          measurementsAvailable: false,
          competitorsWithMeasurements: 0,
          priceChange: { changed: null, comparedCompetitors: 0 },
          availabilityChange: { changed: null, comparedCompetitors: 0 },
        },
      },
    });
  });

  afterEach(async () => {
    if (root) await act(async () => root?.unmount());
    container?.remove();
    root = null;
    container = null;
    vi.clearAllMocks();
  });

  it('zeigt den Leerzustand und lässt die nicht verfügbare Ergänzungsaktion deaktiviert', async () => {
    await act(async () => {
      root?.render(<ShopProductDetail productId="product-1" />);
      await new Promise((resolve) => setTimeout(resolve, 0));
    });

    const detail = container;
    if (!detail) throw new Error('Produktdetailcontainer fehlt.');

    expect(detail.textContent).toContain('Noch keine Wettbewerber hinterlegt.');
    expect(detail.textContent).toContain(
      'Das Ergänzungsformular für bestehende Produkte im Shopbereich fehlt derzeit.',
    );
    const addButton = [...detail.querySelectorAll('button')].find((button) =>
      button.textContent?.includes('Wettbewerber hinzufügen'),
    );
    expect(addButton?.disabled).toBe(true);
    expect(mocks.apiFetch).toHaveBeenCalledTimes(1);
    expect(mocks.apiFetch.mock.calls[0]?.[0]).toBe('/api/shop/products/product-1');
    expect(mocks.apiFetch.mock.calls[0]?.[1]?.method).toBeUndefined();
  });
});
