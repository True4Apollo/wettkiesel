// @vitest-environment node
import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  getSession: vi.fn(),
  headers: vi.fn(),
  findMany: vi.fn(),
}));

vi.mock('server-only', () => ({}));
vi.mock('next/headers', () => ({ headers: mocks.headers }));
vi.mock('@/lib/auth', () => ({ auth: { api: { getSession: mocks.getSession } } }));
vi.mock('@/lib/db', () => ({
  prisma: { shopMarketReportFeedback: { findMany: mocks.findMany } },
}));

import { GET } from '@/app/api/admin/market-report-feedback/route';
import { MarketReportFeedbackSummary } from '@/lib/contracts/market-report-feedback-summary';

describe('Geschützter Tagesbericht-Feedbackabruf', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.headers.mockResolvedValue(new Headers());
    mocks.findMany.mockResolvedValue([]);
  });

  it('weist nicht angemeldete Aufrufe ab, bevor gespeicherte Einträge gelesen werden', async () => {
    mocks.getSession.mockResolvedValue(null);

    const response = await GET();

    expect(response.status).toBe(401);
    expect(mocks.findMany).not.toHaveBeenCalled();
  });

  it('weist Konten ohne Adminrolle ab, bevor gespeicherte Einträge gelesen werden', async () => {
    mocks.getSession.mockResolvedValue({ user: { role: 'user' } });

    const response = await GET();

    expect(response.status).toBe(403);
    expect(mocks.findMany).not.toHaveBeenCalled();
  });

  it('zählt alle gespeicherten Bewertungen und lässt leere optionale Gründe aus', async () => {
    mocks.getSession.mockResolvedValue({ user: { role: 'admin' } });
    mocks.findMany.mockResolvedValue([
      {
        id: 'feedback-helpful',
        isUseful: true,
        reason: '  Klare Preisbewegung  ',
        createdAt: new Date('2026-10-14T12:00:00.000Z'),
        report: { dateKey: '2026-10-14', product: { name: 'Wettkiesel Probeprodukt' } },
      },
      {
        id: 'feedback-no-reason',
        isUseful: false,
        reason: '   ',
        createdAt: new Date('2026-10-13T12:00:00.000Z'),
        report: { dateKey: '2026-10-13', product: { name: 'Wettkiesel Probeprodukt' } },
      },
      {
        id: 'feedback-not-helpful',
        isUseful: false,
        reason: 'Fehlender Vergleichswert',
        createdAt: new Date('2026-10-12T12:00:00.000Z'),
        report: { dateKey: '2026-10-12', product: { name: 'Wettkiesel Probeprodukt' } },
      },
    ]);

    const response = await GET();
    expect(response.status).toBe(200);
    expect(response.headers.get('cache-control')).toBe('private, no-store');

    const summary = MarketReportFeedbackSummary.parse(await response.json());

    expect(mocks.findMany).toHaveBeenCalledTimes(1);
    expect(mocks.findMany).toHaveBeenCalledWith({
      select: {
        id: true,
        isUseful: true,
        reason: true,
        createdAt: true,
        report: {
          select: {
            dateKey: true,
            product: { select: { name: true } },
          },
        },
      },
      orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
    });
    expect(summary.helpfulCount).toBe(1);
    expect(summary.notHelpfulCount).toBe(2);
    expect(summary.reasons).toEqual([
      {
        feedbackId: 'feedback-helpful',
        isUseful: true,
        reason: 'Klare Preisbewegung',
        reportDate: '2026-10-14',
        productName: 'Wettkiesel Probeprodukt',
        submittedAt: '2026-10-14T12:00:00.000Z',
      },
      {
        feedbackId: 'feedback-not-helpful',
        isUseful: false,
        reason: 'Fehlender Vergleichswert',
        reportDate: '2026-10-12',
        productName: 'Wettkiesel Probeprodukt',
        submittedAt: '2026-10-12T12:00:00.000Z',
      },
    ]);
  });
});
