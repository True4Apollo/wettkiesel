import { describe, expect, it } from 'vitest';
import type { CompetitorCheckRun, CompetitorMeasurement } from '@/lib/contracts/competitor-checks';
import { selectOwnProductPrice } from '@/lib/business/own-product-price';

const ownUrl = 'https://shop.example.test/products/one';

function measurement(
  overrides: Partial<CompetitorMeasurement> = {},
): CompetitorMeasurement {
  return {
    id: 'own-measurement',
    targetType: 'own',
    competitorUrl: ownUrl,
    status: 'observed',
    priceValue: '24.50',
    currency: 'EUR',
    priceStatus: 'observed',
    priceErrorCode: null,
    priceErrorMessage: null,
    availability: null,
    priceEvidence: '24,50 €',
    availabilityEvidence: null,
    errorCode: null,
    errorMessage: null,
    checkedAt: '2026-10-14T12:00:00.000Z',
    attemptedAt: '2026-10-14T12:00:00.000Z',
    sourceCached: false,
    ...overrides,
  };
}

function run(
  id: string,
  startedAt: string,
  measurements: CompetitorMeasurement[],
): CompetitorCheckRun {
  return { id, status: 'completed', startedAt, completedAt: startedAt, measurements };
}

describe('Auswahl des gespeicherten Eigenpreises', () => {
  it('behält den letzten lesbaren Eigenpreis mit seinem Messzeitpunkt bei einem neueren unlesbaren Abruf', () => {
    const unreadableAttempt = measurement({
      id: 'own-unreadable',
      status: 'unreadable',
      priceValue: null,
      currency: null,
      priceStatus: 'unreadable',
      checkedAt: '2026-10-15T12:00:00.000Z',
      attemptedAt: '2026-10-15T12:00:00.000Z',
    });
    const newerCompetitorPrice = measurement({
      id: 'competitor-price',
      targetType: 'competitor',
      competitorUrl: 'https://competitor.example.test/item',
      priceValue: '5.99',
      checkedAt: '2026-10-15T12:01:00.000Z',
      attemptedAt: '2026-10-15T12:01:00.000Z',
    });
    const savedOwnPrice = measurement({
      id: 'own-readable',
      priceValue: '31.25',
      checkedAt: '2026-10-14T12:00:00.000Z',
      attemptedAt: '2026-10-14T12:00:00.000Z',
    });

    const summary = selectOwnProductPrice(
      [
        run('latest', '2026-10-15T11:59:00.000Z', [unreadableAttempt, newerCompetitorPrice]),
        run('previous', '2026-10-14T11:59:00.000Z', [savedOwnPrice]),
      ],
      ownUrl,
    );

    expect(summary.status).toBe('unreadable');
    expect(summary.lastReadablePrice).toMatchObject({
      id: 'own-readable',
      priceValue: '31.25',
      currency: 'EUR',
      checkedAt: '2026-10-14T12:00:00.000Z',
    });
    expect(summary.latestAttempt?.id).toBe('own-unreadable');
  });

  it('meldet fehlende Eigenmessungen ohne Wettbewerberwerte zu übernehmen', () => {
    const competitor = measurement({
      id: 'competitor-only',
      targetType: 'competitor',
      competitorUrl: 'https://competitor.example.test/item',
      priceValue: '99.00',
    });

    const summary = selectOwnProductPrice(
      [run('competitor-run', '2026-10-14T12:00:00.000Z', [competitor])],
      ownUrl,
    );

    expect(summary.status).toBe('missing');
    expect(summary.latestAttempt).toBeNull();
    expect(summary.lastReadablePrice).toBeNull();
  });

  it('meldet einen unlesbaren letzten Abruf, wenn kein früherer lesbarer Eigenpreis vorliegt', () => {
    const unreadable = measurement({
      status: 'unreadable',
      priceValue: '999.00',
      currency: 'EUR',
      priceStatus: 'unreadable',
    });

    const summary = selectOwnProductPrice(
      [run('unreadable-run', '2026-10-14T12:00:00.000Z', [unreadable])],
      ownUrl,
    );

    expect(summary.status).toBe('unreadable');
    expect(summary.latestAttempt?.id).toBe('own-measurement');
    expect(summary.lastReadablePrice).toBeNull();
  });
});
