// @polsia:user-owned
import { act } from 'react';
import { createRoot, type Root } from 'react-dom/client';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  apiFetch: vi.fn(),
  routerPush: vi.fn(),
  routerRefresh: vi.fn(),
  toastSuccess: vi.fn(),
}));

vi.mock('@/lib/api-client', () => ({ apiFetch: mocks.apiFetch }));
vi.mock('next/navigation', () => ({
  useRouter: () => ({ push: mocks.routerPush, refresh: mocks.routerRefresh }),
}));
vi.mock('sonner', () => ({ toast: { success: mocks.toastSuccess } }));
vi.mock('@/components/custom/admin/competitor-measurement-panel', () => ({
  CompetitorMeasurementPanel: () => null,
}));
vi.mock('@/components/custom/admin/market-report-panel', () => ({ MarketReportPanel: () => null }));

import { ShopProductForm } from '@/components/custom/admin/shop-product-form';

function setFieldValue(container: HTMLElement, selector: string, value: string) {
  const field = container.querySelector(selector);
  if (!(field instanceof HTMLInputElement || field instanceof HTMLTextAreaElement)) {
    throw new Error(`Eingabefeld ${selector} wurde nicht gefunden.`);
  }
  const prototype =
    field instanceof HTMLInputElement ? HTMLInputElement.prototype : HTMLTextAreaElement.prototype;
  Object.getOwnPropertyDescriptor(prototype, 'value')?.set?.call(field, value);
  field.dispatchEvent(new Event('input', { bubbles: true }));
}

describe('Produktformular: Wettbewerber-URLs', () => {
  let root: Root | null = null;
  let container: HTMLDivElement | null = null;

  beforeEach(() => {
    Object.defineProperty(globalThis, 'IS_REACT_ACT_ENVIRONMENT', {
      configurable: true,
      value: true,
    });
    container = document.createElement('div');
    document.body.append(container);
    root = createRoot(container);
  });

  afterEach(async () => {
    if (root) await act(async () => root?.unmount());
    container?.remove();
    root = null;
    container = null;
    vi.clearAllMocks();
  });

  it('zeigt am Wettbewerberfeld eine verständliche Fehlermeldung und sendet nichts ab', async () => {
    await act(async () => {
      root?.render(<ShopProductForm />);
    });

    const formContainer = container;
    if (!formContainer) throw new Error('Formularcontainer fehlt.');
    await act(async () => {
      setFieldValue(formContainer, '#product-name', 'Erstes Produkt');
      setFieldValue(formContainer, '#own-url', 'https://shop.example.net/produkt');
      setFieldValue(formContainer, '#competitor-urls', 'ftp://wettbewerb.example.net/produkt');
      setFieldValue(formContainer, '#minimum-price', '19.99');
      setFieldValue(formContainer, '#maximum-price', '29.99');
    });

    await act(async () => {
      formContainer.querySelector('form')?.dispatchEvent(
        new Event('submit', { bubbles: true, cancelable: true }),
      );
    });

    expect(
      formContainer.querySelector('#competitor-urls')?.getAttribute('aria-invalid'),
    ).toBe('true');
    expect(formContainer.querySelector('#competitor-urls-error')?.textContent).toContain(
      'HTTP- oder HTTPS-Adresse',
    );
    expect(mocks.apiFetch).not.toHaveBeenCalled();
  });
});
