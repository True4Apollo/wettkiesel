import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  authorizeProductAdmin: vi.fn(),
  productCreate: vi.fn(),
}));

vi.mock('server-only', () => ({}));
vi.mock('@/lib/business/product-admin-auth', () => ({
  authorizeProductAdmin: mocks.authorizeProductAdmin,
}));
vi.mock('@/lib/db', () => ({
  prisma: {
    shopProduct: { create: mocks.productCreate },
  },
}));

import { POST } from '@/app/api/admin/products/route';

const input = {
  name: 'Erstes Produkt',
  ownUrl: 'https://shop.example.net/produkt',
  competitorUrls: ['https://wettbewerb.example.net/produkt'],
  minPrice: 19.99,
  maxPrice: 29.99,
};

const createdProduct = {
  id: 'product-1',
  isArchived: false,
  name: input.name,
  ownUrl: input.ownUrl,
  competitorUrls: input.competitorUrls,
  minPriceCents: 1999,
  maxPriceCents: 2999,
  createdAt: new Date('2026-10-15T10:00:00.000Z'),
  updatedAt: new Date('2026-10-15T10:00:00.000Z'),
};

describe('Owner-Produktanlage', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.authorizeProductAdmin.mockResolvedValue({ ok: true, userId: 'owner-1' });
    mocks.productCreate.mockResolvedValue(createdProduct);
  });

  it('legt das erste Produkt erst beim Speichern für das aktuelle Owner-Konto an', async () => {
    const response = await POST(
      new Request('https://app.example/api/admin/products', {
        method: 'POST',
        body: JSON.stringify(input),
      }),
    );

    expect(response.status).toBe(201);
    expect(mocks.productCreate).toHaveBeenCalledWith({
      data: {
        userId: 'owner-1',
        name: input.name,
        ownUrl: input.ownUrl,
        competitorUrls: input.competitorUrls,
        minPriceCents: 1999,
        maxPriceCents: 2999,
      },
    });
    await expect(response.json()).resolves.toMatchObject({ item: { id: 'product-1' } });
  });

  it('weist Konten ohne Betreiberberechtigung vor jedem Schreibzugriff ab', async () => {
    mocks.authorizeProductAdmin.mockResolvedValue({
      ok: false,
      response: Response.json({ error: 'forbidden' }, { status: 403 }),
    });

    const response = await POST(
      new Request('https://app.example/api/admin/products', {
        method: 'POST',
        body: JSON.stringify(input),
      }),
    );

    expect(response.status).toBe(403);
    await expect(response.json()).resolves.toEqual({ error: 'forbidden' });
    expect(mocks.productCreate).not.toHaveBeenCalled();
  });
});
