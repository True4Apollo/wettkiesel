import { describe, expect, it } from 'vitest';
import {
  assertPublicHttpTarget,
  InvalidPublicHttpTargetError,
  isPublicIpAddress,
} from '@/lib/business/public-http-target';

const resolverFor = (...addresses: string[]) =>
  async () => addresses.map((address) => ({ address }));

describe('Prüfung öffentlicher HTTP-Ziele', () => {
  it('akzeptiert absolute HTTP(S)-URLs mit öffentlichen IPv4- und IPv6-Adressen', async () => {
    await expect(assertPublicHttpTarget('http://93.184.216.34/')).resolves.toBeUndefined();
    await expect(assertPublicHttpTarget('https://[2606:4700:4700::1111]/')).resolves.toBeUndefined();
    await expect(
      assertPublicHttpTarget('https://store.example.net/item', resolverFor('93.184.216.34')),
    ).resolves.toBeUndefined();
  });

  it.each([
    'http://localhost/',
    'http://printer.localhost/',
    'http://127.0.0.1/',
    'http://2130706433/',
    'http://0177.0.0.1/',
    'http://10.20.30.40/',
    'http://169.254.1.2/',
    'http://172.20.1.2/',
    'http://192.0.2.1/',
    'http://198.18.0.1/',
    'http://203.0.113.8/',
    'http://224.0.0.1/',
    'http://240.0.0.1/',
    'http://[::1]/',
    'http://[fc00::1]/',
    'http://[fe80::1]/',
    'http://[ff02::1]/',
    'http://[2001:db8::1]/',
    'http://[2002:7f00:1::]/',
  ])('blockiert lokale, Link-Local-, Multicast- und reservierte IP-Adressen: %s', async (url) => {
    await expect(assertPublicHttpTarget(url)).rejects.toBeInstanceOf(
      InvalidPublicHttpTargetError,
    );
  });

  it.each(['ftp://store.example.net/item', '/relative/path', 'https://user:pass@8.8.8.8/'])(
    'weist nicht absolute HTTP(S)-Ziele oder URLs mit Zugangsdaten zurück: %s',
    async (url) => {
      await expect(assertPublicHttpTarget(url)).rejects.toBeInstanceOf(
        InvalidPublicHttpTargetError,
      );
    },
  );

  it('blockiert Hostnamen, wenn eine DNS-Antwort privat oder reserviert ist', async () => {
    await expect(
      assertPublicHttpTarget(
        'https://store.example.net/item',
        resolverFor('93.184.216.34', '10.0.0.8'),
      ),
    ).rejects.toBeInstanceOf(InvalidPublicHttpTargetError);
    await expect(
      assertPublicHttpTarget('https://store.example.net/item', resolverFor('2001:db8::1')),
    ).rejects.toBeInstanceOf(InvalidPublicHttpTargetError);
  });

  it('blockiert DNS-Fehler und leere DNS-Antworten', async () => {
    await expect(
      assertPublicHttpTarget('https://store.example.net/item', async () => {
        throw new Error('ENOTFOUND');
      }),
    ).rejects.toBeInstanceOf(InvalidPublicHttpTargetError);
    await expect(
      assertPublicHttpTarget('https://store.example.net/item', async () => []),
    ).rejects.toBeInstanceOf(InvalidPublicHttpTargetError);
  });

  it('stuft nur global routbare Adressbereiche als öffentlich ein', () => {
    expect(isPublicIpAddress('8.8.8.8')).toBe(true);
    expect(isPublicIpAddress('2606:4700:4700::1111')).toBe(true);
    expect(isPublicIpAddress('100.64.0.1')).toBe(false);
    expect(isPublicIpAddress('255.255.255.255')).toBe(false);
    expect(isPublicIpAddress('::ffff:127.0.0.1')).toBe(false);
  });
});
