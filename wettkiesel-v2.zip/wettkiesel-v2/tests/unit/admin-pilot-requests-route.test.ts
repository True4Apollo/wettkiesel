// @vitest-environment node
import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  getSession: vi.fn(),
  headers: vi.fn(),
  findMany: vi.fn(),
}));

vi.mock('server-only', () => ({}));
vi.mock('next/headers', () => ({ headers: mocks.headers }));
vi.mock('@/lib/auth', () => ({ auth: { api: { getSession: mocks.getSession } } }));
vi.mock('@/lib/db', () => ({ prisma: { contactMessage: { findMany: mocks.findMany } } }));

import { GET } from '@/app/api/admin/pilot-requests/route';
import { PilotRequestList } from '@/lib/contracts/pilot-requests';

const pilotMarker = 'Zahlungsbereitschaft (unverbindlich):';

describe('Admin-Leseweg für Pilotanfragen', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.headers.mockResolvedValue(new Headers());
    mocks.findMany.mockResolvedValue([]);
  });

  it('weist nicht angemeldete Aufrufe mit 401 ab, bevor Daten gelesen werden', async () => {
    mocks.getSession.mockResolvedValue(null);

    const response = await GET();

    expect(response.status).toBe(401);
    expect(mocks.findMany).not.toHaveBeenCalled();
  });

  it('weist angemeldete Konten ohne Adminrolle mit 403 ab, bevor Daten gelesen werden', async () => {
    mocks.getSession.mockResolvedValue({ user: { role: 'user' } });

    const response = await GET();

    expect(response.status).toBe(403);
    expect(mocks.findMany).not.toHaveBeenCalled();
  });

  it('liefert bei Adminzugriff eine leere Liste und fragt nur Pilotnachrichten ab', async () => {
    mocks.getSession.mockResolvedValue({ user: { role: 'admin' } });

    const response = await GET();
    expect(response.status).toBe(200);

    const result = PilotRequestList.parse(await response.json());

    expect(mocks.findMany).toHaveBeenCalledWith({
      where: { message: { contains: pilotMarker } },
      select: { id: true, createdAt: true, message: true },
      orderBy: { createdAt: 'desc' },
    });
    expect(result.items).toEqual([]);
  });
});
