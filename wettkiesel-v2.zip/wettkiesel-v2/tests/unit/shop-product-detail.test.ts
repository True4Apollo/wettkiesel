// @polsia:user-owned — verifies authenticated owner scoping for product details.
import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  requireAuth: vi.fn(),
  productFindFirst: vi.fn(),
  measurementFindMany: vi.fn(),
}));

vi.mock('server-only', () => ({}));
vi.mock('@/lib/require-auth', () => ({ requireAuth: mocks.requireAuth }));
vi.mock('@/lib/db', () => ({
  prisma: {
    shopProduct: { findFirst: mocks.productFindFirst },
    competitorCheckMeasurement: { findMany: mocks.measurementFindMany },
  },
}));

import { GET } from '@/app/api/shop/products/[productId]/route';

const product = {
  id: 'product-owned',
  userId: 'owner-1',
  name: 'Eigene Tasche',
  ownUrl: 'https://shop.example/item',
  competitorUrls: ['https://rival.example/item'],
  minPriceCents: 1500,
  maxPriceCents: 2500,
  isArchived: false,
  createdAt: new Date('2026-10-01T10:00:00.000Z'),
  updatedAt: new Date('2026-10-02T10:00:00.000Z'),
};

function measurement(
  id: string,
  availability: string | null,
  attemptedAt: string,
  overrides: Record<string, unknown> = {},
) {
  const timestamp = new Date(attemptedAt);
  return {
    id,
    status: 'observed',
    targetType: 'competitor',
    competitorUrl: 'https://rival.example/item',
    priceValue: null,
    currency: null,
    priceStatus: 'not_checked',
    availability,
    checkedAt: timestamp,
    attemptedAt: timestamp,
    createdAt: timestamp,
    run: { productId: product.id, startedAt: timestamp },
    ...overrides,
  };
}

function getProduct(productId: string) {
  return GET(new Request(`https://app.example/api/shop/products/${productId}`), {
    params: Promise.resolve({ productId }),
  });
}

describe('GET /api/shop/products/[productId]', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.requireAuth.mockResolvedValue({ id: 'owner-1' });
    mocks.productFindFirst.mockResolvedValue(product);
    mocks.measurementFindMany.mockResolvedValue([]);
  });

  it('liefert das eigene Produkt und bindet die Abfrage an Eigentümer und Produkt-ID', async () => {
    const response = await getProduct('product-owned');

    expect(response.status).toBe(200);
    await expect(response.json()).resolves.toMatchObject({ item: { id: 'product-owned' } });
    expect(mocks.productFindFirst).toHaveBeenCalledWith({
      where: { id: 'product-owned', userId: 'owner-1', isArchived: false },
    });
  });

  it.each(['foreign-product', 'missing-product'])('%s bleibt unzugänglich', async (productId) => {
    mocks.productFindFirst.mockResolvedValue(null);

    const response = await getProduct(productId);

    expect(response.status).toBe(404);
    await expect(response.json()).resolves.toEqual({ error: 'not_found' });
    expect(mocks.measurementFindMany).not.toHaveBeenCalled();
    expect(mocks.productFindFirst).toHaveBeenCalledWith({
      where: { id: productId, userId: 'owner-1', isArchived: false },
    });
  });

  it('lehnt nicht angemeldete Zugriffe ab, bevor Produktdaten gelesen werden', async () => {
    mocks.requireAuth.mockRejectedValue(Response.json({ error: 'Unauthorized' }, { status: 401 }));

    const response = await getProduct('product-owned');

    expect(response.status).toBe(401);
    expect(mocks.productFindFirst).not.toHaveBeenCalled();
  });

  it('liefert den jüngsten gespeicherten Verfügbarkeitswert mit Messdatensatz und URL', async () => {
    mocks.measurementFindMany.mockResolvedValue([
      measurement('measurement-old', 'InStock', '2026-10-01T10:00:00.000Z'),
      measurement('measurement-latest', 'OutOfStock', '2026-10-03T10:00:00.000Z'),
    ]);

    const response = await getProduct('product-owned');
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body.item.competitorLastChecks).toMatchObject([
      {
        competitorUrl: 'https://rival.example/item',
        availabilityMeasurement: {
          measurementId: 'measurement-latest',
          availability: 'OutOfStock',
        },
      },
    ]);
  });

  it('behält einen jüngsten Messdatensatz mit null getrennt von älteren Verfügbarkeitswerten', async () => {
    mocks.measurementFindMany.mockResolvedValue([
      measurement('measurement-old', 'InStock', '2026-10-01T10:00:00.000Z'),
      measurement('measurement-latest', null, '2026-10-03T10:00:00.000Z'),
    ]);

    const response = await getProduct('product-owned');
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body.item.competitorLastChecks).toMatchObject([
      {
        competitorUrl: 'https://rival.example/item',
        availabilityMeasurement: {
          measurementId: 'measurement-latest',
          availability: null,
        },
      },
    ]);
  });

  it('erfindet ohne passenden Wettbewerberdatensatz keinen Verfügbarkeitsstatus', async () => {
    mocks.measurementFindMany.mockResolvedValue([
      measurement('measurement-own', 'InStock', '2026-10-03T10:00:00.000Z', {
        targetType: 'own',
      }),
      measurement('measurement-other', 'InStock', '2026-10-03T10:00:00.000Z', {
        competitorUrl: 'https://other.example/item',
      }),
    ]);

    const response = await getProduct('product-owned');
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body.item.competitorLastChecks).toMatchObject([
      {
        competitorUrl: 'https://rival.example/item',
        availabilityMeasurement: null,
      },
    ]);
  });
});
