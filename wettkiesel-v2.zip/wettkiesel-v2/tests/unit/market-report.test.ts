import { describe, expect, it } from 'vitest';
import {
  buildMarketReport,
  buildShopDailyMarketReport,
  type StoredCompetitorObservation,
  type StoredProductCompetitorObservation,
} from '@/lib/business/market-report';

const emptyObservation: StoredCompetitorObservation = {
  id: 'today-empty',
  competitorUrl: 'https://shop.example/item-c',
  status: 'no_data',
  priceValue: null,
  currency: null,
  availability: null,
  checkedAt: '2026-10-14T12:00:00.000Z',
};

const blockedObservation: StoredCompetitorObservation = {
  id: 'today-blocked',
  competitorUrl: 'https://shop.example/redirect',
  status: 'invalid_target',
  priceValue: null,
  currency: null,
  availability: null,
  checkedAt: '2026-10-14T12:30:00.000Z',
};

const savedObservations: StoredCompetitorObservation[] = [
  {
    id: 'yesterday-item',
    competitorUrl: 'https://shop.example/item-a',
    status: 'observed',
    priceValue: '100.00',
    currency: 'EUR',
    availability: 'InStock',
    checkedAt: '2026-10-13T10:00:00.000Z',
  },
  {
    id: 'today-item',
    competitorUrl: 'https://shop.example/item-a',
    status: 'observed',
    priceValue: '120.00',
    currency: 'EUR',
    availability: 'OutOfStock',
    checkedAt: '2026-10-14T10:00:00.000Z',
  },
  {
    id: 'today-without-baseline',
    competitorUrl: 'https://shop.example/item-b',
    status: 'partial',
    priceValue: '39.99',
    currency: 'EUR',
    availability: null,
    checkedAt: '2026-10-14T11:00:00.000Z',
  },
  emptyObservation,
];

describe('buildMarketReport', () => {
  it('leitet Bewegungen nur aus gespeicherten Tagesbeobachtungen und passenden Vorwerten ab', () => {
    const report = buildMarketReport({
      productId: 'product-1',
      date: '2026-10-14',
      generatedAt: new Date('2026-10-14T13:00:00.000Z'),
      measurements: [...savedObservations.slice(1), blockedObservation],
      previousMeasurements: savedObservations.slice(0, 1),
    });

    expect(report).toMatchObject({
      productId: 'product-1',
      date: '2026-10-14',
      storedMeasurementCount: 2,
      observations: [
        {
          measurementId: 'today-item',
          priceDirection: 'increase',
          previousPriceValue: '100.00',
          availabilityChanged: true,
        },
        {
          measurementId: 'today-without-baseline',
          priceDirection: null,
          previousPriceValue: null,
          availabilityChanged: null,
          comparisonAt: null,
        },
      ],
    });
  });

  it('meldet ohne verwertbare gespeicherte Beobachtungen keine Marktbewegung', () => {
    const report = buildMarketReport({
      productId: 'product-1',
      date: '2026-10-14',
      generatedAt: new Date('2026-10-14T13:00:00.000Z'),
      measurements: [emptyObservation],
      previousMeasurements: [],
    });

    expect(report.storedMeasurementCount).toBe(0);
    expect(report.observations).toEqual([]);
  });

  it('lässt blockierte Zielprüfungen vollständig aus dem Marktbericht heraus', () => {
    const report = buildMarketReport({
      productId: 'product-1',
      date: '2026-10-14',
      generatedAt: new Date('2026-10-14T13:00:00.000Z'),
      measurements: [
        {
          ...blockedObservation,
          priceValue: '999.99',
          currency: 'EUR',
          availability: 'Auf Lager',
        },
      ],
      previousMeasurements: [],
    });

    expect(report.storedMeasurementCount).toBe(0);
    expect(report.observations).toEqual([]);
  });

  it('gibt ungültige gespeicherte Verfügbarkeit nicht als Status im Bericht aus', () => {
    const report = buildMarketReport({
      productId: 'product-1',
      date: '2026-10-14',
      generatedAt: new Date('2026-10-14T13:00:00.000Z'),
      measurements: [
        {
          id: 'today-legacy-value',
          competitorUrl: 'https://shop.example/item-d',
          status: 'partial',
          priceValue: '19.99',
          currency: 'EUR',
          availability: 'Auf Lager',
          checkedAt: '2026-10-14T12:00:00.000Z',
        },
      ],
      previousMeasurements: [],
    });

    expect(report.observations).toMatchObject([{ availability: null }]);
  });

  it('vergleicht einen gespeicherten Preiswert von null Euro als gültigen Zahlenwert', () => {
    const report = buildMarketReport({
      productId: 'product-1',
      date: '2026-10-15',
      generatedAt: new Date('2026-10-15T13:00:00.000Z'),
      measurements: [
        {
          id: 'today-free-item',
          competitorUrl: 'https://shop.example/free-item',
          status: 'observed',
          priceValue: '0.00',
          currency: 'EUR',
          availability: null,
          checkedAt: '2026-10-15T12:00:00.000Z',
        },
      ],
      previousMeasurements: [
        {
          id: 'yesterday-free-item',
          competitorUrl: 'https://shop.example/free-item',
          status: 'observed',
          priceValue: '5.00',
          currency: 'EUR',
          availability: null,
          checkedAt: '2026-10-14T12:00:00.000Z',
        },
      ],
    });

    expect(report.observations).toMatchObject([
      { priceDirection: 'decrease', previousPriceValue: '5.00', priceValue: '0.00' },
    ]);
  });
});

describe('buildShopDailyMarketReport', () => {
  it('unterscheidet gespeicherte Bewegungen, bewegungslose Messdaten und fehlende verwertbare Messungen', () => {
    const products = [
      { id: 'changed-product', name: 'Produkt mit Änderung' },
      { id: 'steady-product', name: 'Produkt ohne Änderung' },
      { id: 'unmeasured-product', name: 'Produkt ohne Messdaten' },
    ];
    const currentMeasurements: StoredProductCompetitorObservation[] = [
      {
        productId: 'changed-product',
        id: 'changed-current',
        competitorUrl: 'https://shop.example/changed',
        status: 'observed',
        priceValue: '12.00',
        currency: 'EUR',
        availability: null,
        checkedAt: '2026-10-15T10:00:00.000Z',
      },
      {
        productId: 'steady-product',
        id: 'steady-current',
        competitorUrl: 'https://shop.example/steady',
        status: 'observed',
        priceValue: '20.00',
        currency: 'EUR',
        availability: 'InStock',
        checkedAt: '2026-10-15T11:00:00.000Z',
      },
      {
        productId: 'steady-product',
        id: 'without-baseline',
        competitorUrl: 'https://shop.example/without-baseline',
        status: 'partial',
        priceValue: '39.99',
        currency: 'EUR',
        availability: null,
        checkedAt: '2026-10-15T12:00:00.000Z',
      },
      {
        productId: 'unmeasured-product',
        id: 'unreadable-current',
        competitorUrl: 'https://shop.example/unreadable',
        status: 'unreadable',
        priceValue: null,
        currency: null,
        availability: null,
        checkedAt: '2026-10-15T13:00:00.000Z',
      },
    ];
    const previousMeasurements: StoredProductCompetitorObservation[] = [
      {
        productId: 'changed-product',
        id: 'changed-previous',
        competitorUrl: 'https://shop.example/changed',
        status: 'observed',
        priceValue: '10.00',
        currency: 'EUR',
        availability: null,
        checkedAt: '2026-10-14T10:00:00.000Z',
      },
      {
        productId: 'steady-product',
        id: 'steady-previous',
        competitorUrl: 'https://shop.example/steady',
        status: 'observed',
        priceValue: '20.00',
        currency: 'EUR',
        availability: 'InStock',
        checkedAt: '2026-10-14T11:00:00.000Z',
      },
    ];
    const reportFor = (productId: string) =>
      buildShopDailyMarketReport({
        date: '2026-10-15',
        generatedAt: new Date('2026-10-15T14:00:00.000Z'),
        products: products.filter((product) => product.id === productId),
        measurements: currentMeasurements,
        previousMeasurements,
      });

    expect(reportFor('changed-product')).toMatchObject({
      status: 'movements',
      changes: [{ price: { previousValue: '10.00', currentValue: '12.00', currency: 'EUR' } }],
    });
    expect(reportFor('steady-product')).toMatchObject({ status: 'no_movements', changes: [] });
    expect(reportFor('unmeasured-product')).toMatchObject({
      status: 'no_measurements',
      changes: [],
    });
  });

  it('zeigt nur gespeicherte Preis- und Verfügbarkeitsänderungen mit beiden Messzeitpunkten', () => {
    const previousPrice: StoredProductCompetitorObservation = {
      productId: 'product-1',
      id: 'previous-price',
      competitorUrl: 'https://shop.example/price-change',
      status: 'observed',
      priceValue: '100.00',
      currency: 'EUR',
      availability: 'InStock',
      checkedAt: '2026-10-14T10:00:00.000Z',
    };
    const previousStock: StoredProductCompetitorObservation = {
      productId: 'product-1',
      id: 'previous-stock',
      competitorUrl: 'https://shop.example/stock-change',
      status: 'observed',
      priceValue: '50.00',
      currency: 'EUR',
      availability: 'InStock',
      checkedAt: '2026-10-14T09:00:00.000Z',
    };
    const previousSame: StoredProductCompetitorObservation = {
      productId: 'product-1',
      id: 'previous-same',
      competitorUrl: 'https://shop.example/unchanged',
      status: 'observed',
      priceValue: '20.00',
      currency: 'EUR',
      availability: 'InStock',
      checkedAt: '2026-10-14T08:00:00.000Z',
    };
    const previous = [previousPrice, previousStock, previousSame];
    const current: StoredProductCompetitorObservation[] = [
      {
        ...previousPrice,
        id: 'current-price',
        priceValue: '120.00',
        checkedAt: '2026-10-15T10:00:00.000Z',
      },
      {
        ...previousStock,
        id: 'current-stock',
        availability: 'OutOfStock',
        checkedAt: '2026-10-15T11:00:00.000Z',
      },
      {
        ...previousSame,
        id: 'current-same',
        checkedAt: '2026-10-15T09:00:00.000Z',
      },
      {
        productId: 'product-1',
        id: 'current-no-baseline',
        competitorUrl: 'https://shop.example/no-baseline',
        status: 'observed',
        priceValue: '39.99',
        currency: 'EUR',
        availability: 'InStock',
        checkedAt: '2026-10-15T12:00:00.000Z',
      },
    ];

    const report = buildShopDailyMarketReport({
      date: '2026-10-15',
      generatedAt: new Date('2026-10-15T13:00:00.000Z'),
      products: [{ id: 'product-1', name: 'Gespeichertes Produkt' }],
      measurements: current,
      previousMeasurements: previous,
    });

    expect(report.changes).toHaveLength(2);
    expect(report.changes.find((change) => change.id === 'product-1:current-price')).toEqual({
      id: 'product-1:current-price',
      productId: 'product-1',
      productName: 'Gespeichertes Produkt',
      productHref: '/admin/products/product-1',
      competitorUrl: 'https://shop.example/price-change',
      previousAt: '2026-10-14T10:00:00.000Z',
      currentAt: '2026-10-15T10:00:00.000Z',
      price: { previousValue: '100.00', currentValue: '120.00', currency: 'EUR' },
      availability: null,
    });
    expect(report.changes.find((change) => change.id === 'product-1:current-stock')).toMatchObject({
      productName: 'Gespeichertes Produkt',
      productHref: '/admin/products/product-1',
      competitorUrl: 'https://shop.example/stock-change',
      previousAt: '2026-10-14T09:00:00.000Z',
      currentAt: '2026-10-15T11:00:00.000Z',
      price: null,
      availability: { previousValue: 'InStock', currentValue: 'OutOfStock' },
    });
  });

  it('liefert keine Änderungen, wenn keine gespeicherten Vorher-/Nachherwerte verschieden sind', () => {
    const report = buildShopDailyMarketReport({
      date: '2026-10-15',
      generatedAt: new Date('2026-10-15T13:00:00.000Z'),
      products: [{ id: 'product-1', name: 'Gespeichertes Produkt' }],
      measurements: [
        {
          productId: 'product-1',
          id: 'current-unchanged',
          competitorUrl: 'https://shop.example/unchanged',
          status: 'observed',
          priceValue: '20.00',
          currency: 'EUR',
          availability: 'InStock',
          checkedAt: '2026-10-15T10:00:00.000Z',
        },
        {
          productId: 'product-1',
          id: 'current-no-baseline',
          competitorUrl: 'https://shop.example/no-baseline',
          status: 'observed',
          priceValue: '39.99',
          currency: 'EUR',
          availability: 'InStock',
          checkedAt: '2026-10-15T11:00:00.000Z',
        },
      ],
      previousMeasurements: [
        {
          productId: 'product-1',
          id: 'previous-unchanged',
          competitorUrl: 'https://shop.example/unchanged',
          status: 'observed',
          priceValue: '20.00',
          currency: 'EUR',
          availability: 'InStock',
          checkedAt: '2026-10-14T10:00:00.000Z',
        },
      ],
    });

    expect(report.changes).toEqual([]);
  });
});
