# Wettkiesel

Preisüberwachung für kleine Onlineshops: Wettkiesel beobachtet öffentliche Wettbewerberpreise und
Verfügbarkeiten, speichert Messverläufe und erstellt Tagesberichte mit unverbindlichen
Preisvorschlägen. Automatische Preisänderungen sind (noch) nicht aktiv.

Technik: Next.js 16 (App Router), React 19, TypeScript, Tailwind 4, Prisma 6 + PostgreSQL,
Better Auth (Login), Vitest, Biome.

Die Vorlage für dieses Projekt stammt von Polsia. Diese Version (v2) läuft auch ohne Polsia.
Welche Funktionen noch Polsia-Dienste brauchen, steht weiter unten.

---

## 1. Vor dem Livegang ausfüllen (WICHTIG)

Alle Platzhalter stehen in **`src/lib/wettkiesel-config.ts`**:

| Bereich | Was | Wo sichtbar |
|---|---|---|
| `legal` | Name/Firma, Anschrift, E-Mail, Telefon, USt-IdNr., Hosting- und DB-Anbieter | `/impressum`, `/datenschutz` |
| `founder` | Dein Name, 2–3 Sätze über dich, optional Foto (`/public/founder.jpg`) | Startseite „Wer dahinter steht“ |
| `pricingTiers` | Tarife (Vorschlag: 29 / 79 / 149 €) | Startseite „Preise“ |
| `pricingIsProposal` | `true` = Hinweis „Preise sind ein Vorschlag“ wird angezeigt | Startseite |
| `founderDiscount` | Gründungsrabatt an/aus + Text | Startseite |
| `pilotOffer` | Text des Pilotangebots | Startseite, `/pilot` |

Suche nach übrig gebliebenen Platzhaltern: `grep -rn "PLATZHALTER" src`

Die Datenschutzerklärung ist nur ein **Gerüst**. Prüfe sie mit einem Generator (z. B. eRecht24 oder
Dr. Schwenke) oder lass sie anwaltlich prüfen.

## 2. Lokal starten

Voraussetzungen: Node.js ≥ 20.18, PostgreSQL (lokal oder z. B. kostenlos bei Neon/Supabase).

```bash
npm install
cp .env.example .env        # Werte eintragen (siehe unten)
npx prisma migrate deploy   # Tabellen anlegen
npm run dev                 # http://localhost:3000
```

Postgres schnell per Docker: `docker run -d -p 5432:5432 -e POSTGRES_PASSWORD=wk -e POSTGRES_DB=wettkiesel postgres:17`
→ `DATABASE_URL=postgresql://postgres:wk@localhost:5432/wettkiesel`

Weitere Befehle:

```bash
npm run build && npm start  # Produktionsbuild
npm test                    # Unit-Tests (Vitest)
npm run typecheck           # TypeScript
npm run lint                # Biome
npx prisma studio           # Datenbank im Browser ansehen
```

## 3. Umgebungsvariablen

| Variable | Pflicht | Bedeutung |
|---|---|---|
| `DATABASE_URL` | ja | Postgres-Verbindung |
| `BETTER_AUTH_SECRET` | ja | Langer Zufallswert, z. B. `openssl rand -base64 32` |
| `BETTER_AUTH_URL` | ja | Öffentliche URL der App (lokal `http://localhost:3000`) |
| `NEXT_PUBLIC_APP_URL` | ja | Gleiche URL. Wird auch für Canonical, Sitemap und OG-Bilder genutzt |
| `POLSIA_OWNER_EMAIL` | empfohlen | Wer sich mit dieser E-Mail registriert, wird Admin (`/admin`). Der Name stammt aus der Vorlage, das Feature läuft auch ohne Polsia |
| `BETTER_AUTH_TRUSTED_ORIGINS` | optional | Weitere erlaubte Domains, kommagetrennt |
| `POLSIA_API_KEY` | für Messungen | Siehe „Polsia-Abhängigkeiten“ |
| `POLSIA_EMAIL_PROXY_URL`, `POLSIA_COMPANY_EMAIL` | optional | E-Mail-Benachrichtigung bei neuen Pilotanfragen über Polsia |
| `POLSIA_ANALYTICS_SLUG` | optional | Polsia-Besucherzähler. Ohne diesen Wert gibt es kein Tracking |

## 4. Deployment

### Vercel + Neon (Postgres)
1. Code in ein eigenes GitHub-Repo pushen.
2. Bei neon.tech eine Datenbank anlegen und die Verbindungs-URL kopieren.
3. Auf vercel.com das Repo importieren und die Variablen aus Abschnitt 3 setzen
   (`BETTER_AUTH_URL` und `NEXT_PUBLIC_APP_URL` = deine Domain).
4. Build-Befehl: `npx prisma migrate deploy && npm run build`
5. Eigene Domain verbinden (z. B. wettkiesel.de).

### Railway
1. Neues Projekt aus dem GitHub-Repo anlegen und ein Postgres-Plugin hinzufügen
   (`DATABASE_URL` wird automatisch gesetzt).
2. Variablen setzen, Build: `npm run build`, Start: `npx prisma migrate deploy && npm start`.

### Täglicher Messlauf (Cron)
`jobs/daily-competitor-checks.ts` führt die tägliche Prüfung aus, z. B. mit
`npx tsx jobs/daily-competitor-checks.ts`. Auf Railway geht das als Cron-Service, alternativ über
GitHub Actions (geplanter Workflow). Dafür braucht es derzeit `POLSIA_API_KEY` (siehe unten).

## 5. Pilotanfragen ansehen

Anfragen aus `/pilot` landen in der Tabelle `contact_message`. Als Admin siehst du sie unter
**`/admin/pilotanfragen`**. Eine E-Mail-Benachrichtigung gibt es nur mit den Polsia-E-Mail-Variablen.
Ohne sie schaust du im Admin-Bereich oder mit `npx prisma studio` nach. Eigener Versand
(z. B. Resend/SMTP) lässt sich in `src/app/api/contact/route.ts` → `notifyCompany` ergänzen.

## 6. Polsia-Abhängigkeiten (Stand v2)

| Teil | Status |
|---|---|
| Website, Login, Dashboard, Admin, Pilotformular, Impressum/Datenschutz | **läuft ohne Polsia** |
| E-Mail bei neuer Pilotanfrage (`src/lib/email/*`) | optional. Ohne Polsia wird nichts versendet, die Anfrage wird trotzdem gespeichert |
| Besucher-Analytics (`src/components/polsia-analytics.tsx`) | nur aktiv, wenn `POLSIA_ANALYTICS_SLUG` gesetzt ist |
| **Seitenabruf der Wettbewerber** (`src/modules/web-search/client.ts` → `fetchPage`) | **braucht Polsia** (`POLSIA_API_KEY`) |
| **KI-Auslesen von Preis/Verfügbarkeit** (`src/lib/ai/client.ts`, OpenAI-kompatibel über `POLSIA_AI_BASE_URL`) | **braucht Polsia** oder einen anderen OpenAI-kompatiblen Endpunkt |
| KI-Chat (`/api/ai/chat`) | braucht Polsia-KI |
| `.polsia/*`, `// @polsia:...`-Kommentare | Metadaten der Polsia-Vorlage, ohne Einfluss auf die Laufzeit |

Um ganz ohne Polsia zu messen, musst du `fetchPage` durch einen eigenen Abruf ersetzen
(z. B. `fetch` + HTML→Text oder Playwright) und `src/lib/ai/client.ts` auf einen eigenen
OpenAI-kompatiblen Anbieter mit eigenem Schlüssel umstellen. Die Aufrufstelle ist
`src/lib/business/competitor-page-reader.ts`.

## 7. Bekannte Testfehler

4 von 301 Unit-Tests schlagen fehl, im Original genauso (nicht durch v2 verursacht):
`competitor-price-suggestion`, `manual-competitor-run`, `manual-own-product-run`,
`shop-product-detail-view`.

## 8. Was in v2 geändert wurde

- Neue Startseite: Hero mit klarem Nutzen, Funktionen, kompakter Kasten „Heute / Roadmap“, Ablauf des Pilots,
  Preise (konfigurierbar), Gründer-Abschnitt, FAQ, Footer mit Impressum und Datenschutz.
- Kürzeres Pilotformular: Name, E-Mail, Shop-URL, Shopsystem, 0–5 Wettbewerber-URLs, Budget optional.
- Neue Seiten: `/impressum`, `/datenschutz` (mit Platzhaltern), `/beispielbericht` (fiktive Beispieldaten).
- SEO: neue Titel und Meta-Beschreibungen, die Sitemap enthält jetzt alle öffentlichen Seiten.
- Unabhängigkeit: Polsia-E-Mail optional, Migration für Shop-Produkte ergänzt
  (`prisma/migrations/20261019222607_add_shop_products`), `.env.example`, README.
