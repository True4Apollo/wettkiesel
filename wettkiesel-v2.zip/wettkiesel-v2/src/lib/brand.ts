// @polsia:user-owned — brand identity. Edit freely. `site.ts` re-exports
// siteName/siteDescription; `manifest.ts` + `opengraph-image.tsx` read `brandVisual`.

export const siteName = 'Wettkiesel';
export const siteDescription =
  'Preisüberwachung für kleine Onlineshops: Wettbewerberpreise und Verfügbarkeit täglich im Blick.';

// PWA + social-share colors. HEX only (CSS variables aren't readable here) — set
// them to match the theme you define in src/app/brand-theme.css. The starter
// values are achromatic placeholders, not a palette.
export const brandVisual = {
  /** PWA browser-UI / status-bar color — usually your background or primary. */
  themeColor: '#f7f6f0',
  /** PWA splash + install background. */
  backgroundColor: '#f7f6f0',
  /** Social-share (OG/Twitter) image. */
  og: {
    background: '#203e33',
    foreground: '#f7f6f0',
    /** Second line under the site name; '' hides it. */
    tagline:
      'Preisüberwachung für kleine Onlineshops: Wettbewerberpreise und Verfügbarkeit täglich im Blick.',
    /** Optional https PNG/JPEG background photo; '' keeps the plain-color card. */
    image: '',
  },
} as const;
