// @polsia:user-owned
//
// Shared zod schema for a contact message. Safe to import from a 'use client'
// file: no server-only imports, so the client can reuse the input TYPE without
// pulling in the route handler or Prisma.

import { z } from 'zod';

export const willingnessOptions = [
  '0 € pro Monat',
  '1–49 € pro Monat',
  '50–99 € pro Monat',
  '100–349 € pro Monat',
  '350 € oder mehr pro Monat',
  'Kann ich noch nicht einschätzen',
] as const;

export const shopSystemOptions = [
  'Shopify',
  'WooCommerce',
  'Shopware',
  'JTL-Shop',
  'Gambio',
  'Sonstiges / weiß nicht',
] as const;

export const contactSchema = z
  .object({
    name: z.string().min(1, 'Bitte gib deinen Namen ein.'),
    email: z.string().email('Bitte gib eine gültige E-Mail-Adresse ein.'),
    message: z.string().min(1, 'Bitte gib eine Nachricht ein.').max(25_000),
    willingness: z
      .enum(willingnessOptions, {
        invalid_type_error: 'Bitte wähle eine gültige Größenordnung aus.',
      })
      .optional(),
    fields: z.record(z.string().max(64), z.string().max(2000)).optional(),
  })
  .superRefine((input, context) => {
    if (!input.fields) return;
    if (Object.keys(input.fields).length > 20) {
      context.addIssue({ code: 'custom', path: ['fields'], message: 'Zu viele Formularangaben.' });
    }
    if (new TextEncoder().encode(JSON.stringify(input.fields)).byteLength > 8 * 1024) {
      context.addIssue({
        code: 'custom',
        path: ['fields'],
        message: 'Die Formularangaben sind zu lang.',
      });
    }
  });

export type ContactInput = z.infer<typeof contactSchema>;
