// @polsia:user-owned — FAQ content AND its shape. Edit the questions/answers and
// the CTA below. You may also EXTEND these types (e.g. add a `category` field) to
// support a richer layout — the sealed <FaqJsonLd> only reads `question` +
// `answer`, so extending FaqItem is safe. This is your content file.

export interface FaqItem {
  /** Stable identifier used by the accordion. */
  id: string;
  /** Shown in the accordion AND emitted as the JSON-LD Question name. */
  question: string;
  /** Shown in the accordion AND emitted as the JSON-LD Answer text. Plain text. */
  answer: string;
}

/** Call-to-action under the FAQ. Set the content's `cta` to null to hide it. */
export interface FaqCta {
  label: string;
  href: string;
}

export interface FaqContent {
  /** Optional intro paragraph under the H1. */
  intro?: string;
  /** The question/answer pairs — rendered in the accordion AND as FAQPage JSON-LD. */
  items: FaqItem[];
  /** The CTA under the list, or `null` for a CTA-free FAQ page. */
  cta: FaqCta | null;
}

export const faqContent: FaqContent = {
  intro:
    'Kurz erklärt, was Wettkiesel heute beobachtet, speichert und vorschlägt — und wo die Grenze zur Shop-Integration liegt.',
  items: [
    {
      id: 'was-kann-beobachtet-werden',
      question: 'Was beobachtet Wettkiesel heute?',
      answer:
        'Wettkiesel beobachtet öffentlich erreichbare Wettbewerberpreise und Produktverfügbarkeiten. Die Beobachtungen werden gespeichert, damit Preisbewegungen und andere Marktveränderungen nachvollziehbar bleiben.',
    },
    {
      id: 'gespeicherte-messungen-und-vorschlaege',
      question: 'Was wird gespeichert oder vorgeschlagen?',
      answer:
        'Gespeicherte Messungen und Marktbewegungen können im Verlauf betrachtet werden. Zusätzlich sind begrenzte Preisvorschläge darstellbar. Sie sind Hinweise, keine automatische Änderung und kein Erfolgsversprechen.',
    },
    {
      id: 'automatische-preisaenderungen',
      question: 'Ändert Wettkiesel automatisch Preise in meinem Shop?',
      answer:
        'Nein. Automatische Änderungen von Shoppreisen sind heute nicht verfügbar und nicht aktiviert. Sie kommen erst als spätere Voraussetzung infrage, wenn die konkrete Shopplattform bestätigt und passende Zugangsdaten bereitgestellt wurden.',
    },
    {
      id: 'shopplattformen-und-zugangsdaten',
      question: 'Welche Shopplattform und welche Zugangsdaten braucht ihr?',
      answer:
        'Eine konkrete Shopplattform muss zuerst bestätigt werden. Im Pilotformular werden keine Shop-, API- oder sonstigen Zugangsdaten verlangt — bitte teile dort auch keine sensiblen Zugangsdaten.',
    },
  ],
  cta: null,
};
