// @polsia:user-owned

import 'server-only';
import { createHash } from 'node:crypto';
import { z } from 'zod';
import { auth } from '@/lib/auth';
import { parseCompetitorAvailability } from '@/lib/contracts/competitor-checks';
import { prisma } from '@/lib/db';
import {
  CsvAccessError,
  type CsvServerSource,
  defineCsvSource,
  type ExportContext,
} from '@/modules/csv-export/server';

const productMeasurementsSource = defineCsvSource<MeasurementRow, { productId: string }>({
  id: 'product_competitor_measurements',
  label: 'Produkt- und Wettbewerbermessungen eines Produkts',
  schemaVersion: '2',
  columns: [
    {
      key: 'target_type',
      label: 'Messziel',
      kind: 'text',
      access: 'readonly',
      nullable: false,
      serialize: (row: MeasurementRow) =>
        row.targetType === 'own' ? 'Eigenes Produkt' : 'Wettbewerber',
    },
    {
      key: 'source_url',
      label: 'Produkt-URL',
      kind: 'text',
      access: 'readonly',
      nullable: false,
      serialize: (row: MeasurementRow) => row.competitorUrl,
    },
    {
      key: 'measured_at',
      label: 'Messzeitstempel',
      kind: 'datetime',
      access: 'readonly',
      nullable: false,
      serialize: (row: MeasurementRow) => row.measuredAt.toISOString(),
    },
    {
      key: 'price',
      label: 'Preis',
      kind: 'text',
      access: 'readonly',
      nullable: true,
      serialize: (row: MeasurementRow) => {
        if (!row.priceValue?.trim()) return null;
        return row.currency?.trim()
          ? `${row.priceValue.trim()} ${row.currency.trim()}`
          : row.priceValue.trim();
      },
    },
    {
      key: 'availability',
      label: 'Verfügbarkeit',
      kind: 'text',
      access: 'readonly',
      nullable: true,
      serialize: (row: MeasurementRow) => parseCompetitorAvailability(row.availability),
    },
  ],
  parseFilters(raw) {
    const parsed = z
      .object({ productId: z.string().trim().min(1).max(128) })
      .strict()
      .safeParse(raw);
    return parsed.success ? { ok: true, value: parsed.data } : { ok: false };
  },
  async authorizeColumns(context) {
    return context.actorId === context.scopeId
      ? ['target_type', 'source_url', 'measured_at', 'price', 'availability']
      : [];
  },
  keyOf: (row: MeasurementRow) => row.id,
  versionOf(row) {
    return createHash('sha256')
      .update(
        JSON.stringify([
          row.measuredAt.toISOString(),
          row.targetType,
          row.competitorUrl,
          row.priceValue,
          row.currency,
          row.availability,
        ]),
      )
      .digest('hex');
  },
  async readRows({ context, filters, limit, signal }) {
    if (signal.aborted) throw new Error('Export abgebrochen.');
    const rows = await prisma.$transaction(
      (transaction) =>
        transaction.competitorCheckMeasurement.findMany({
          where: {
            run: {
              productId: filters.productId,
              product: { userId: context.scopeId },
            },
          },
          orderBy: [{ createdAt: 'asc' }, { id: 'asc' }],
          take: limit,
          select: {
            id: true,
            targetType: true,
            competitorUrl: true,
            priceValue: true,
            currency: true,
            availability: true,
            checkedAt: true,
            attemptedAt: true,
            run: { select: { startedAt: true } },
          },
        }),
      { maxWait: 5_000, timeout: 25_000, isolationLevel: 'RepeatableRead' },
    );
    if (signal.aborted) throw new Error('Export abgebrochen.');
    return rows.map((row) => ({
      id: row.id,
      targetType: row.targetType,
      competitorUrl: row.competitorUrl,
      priceValue: row.priceValue,
      currency: row.currency,
      availability: parseCompetitorAvailability(row.availability),
      measuredAt: row.checkedAt ?? row.attemptedAt ?? row.run.startedAt,
    }));
  },
});

interface MeasurementRow {
  id: string;
  targetType: string;
  competitorUrl: string;
  priceValue: string | null;
  currency: string | null;
  availability: string | null;
  measuredAt: Date;
}

export const csvExportSources: CsvServerSource[] = [productMeasurementsSource];

export async function authorizeCsvExport(
  request: Request,
  _sourceId: string,
): Promise<ExportContext> {
  const session = await auth.api.getSession({ headers: request.headers });
  if (!session?.user) throw new CsvAccessError(401);
  const roles = (session.user.role ?? '').split(',').map((role) => role.trim());
  if (!roles.includes('admin')) throw new CsvAccessError(403);
  // Customize source policy here; authorizeColumns is also mandatory on every adapter.
  // For organization scopes, resolve membership on the server from this session.
  return { actorId: session.user.id, scopeId: session.user.id };
}
