// @polsia:user-owned — Vertrag für die geschützte Adminübersicht gespeicherter Bewertungen.
import { z } from 'zod';

export const MarketReportFeedbackSummary = z.object({
  helpfulCount: z.number().int().nonnegative(),
  notHelpfulCount: z.number().int().nonnegative(),
  reasons: z.array(
    z.object({
      feedbackId: z.string(),
      isUseful: z.boolean(),
      reason: z.string().trim().min(1).max(300),
      reportDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
      productName: z.string(),
      submittedAt: z.string().datetime(),
    }),
  ),
});

export type MarketReportFeedbackSummary = z.infer<typeof MarketReportFeedbackSummary>;
