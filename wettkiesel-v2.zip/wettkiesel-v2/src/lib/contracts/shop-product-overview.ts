// @polsia:user-owned — contract for the signed-in customer's product overview.
import { z } from 'zod';
import {
  CompetitorAvailabilityStatus,
  CompetitorMeasurementStatus,
} from '@/lib/contracts/competitor-checks';
import { ShopProductItem } from '@/lib/contracts/shop-products';

export const ShopProductLastCheckStatus = CompetitorMeasurementStatus;

export const ShopProductLastCheck = z.object({
  status: ShopProductLastCheckStatus,
  checkedAt: z.string().datetime().nullable(),
  attemptedAt: z.string().datetime().nullable(),
});

export const ShopProductAvailabilityMeasurement = z.object({
  measurementId: z.string(),
  availability: CompetitorAvailabilityStatus.nullable(),
  checkedAt: z.string().datetime().nullable(),
  attemptedAt: z.string().datetime().nullable(),
});

export const ShopProductCompetitorLastCheck = z.object({
  competitorUrl: z.string().url(),
  lastCheck: ShopProductLastCheck.nullable(),
  availabilityMeasurement: ShopProductAvailabilityMeasurement.nullable(),
});

export const ShopProductChangeStatus = z.object({
  changed: z.boolean().nullable(),
  comparedCompetitors: z.number().int().nonnegative(),
});

export const ShopProductMarketStatus = z.object({
  measurementsAvailable: z.boolean(),
  competitorsWithMeasurements: z.number().int().nonnegative(),
  priceChange: ShopProductChangeStatus,
  availabilityChange: ShopProductChangeStatus,
});

export const ShopProductOverviewItem = ShopProductItem.extend({
  lastCheck: ShopProductLastCheck.nullable(),
  competitorLastChecks: z.array(ShopProductCompetitorLastCheck),
  marketStatus: ShopProductMarketStatus,
});

export const ShopProductOverviewList = z.object({
  items: z.array(ShopProductOverviewItem),
});

export const ShopProductOverviewResponse = z.object({
  item: ShopProductOverviewItem,
});

export type ShopProductLastCheckStatus = z.infer<typeof ShopProductLastCheckStatus>;
export type ShopProductOverviewItem = z.infer<typeof ShopProductOverviewItem>;
export type ShopProductMarketStatus = z.infer<typeof ShopProductMarketStatus>;
