// @polsia:user-owned — shared contract for persisted shop market reports.
import { z } from 'zod';
import { CompetitorAvailabilityStatus } from '@/lib/contracts/competitor-checks';

export const MarketReportDate = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/, 'Bitte einen gültigen Tag auswählen.')
  .refine(
    (value) => {
      const date = new Date(`${value}T00:00:00.000Z`);
      return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
    },
    { message: 'Bitte einen gültigen Tag auswählen.' },
  );

const PriceDirection = z.enum(['increase', 'decrease', 'unchanged']);

export const MarketReportObservation = z.object({
  measurementId: z.string(),
  competitorUrl: z.string().url(),
  observedAt: z.string().datetime(),
  priceValue: z.string().nullable(),
  currency: z.string().nullable(),
  availability: CompetitorAvailabilityStatus.nullable(),
  comparisonAt: z.string().datetime().nullable(),
  previousPriceValue: z.string().nullable(),
  priceDirection: PriceDirection.nullable(),
  previousAvailability: CompetitorAvailabilityStatus.nullable(),
  availabilityChanged: z.boolean().nullable(),
});

export const MarketReport = z.object({
  version: z.literal(1),
  productId: z.string(),
  date: MarketReportDate,
  generatedAt: z.string().datetime(),
  storedMeasurementCount: z.number().int().nonnegative(),
  observations: z.array(MarketReportObservation),
});

export const MarketReportFeedback = z.object({
  id: z.string(),
  reportId: z.string(),
  isUseful: z.boolean(),
  reason: z.string().max(300).nullable(),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
});

export const MarketReportQueryResponse = z.object({
  report: MarketReport.nullable(),
  reportId: z.string().nullable(),
  feedback: MarketReportFeedback.nullable(),
});
export const MarketReportCreateInput = z.object({ date: MarketReportDate }).strict();
export const MarketReportCreateResponse = z.object({
  report: MarketReport,
  reportId: z.string(),
  feedback: MarketReportFeedback.nullable(),
});
export const MarketReportFeedbackInput = z
  .object({
    reportId: z.string().min(1).max(128),
    isUseful: z.boolean(),
    reason: z
      .string()
      .trim()
      .max(300, 'Der Grund darf höchstens 300 Zeichen lang sein.')
      .optional(),
  })
  .strict();
export const MarketReportFeedbackResponse = z.object({ feedback: MarketReportFeedback });

export const ShopDailyMarketChange = z.object({
  id: z.string(),
  productId: z.string(),
  productName: z.string(),
  productHref: z.string(),
  competitorUrl: z.string().url(),
  previousAt: z.string().datetime(),
  currentAt: z.string().datetime(),
  price: z
    .object({
      previousValue: z.string(),
      currentValue: z.string(),
      currency: z.string(),
    })
    .nullable(),
  availability: z
    .object({
      previousValue: CompetitorAvailabilityStatus,
      currentValue: CompetitorAvailabilityStatus,
    })
    .nullable(),
});

export const ShopDailyMarketReport = z.object({
  date: MarketReportDate,
  status: z.enum(['movements', 'no_movements', 'no_measurements', 'no_active_products']),
  changes: z.array(ShopDailyMarketChange),
});

export type MarketReport = z.infer<typeof MarketReport>;
export type MarketReportObservation = z.infer<typeof MarketReportObservation>;
export type MarketReportFeedback = z.infer<typeof MarketReportFeedback>;
export type ShopDailyMarketChange = z.infer<typeof ShopDailyMarketChange>;
export type ShopDailyMarketReport = z.infer<typeof ShopDailyMarketReport>;
