// @polsia:user-owned — shared contract for owner-scoped competitor measurements.
import { z } from 'zod';

export const CompetitorMeasurementStatus = z.enum([
  'pending',
  'processing',
  'not_checked',
  'observed',
  'partial',
  'no_data',
  'inconsistent',
  'incomplete',
  'unreadable',
  'invalid_target',
  'error',
]);

export const CompetitorCheckRunStatus = z.enum(['running', 'completed']);
export const CompetitorPriceStatus = z.enum(['not_checked', 'observed', 'unreadable']);
export const CompetitorMeasurementTarget = z.enum(['own', 'competitor']);
export const CompetitorAvailabilityStatus = z.enum([
  'BackOrder',
  'Discontinued',
  'InStock',
  'InStoreOnly',
  'LimitedAvailability',
  'MadeToOrder',
  'OnlineOnly',
  'OutOfStock',
  'PreOrder',
  'PreSale',
  'Reserved',
  'SoldOut',
]);

export function parseCompetitorAvailability(value: string | null | undefined) {
  const candidate = value?.trim();
  if (!candidate) return null;
  const parsed = CompetitorAvailabilityStatus.safeParse(candidate);
  return parsed.success ? parsed.data : null;
}

export const CompetitorMeasurement = z.object({
  id: z.string(),
  targetType: CompetitorMeasurementTarget,
  competitorUrl: z.string().url(),
  status: CompetitorMeasurementStatus,
  priceValue: z.string().nullable(),
  currency: z.string().nullable(),
  priceStatus: CompetitorPriceStatus,
  priceErrorCode: z.string().nullable(),
  priceErrorMessage: z.string().nullable(),
  availability: CompetitorAvailabilityStatus.nullable(),
  priceEvidence: z.string().nullable(),
  availabilityEvidence: z.string().nullable(),
  errorCode: z.string().nullable(),
  errorMessage: z.string().nullable(),
  checkedAt: z.string().datetime().nullable(),
  attemptedAt: z.string().datetime().nullable(),
  sourceCached: z.boolean().nullable(),
});

export const CompetitorCheckRun = z.object({
  id: z.string(),
  status: CompetitorCheckRunStatus,
  startedAt: z.string().datetime(),
  completedAt: z.string().datetime().nullable(),
  measurements: z.array(CompetitorMeasurement),
});

export const CompetitorPriceSuggestion = z.object({
  priceCents: z.number().int().positive(),
  currency: z.literal('EUR'),
  observation: z.object({
    measurementId: z.string(),
    competitorUrl: z.string().url(),
    priceValue: z.string().min(1),
    checkedAt: z.string().datetime().nullable(),
  }),
});

export const PriceSuggestionLimitEffect = z.enum(['minimum', 'maximum', 'none']);

const PriceSuggestionLimit = z.discriminatedUnion('limitEffect', [
  z.object({
    limitEffect: z.literal('minimum'),
    limitPriceCents: z.number().int().positive(),
  }),
  z.object({
    limitEffect: z.literal('maximum'),
    limitPriceCents: z.number().int().positive(),
  }),
  z.object({ limitEffect: z.literal('none'), limitPriceCents: z.null() }),
]);

export const ProductPriceSuggestion = CompetitorPriceSuggestion.and(PriceSuggestionLimit);

export const LatestCompetitorCheckResponse = z.object({
  ownUrl: z.string().url(),
  run: CompetitorCheckRun.nullable(),
  runs: z.array(CompetitorCheckRun),
  priceSuggestion: ProductPriceSuggestion.nullable(),
});

export const CompetitorCheckResponse = z.object({ run: CompetitorCheckRun });

export const CompetitorMeasurementResponse = z.object({
  measurement: CompetitorMeasurement,
  runStatus: CompetitorCheckRunStatus,
});

export type CompetitorMeasurementStatus = z.infer<typeof CompetitorMeasurementStatus>;
export type CompetitorCheckRunStatus = z.infer<typeof CompetitorCheckRunStatus>;
export type CompetitorPriceStatus = z.infer<typeof CompetitorPriceStatus>;
export type CompetitorMeasurementTarget = z.infer<typeof CompetitorMeasurementTarget>;
export type CompetitorAvailabilityStatus = z.infer<typeof CompetitorAvailabilityStatus>;
export type CompetitorMeasurement = z.infer<typeof CompetitorMeasurement>;
export type CompetitorCheckRun = z.infer<typeof CompetitorCheckRun>;
export type CompetitorPriceSuggestion = z.infer<typeof CompetitorPriceSuggestion>;
export type PriceSuggestionLimitEffect = z.infer<typeof PriceSuggestionLimitEffect>;
export type ProductPriceSuggestion = z.infer<typeof ProductPriceSuggestion>;
