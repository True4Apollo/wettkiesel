// @polsia:user-owned — shared zod contract for the owner-scoped shop product API.
import { z } from 'zod';

const invalidHttpUrlMessage = 'Bitte eine vollständige HTTP- oder HTTPS-Adresse eingeben.';

const httpUrl = z
  .string()
  .trim()
  .url(invalidHttpUrlMessage)
  .max(2048, 'Die URL ist zu lang.')
  .refine(
    (value) => {
      try {
        const protocol = new URL(value).protocol;
        return protocol === 'http:' || protocol === 'https:';
      } catch {
        return false;
      }
    },
    { message: invalidHttpUrlMessage },
  );

const euroAmount = z
  .number()
  .finite('Bitte einen gültigen Preis eingeben.')
  .min(0, 'Der Preis darf nicht negativ sein.')
  .refine((value) => Math.abs(value * 100 - Math.round(value * 100)) < 1e-8, {
    message: 'Bitte höchstens zwei Nachkommastellen verwenden.',
  });

// Stored values are deliberately more permissive than new input so legacy rows
// remain readable and can be reviewed and corrected in the owner interface.
const storedEuroAmount = z.number().finite();

export function isValidProductPriceRange(minPrice: number, maxPrice: number) {
  return (
    Number.isFinite(minPrice) &&
    Number.isFinite(maxPrice) &&
    minPrice > 0 &&
    maxPrice > 0 &&
    minPrice <= maxPrice
  );
}

const minimumPrice = euroAmount.refine((value) => value > 0, {
  message: 'Der Mindestpreis muss größer als 0 € sein.',
});

const maximumPrice = euroAmount.refine((value) => value > 0, {
  message: 'Der Höchstpreis muss größer als 0 € sein.',
});

export const ShopProductInput = z
  .object({
    name: z.string().trim().min(1, 'Bitte einen Produktnamen eingeben.').max(120),
    ownUrl: httpUrl,
    competitorUrls: z.array(httpUrl).max(20, 'Es sind höchstens 20 Wettbewerber-URLs möglich.'),
    minPrice: minimumPrice,
    maxPrice: maximumPrice,
  })
  .strict()
  .superRefine((value, context) => {
    if (value.maxPrice < value.minPrice) {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Der Höchstpreis muss mindestens dem Mindestpreis entsprechen.',
        path: ['maxPrice'],
      });
    }
  });

export const ShopProductItem = z.object({
  id: z.string(),
  isArchived: z.boolean(),
  name: z.string(),
  ownUrl: httpUrl,
  competitorUrls: z.array(httpUrl),
  minPrice: storedEuroAmount,
  maxPrice: storedEuroAmount,
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
});

export const ShopProductArchiveInput = z.object({ confirmed: z.literal(true) }).strict();
export const ShopProductArchiveResponse = z.object({
  item: z.object({ id: z.string(), isArchived: z.literal(true) }),
});

export const ShopProductList = z.object({ items: z.array(ShopProductItem) });
export const ShopProductResponse = z.object({ item: ShopProductItem });

export type ShopProductInput = z.infer<typeof ShopProductInput>;
export type ShopProductArchiveInput = z.infer<typeof ShopProductArchiveInput>;
export type ShopProductItem = z.infer<typeof ShopProductItem>;
