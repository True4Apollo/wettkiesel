// @polsia:user-owned — deterministic market movement derivation from stored measurements.

import { parseCompetitorAvailability } from '@/lib/contracts/competitor-checks';
import {
  type MarketReport,
  type MarketReportObservation,
  ShopDailyMarketReport,
} from '@/lib/contracts/market-reports';

export interface StoredCompetitorObservation {
  id: string;
  targetType?: 'own' | 'competitor';
  competitorUrl: string;
  status: string;
  priceValue: string | null;
  currency: string | null;
  availability: string | null;
  checkedAt: Date | string | null;
}

export interface StoredProductCompetitorObservation extends StoredCompetitorObservation {
  productId: string;
}

interface BuildMarketReportInput {
  productId: string;
  date: string;
  generatedAt: Date;
  measurements: StoredCompetitorObservation[];
  previousMeasurements: StoredCompetitorObservation[];
}

function checkedDate(value: Date | string | null): Date | null {
  if (value === null) return null;
  const date = value instanceof Date ? value : new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function usablePrice(value: string | null): string | null {
  if (value === null || value.trim() === '') return null;
  const amount = Number(value);
  return Number.isFinite(amount) && amount >= 0 ? value.trim() : null;
}

function usableText(value: string | null): string | null {
  const text = value?.trim();
  return text ? text : null;
}

function usableAvailability(value: string | null) {
  return parseCompetitorAvailability(value);
}

function isReportObservation(measurement: StoredCompetitorObservation) {
  if (measurement.targetType === 'own') return false;
  if (!['observed', 'partial'].includes(measurement.status)) return false;
  return (
    usablePrice(measurement.priceValue) !== null ||
    usableAvailability(measurement.availability) !== null
  );
}

function compareMeasurement(
  current: StoredCompetitorObservation,
  previous: StoredCompetitorObservation | undefined,
): MarketReportObservation | null {
  const currentAt = checkedDate(current.checkedAt);
  if (!currentAt) return null;
  const previousAt = checkedDate(previous?.checkedAt ?? null);
  const priceValue = usablePrice(current.priceValue);
  const currency = usableText(current.currency);
  const previousPriceValue = usablePrice(previous?.priceValue ?? null);
  const previousCurrency = usableText(previous?.currency ?? null);
  const availability = usableAvailability(current.availability);
  const previousAvailability = usableAvailability(previous?.availability ?? null);

  let priceDirection: MarketReportObservation['priceDirection'] = null;
  if (
    priceValue !== null &&
    previousPriceValue !== null &&
    currency !== null &&
    currency === previousCurrency
  ) {
    const currentAmount = Number(priceValue);
    const previousAmount = Number(previousPriceValue);
    priceDirection =
      currentAmount > previousAmount
        ? 'increase'
        : currentAmount < previousAmount
          ? 'decrease'
          : 'unchanged';
  }

  const hasAvailabilityComparison = Boolean(availability && previousAvailability);

  return {
    measurementId: current.id,
    competitorUrl: current.competitorUrl,
    observedAt: currentAt.toISOString(),
    priceValue,
    currency,
    availability,
    comparisonAt: previousAt?.toISOString() ?? null,
    previousPriceValue: priceDirection === null ? null : previousPriceValue,
    priceDirection,
    previousAvailability: hasAvailabilityComparison ? previousAvailability : null,
    availabilityChanged: hasAvailabilityComparison ? availability !== previousAvailability : null,
  };
}

function newestByUrl(measurements: StoredCompetitorObservation[]) {
  const newest = new Map<string, StoredCompetitorObservation>();
  for (const measurement of measurements) {
    const checkedAt = checkedDate(measurement.checkedAt);
    if (!checkedAt || !isReportObservation(measurement)) continue;

    const current = newest.get(measurement.competitorUrl);
    const currentAt = checkedDate(current?.checkedAt ?? null);
    if (
      !currentAt ||
      checkedAt > currentAt ||
      (checkedAt.getTime() === currentAt.getTime() &&
        measurement.id.localeCompare(current?.id ?? '') > 0)
    ) {
      newest.set(measurement.competitorUrl, measurement);
    }
  }
  return newest;
}

export function buildMarketReport(input: BuildMarketReportInput): MarketReport {
  const dayStart = new Date(`${input.date}T00:00:00.000Z`);
  const dayEnd = new Date(dayStart.getTime() + 24 * 60 * 60 * 1000);
  const selectedDayMeasurements = input.measurements.filter((measurement) => {
    const checkedAt = checkedDate(measurement.checkedAt);
    return (
      checkedAt !== null &&
      checkedAt >= dayStart &&
      checkedAt < dayEnd &&
      isReportObservation(measurement)
    );
  });
  const latestCurrent = newestByUrl(selectedDayMeasurements);
  const previousCandidates = input.previousMeasurements.filter((measurement) => {
    const checkedAt = checkedDate(measurement.checkedAt);
    return checkedAt !== null && checkedAt < dayStart && isReportObservation(measurement);
  });
  const latestPrevious = newestByUrl(previousCandidates);

  const observations = [...latestCurrent.entries()]
    .sort(([leftUrl], [rightUrl]) => leftUrl.localeCompare(rightUrl))
    .map(([competitorUrl, current]) =>
      compareMeasurement(current, latestPrevious.get(competitorUrl)),
    )
    .filter((observation): observation is MarketReportObservation => observation !== null);

  return {
    version: 1,
    productId: input.productId,
    date: input.date,
    generatedAt: input.generatedAt.toISOString(),
    storedMeasurementCount: selectedDayMeasurements.length,
    observations,
  };
}

export function buildShopDailyMarketReport(input: {
  date: string;
  generatedAt: Date;
  products: Array<{ id: string; name: string }>;
  measurements: StoredProductCompetitorObservation[];
  previousMeasurements: StoredProductCompetitorObservation[];
}) {
  let storedMeasurementCount = 0;
  const changes = input.products.flatMap((product) => {
    const report = buildMarketReport({
      productId: product.id,
      date: input.date,
      generatedAt: input.generatedAt,
      measurements: input.measurements.filter(
        (measurement) => measurement.productId === product.id,
      ),
      previousMeasurements: input.previousMeasurements.filter(
        (measurement) => measurement.productId === product.id,
      ),
    });
    storedMeasurementCount += report.storedMeasurementCount;

    return report.observations.flatMap((observation) => {
      const price =
        (observation.priceDirection === 'increase' || observation.priceDirection === 'decrease') &&
        observation.previousPriceValue !== null &&
        observation.priceValue !== null &&
        observation.currency !== null
          ? {
              previousValue: observation.previousPriceValue,
              currentValue: observation.priceValue,
              currency: observation.currency,
            }
          : null;
      const availability =
        observation.availabilityChanged === true &&
        observation.previousAvailability !== null &&
        observation.availability !== null
          ? {
              previousValue: observation.previousAvailability,
              currentValue: observation.availability,
            }
          : null;

      if (!observation.comparisonAt || (!price && !availability)) return [];

      return [
        ShopDailyMarketReport.shape.changes.element.parse({
          id: `${product.id}:${observation.measurementId}`,
          productId: product.id,
          productName: product.name,
          productHref: `/admin/products/${encodeURIComponent(product.id)}`,
          competitorUrl: observation.competitorUrl,
          previousAt: observation.comparisonAt,
          currentAt: observation.observedAt,
          price,
          availability,
        }),
      ];
    });
  });

  changes.sort((left, right) => right.currentAt.localeCompare(left.currentAt));
  const status =
    input.products.length === 0
      ? 'no_active_products'
      : changes.length > 0
        ? 'movements'
        : storedMeasurementCount > 0
          ? 'no_movements'
          : 'no_measurements';

  return ShopDailyMarketReport.parse({ date: input.date, status, changes });
}
