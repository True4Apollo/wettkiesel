// @polsia:user-owned — atomically archives only an active product owned by the caller.
interface ArchiveShopProductStore {
  shopProduct: {
    updateMany(args: {
      where: { id: string; userId: string; isArchived: false };
      data: { isArchived: true };
    }): Promise<{ count: number }>;
  };
}

export async function archiveShopProductForOwner(
  store: ArchiveShopProductStore,
  productId: string,
  userId: string,
) {
  const result = await store.shopProduct.updateMany({
    where: { id: productId, userId, isArchived: false },
    data: { isArchived: true },
  });
  return result.count === 1;
}
