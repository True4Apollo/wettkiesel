// @polsia:user-owned — selects only persisted competitor prices with a measured timestamp.
import type { CompetitorCheckRun, CompetitorMeasurement } from '@/lib/contracts/competitor-checks';

export type CompetitorPricePoint = Omit<
  Pick<CompetitorMeasurement, 'id' | 'checkedAt' | 'priceValue' | 'currency'>,
  'checkedAt' | 'priceValue'
> & { checkedAt: string; priceValue: string; numericValue: number };

export type CompetitorPriceSeries = {
  competitorUrl: string;
  points: CompetitorPricePoint[];
};

function storedPricePoint(measurement: CompetitorMeasurement): CompetitorPricePoint | null {
  if (
    measurement.targetType !== 'competitor' ||
    measurement.priceStatus !== 'observed' ||
    !measurement.checkedAt ||
    !measurement.priceValue?.trim()
  ) {
    return null;
  }

  const storedValue = measurement.priceValue.trim();
  if (!/^\d+(?:\.\d{1,4})?$/.test(storedValue)) return null;
  const numericValue = Number(storedValue);
  if (!Number.isFinite(numericValue) || numericValue > 1_000_000_000) return null;
  if (!Number.isFinite(Date.parse(measurement.checkedAt))) return null;

  return {
    id: measurement.id,
    checkedAt: measurement.checkedAt,
    priceValue: measurement.priceValue,
    currency: measurement.currency,
    numericValue,
  };
}

export function selectCompetitorPriceHistory(runs: CompetitorCheckRun[]): CompetitorPriceSeries[] {
  const seriesByUrl = new Map<string, CompetitorPriceSeries>();

  for (const run of runs) {
    for (const measurement of run.measurements) {
      const point = storedPricePoint(measurement);
      if (!point) continue;

      const series = seriesByUrl.get(measurement.competitorUrl) ?? {
        competitorUrl: measurement.competitorUrl,
        points: [],
      };
      series.points.push(point);
      seriesByUrl.set(measurement.competitorUrl, series);
    }
  }

  return [...seriesByUrl.values()]
    .map((series) => ({
      ...series,
      points: series.points.sort(
        (left, right) =>
          Date.parse(left.checkedAt ?? '') - Date.parse(right.checkedAt ?? '') ||
          left.id.localeCompare(right.id),
      ),
    }))
    .sort((left, right) => left.competitorUrl.localeCompare(right.competitorUrl));
}
