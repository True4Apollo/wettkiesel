// @polsia:user-owned — daily idempotent batches for saved public competitor URLs.
import 'server-only';
import { persistCompetitorMeasurement } from '@/lib/business/competitor-check-persistence';
import { readCompetitorPage } from '@/lib/business/competitor-page-reader';
import { prisma } from '@/lib/db';
import {
  QuotaExceededError,
  runBatch,
  WebSearchConfigurationError,
  WebSearchError,
  WebSearchNotEnabledError,
} from '@/modules/web-search/client';

const SCHEDULE_BUDGET_MS = 15_000;
const CHECK_BUDGET_MS = 225_000;
const CHECK_ITEM_BUDGET_MS = 80_000;
const STALE_PROCESSING_MS = 120_000;

function uniqueViolation(error: unknown): boolean {
  return Boolean(
    error &&
      typeof error === 'object' &&
      'code' in error &&
      (error as { code?: unknown }).code === 'P2002',
  );
}

function batchStopError(code: string | null): Error | null {
  if (code === 'daily_quota') return new QuotaExceededError();
  if (code === 'web_search_not_enabled') return new WebSearchNotEnabledError();
  if (code === 'web_search_not_configured') return new WebSearchConfigurationError();
  if (code === 'web_search_401') return new WebSearchError(401, 'unauthorized');
  return null;
}

async function createOrLoadDailyRun(
  product: {
    id: string;
    ownUrl: string;
    competitorUrls: string[];
  },
  dateKey: string,
) {
  try {
    return await prisma.$transaction(
      async (transaction) => {
        const activeProduct = await transaction.shopProduct.findFirst({
          where: { id: product.id, isArchived: false },
          select: { id: true },
        });
        if (!activeProduct) return null;

        const existing = await transaction.competitorCheckDailySchedule.findUnique({
          where: { productId_dateKey: { productId: product.id, dateKey } },
          select: { runId: true },
        });
        if (existing) return existing.runId;

        const run = await transaction.competitorCheckRun.create({
          data: {
            productId: product.id,
            measurements: {
              create: [
                { targetType: 'own', competitorUrl: product.ownUrl },
                ...product.competitorUrls.map((competitorUrl) => ({
                  targetType: 'competitor',
                  competitorUrl,
                })),
              ],
            },
          },
        });
        await transaction.competitorCheckDailySchedule.create({
          data: { productId: product.id, runId: run.id, dateKey },
        });
        return run.id;
      },
      { isolationLevel: 'Serializable' },
    );
  } catch (error) {
    if (!uniqueViolation(error)) throw error;
    const activeProduct = await prisma.shopProduct.findFirst({
      where: { id: product.id, isArchived: false },
      select: { id: true },
    });
    if (!activeProduct) return null;
    const existing = await prisma.competitorCheckDailySchedule.findUnique({
      where: { productId_dateKey: { productId: product.id, dateKey } },
      select: { runId: true },
    });
    if (!existing) throw error;
    return existing.runId;
  }
}

async function syncDailyUrls(
  product: { id: string; ownUrl: string; competitorUrls: string[] },
  runId: string,
) {
  const stored = await prisma.competitorCheckMeasurement.findMany({
    where: { runId },
    select: { targetType: true, competitorUrl: true },
  });
  const knownTargets = new Set(
    stored.map((measurement) => `${measurement.targetType}\u0000${measurement.competitorUrl}`),
  );
  const expectedTargets = [
    { targetType: 'own', competitorUrl: product.ownUrl },
    ...product.competitorUrls.map((competitorUrl) => ({ targetType: 'competitor', competitorUrl })),
  ];
  const missingTargets = expectedTargets.filter((target) => {
    const key = `${target.targetType}\u0000${target.competitorUrl}`;
    if (knownTargets.has(key)) return false;
    knownTargets.add(key);
    return true;
  });
  if (missingTargets.length === 0) return;

  await prisma.$transaction([
    prisma.competitorCheckMeasurement.createMany({
      data: missingTargets.map((target) => ({ runId, ...target })),
    }),
    prisma.competitorCheckRun.update({
      where: { id: runId },
      data: { status: 'running', completedAt: null },
    }),
  ]);
}

async function closeExpiredDailyRuns(beforeDateKey: string) {
  const oldSchedules = await prisma.competitorCheckDailySchedule.findMany({
    where: { dateKey: { lt: beforeDateKey }, product: { isArchived: false } },
    select: { runId: true },
  });
  const oldRunIds = oldSchedules.map((schedule) => schedule.runId);
  if (oldRunIds.length === 0) return;

  const staleBefore = new Date(Date.now() - STALE_PROCESSING_MS);
  await prisma.competitorCheckMeasurement.updateMany({
    where: {
      runId: { in: oldRunIds },
      run: { product: { isArchived: false } },
      OR: [
        { status: 'pending' },
        {
          status: 'processing',
          OR: [{ processingAt: null }, { processingAt: { lte: staleBefore } }],
        },
      ],
    },
    data: {
      status: 'not_checked',
      errorCode: 'daily_window_elapsed',
      errorMessage: 'Die tägliche Prüfrunde endete, bevor diese URL abgerufen werden konnte.',
      processingAt: null,
    },
  });
  await prisma.competitorCheckRun.updateMany({
    where: {
      id: { in: oldRunIds },
      product: { isArchived: false },
      measurements: { none: { status: { in: ['pending', 'processing'] } } },
    },
    data: { status: 'completed', completedAt: new Date() },
  });
}

/** Creates or resumes today's run for every product and reads its own URL plus competitor URLs. */
export async function refreshDailyCompetitorChecks(now = new Date()) {
  const dateKey = now.toISOString().slice(0, 10);
  await closeExpiredDailyRuns(dateKey);

  const products = await prisma.shopProduct.findMany({
    where: { isArchived: false },
    select: { id: true, ownUrl: true, competitorUrls: true },
  });
  const schedules = await runBatch(
    products,
    async (product) => {
      const runId = await createOrLoadDailyRun(product, dateKey);
      if (!runId) return;
      await syncDailyUrls(product, runId);
    },
    { budgetMs: SCHEDULE_BUDGET_MS, itemBudgetMs: 1_000 },
  );

  const scheduledRuns = await prisma.competitorCheckDailySchedule.findMany({
    where: { dateKey, product: { isArchived: false } },
    select: { runId: true },
  });
  const runIds = scheduledRuns.map((schedule) => schedule.runId);
  if (runIds.length === 0) return { schedules, checks: { done: 0, failed: 0, skipped: 0 } };

  const staleBefore = new Date(Date.now() - STALE_PROCESSING_MS);
  const measurements = await prisma.competitorCheckMeasurement.findMany({
    where: {
      runId: { in: runIds },
      run: { product: { isArchived: false } },
      OR: [
        { status: 'pending' },
        {
          status: 'processing',
          OR: [{ processingAt: null }, { processingAt: { lte: staleBefore } }],
        },
      ],
    },
    include: { run: { select: { id: true, product: { select: { name: true } } } } },
    orderBy: [{ attemptedAt: { sort: 'asc', nulls: 'first' } }, { createdAt: 'asc' }],
  });

  let checks: { done: number; failed: number; skipped: number };
  try {
    checks = await runBatch(
      measurements,
      async (measurement) => {
        const attemptedAt = new Date();
        const staleProcessingBefore = new Date(attemptedAt.getTime() - STALE_PROCESSING_MS);
        const claimed = await prisma.competitorCheckMeasurement.updateMany({
          where: {
            id: measurement.id,
            run: { product: { isArchived: false } },
            OR: [
              { status: 'pending' },
              {
                status: 'processing',
                OR: [{ processingAt: null }, { processingAt: { lte: staleProcessingBefore } }],
              },
            ],
          },
          data: { status: 'processing', attemptedAt, processingAt: attemptedAt },
        });
        if (claimed.count === 0) return;

        const result = await readCompetitorPage({
          url: measurement.competitorUrl,
          productName: measurement.run.product.name,
          targetType: measurement.targetType === 'own' ? 'own' : 'competitor',
        });
        await persistCompetitorMeasurement({
          measurementId: measurement.id,
          runId: measurement.run.id,
          attemptedAt,
          result,
        });

        const stopError = batchStopError(result.errorCode);
        if (stopError) throw stopError;
      },
      { budgetMs: CHECK_BUDGET_MS, itemBudgetMs: CHECK_ITEM_BUDGET_MS },
    );
  } catch (error) {
    await prisma.competitorCheckRun.updateMany({
      where: {
        id: { in: runIds },
        product: { isArchived: false },
        measurements: { none: { status: { in: ['pending', 'processing'] } } },
      },
      data: { status: 'completed', completedAt: new Date() },
    });
    throw error;
  }

  await prisma.competitorCheckRun.updateMany({
    where: {
      id: { in: runIds },
      product: { isArchived: false },
      measurements: { none: { status: { in: ['pending', 'processing'] } } },
    },
    data: { status: 'completed', completedAt: new Date() },
  });

  return { schedules, checks };
}
