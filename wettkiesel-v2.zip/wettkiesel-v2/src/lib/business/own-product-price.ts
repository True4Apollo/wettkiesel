// @polsia:user-owned — selects only saved readings for the product's own URL.
import type { CompetitorCheckRun, CompetitorMeasurement } from '@/lib/contracts/competitor-checks';

export type OwnProductPriceStatus =
  | 'missing'
  | 'pending'
  | 'not_checked'
  | 'observed'
  | 'unreadable';

export interface OwnProductPriceSummary {
  status: OwnProductPriceStatus;
  latestAttempt: CompetitorMeasurement | null;
  lastReadablePrice: CompetitorMeasurement | null;
}

type OwnMeasurementEntry = {
  measurement: CompetitorMeasurement;
  runStartedAt: string;
};

function attemptTime(entry: OwnMeasurementEntry) {
  return entry.measurement.attemptedAt ?? entry.measurement.checkedAt ?? entry.runStartedAt;
}

function isReadablePrice(measurement: CompetitorMeasurement) {
  const amount = measurement.priceValue?.trim();
  const currency = measurement.currency?.trim();
  if (!amount || !currency || measurement.priceStatus !== 'observed' || !measurement.checkedAt) {
    return false;
  }

  const numericAmount = Number(amount);
  return Number.isFinite(numericAmount) && numericAmount >= 0;
}

export function selectOwnProductPrice(
  runs: CompetitorCheckRun[],
  ownUrl: string,
): OwnProductPriceSummary {
  const ownMeasurements: OwnMeasurementEntry[] = runs.flatMap((run) =>
    run.measurements
      .filter(
        (measurement) => measurement.targetType === 'own' && measurement.competitorUrl === ownUrl,
      )
      .map((measurement) => ({ measurement, runStartedAt: run.startedAt })),
  );

  const latestAttempt = [...ownMeasurements].sort(
    (left, right) => Date.parse(attemptTime(right)) - Date.parse(attemptTime(left)),
  )[0]?.measurement;
  const lastReadablePrice = [...ownMeasurements]
    .filter((entry) => isReadablePrice(entry.measurement))
    .sort(
      (left, right) =>
        Date.parse(right.measurement.checkedAt ?? '') -
        Date.parse(left.measurement.checkedAt ?? ''),
    )[0]?.measurement;

  let status: OwnProductPriceStatus = 'missing';
  if (latestAttempt?.status === 'pending' || latestAttempt?.status === 'processing') {
    status = 'pending';
  } else if (latestAttempt) {
    status = isReadablePrice(latestAttempt)
      ? 'observed'
      : latestAttempt.priceStatus === 'not_checked'
        ? 'not_checked'
        : 'unreadable';
  }

  return {
    status,
    latestAttempt: latestAttempt ?? null,
    lastReadablePrice: lastReadablePrice ?? null,
  };
}
