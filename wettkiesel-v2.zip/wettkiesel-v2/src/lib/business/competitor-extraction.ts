// @polsia:user-owned — deterministic validation for public competitor-page extracts.
import { z } from 'zod';
import {
  type CompetitorAvailabilityStatus as AvailabilityStatus,
  CompetitorAvailabilityStatus,
} from '@/lib/contracts/competitor-checks';

const CandidateQuotes = z
  .object({
    priceQuotes: z.array(z.string().trim().min(1).max(300)).max(10),
  })
  .strict();

const numericToken =
  /(?<![\p{L}\p{N}])([-−+]?\d+(?:[.,'’\s\u00a0]\d{3})*(?:[.,]\d{1,4})?)(?![\p{L}\p{N}])/gu;
const currencyToken = /\b(EUR|USD|GBP|CHF|CAD|AUD|JPY|PLN|SEK|NOK|DKK)\b|€|£|\$/giu;

type PriceCandidate = { value: string; currency: string; evidence: string };

export interface CompetitorExtraction {
  status:
    | 'observed'
    | 'partial'
    | 'no_data'
    | 'inconsistent'
    | 'incomplete'
    | 'unreadable'
    | 'invalid_target'
    | 'error';
  priceValue: string | null;
  currency: string | null;
  priceStatus: 'not_checked' | 'observed' | 'unreadable';
  priceErrorCode: string | null;
  priceErrorMessage: string | null;
  availability: AvailabilityStatus | null;
  priceEvidence: string | null;
  availabilityEvidence: string | null;
  errorCode: string | null;
  errorMessage: string | null;
}

function normalizeAmount(input: string): string | null {
  const negative = input.startsWith('-') || input.startsWith('−');
  if (negative || input.startsWith('+')) return null;

  const value = input.replace(/[\s'’\u00a0]/g, '');
  const comma = value.lastIndexOf(',');
  const dot = value.lastIndexOf('.');
  let whole = value;
  let fraction = '';

  if (comma >= 0 && dot >= 0) {
    const decimalIndex = Math.max(comma, dot);
    const decimalDigits = value.length - decimalIndex - 1;
    if (decimalDigits < 1 || decimalDigits > 4) return null;
    whole = value.slice(0, decimalIndex).replace(/[.,]/g, '');
    fraction = value.slice(decimalIndex + 1);
  } else if (comma >= 0 || dot >= 0) {
    const separator = comma >= 0 ? ',' : '.';
    const parts = value.split(separator);
    const finalPart = parts.at(-1) ?? '';
    const firstPart = parts[0] ?? '';
    const grouped = parts.length > 1 && finalPart.length === 3 && firstPart.length <= 3;
    if (grouped) {
      whole = parts.join('');
    } else {
      if (finalPart.length < 1 || finalPart.length > 4) return null;
      whole = parts.slice(0, -1).join('');
      fraction = finalPart;
    }
  }

  if (!/^\d+$/.test(whole)) return null;
  const number = Number(`${whole}${fraction ? `.${fraction}` : ''}`);
  if (!Number.isFinite(number) || number < 0 || number > 1_000_000_000) return null;
  const normalizedFraction = fraction.replace(/0+$/, '');
  return normalizedFraction ? `${Number(whole)}.${normalizedFraction}` : String(Number(whole));
}

function currenciesIn(quote: string): string[] {
  return [
    ...new Set(
      [...quote.matchAll(currencyToken)].flatMap((match) => {
        const value = (match[0] ?? '').toUpperCase();
        if (value === '€') return ['EUR'];
        if (value === '£') return ['GBP'];
        if (value === '$') return [];
        return [value];
      }),
    ),
  ];
}

function priceCandidates(quote: string): PriceCandidate[] {
  const currencies = currenciesIn(quote);
  if (currencies.length === 0) return [];

  const amounts = [...quote.matchAll(numericToken)].flatMap((match) => {
    const raw = match[1];
    if (!raw) return [];
    const value = normalizeAmount(raw);
    if (value === null) return [];
    return [{ value, evidence: quote }];
  });
  return amounts.flatMap((amount) => currencies.map((currency) => ({ ...amount, currency })));
}

export interface SchemaAvailabilityExtraction {
  availability: AvailabilityStatus | null;
  evidence: string | null;
  conflicting: boolean;
}

function tagAttributes(source: string) {
  const attributes = new Map<string, string>();
  for (const match of source.matchAll(
    /(?:^|\s)([^\s=/>]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g,
  )) {
    const name = match[1]?.toLowerCase();
    if (name) attributes.set(name, match[2] ?? match[3] ?? match[4] ?? '');
  }
  return attributes;
}

function normalizeSchemaAvailability(value: unknown): AvailabilityStatus | null {
  if (typeof value === 'object' && value !== null && '@id' in value) {
    return normalizeSchemaAvailability(Reflect.get(value, '@id'));
  }
  if (typeof value !== 'string') return null;

  const candidate = value.trim();
  const direct = CompetitorAvailabilityStatus.safeParse(candidate);
  if (direct.success) return direct.data;

  const compact = candidate.match(/^schema:([A-Za-z]+)$/)?.[1];
  if (compact) {
    const parsed = CompetitorAvailabilityStatus.safeParse(compact);
    if (parsed.success) return parsed.data;
  }

  try {
    const url = new URL(candidate);
    if ((url.protocol !== 'http:' && url.protocol !== 'https:') || url.hostname !== 'schema.org') {
      return null;
    }
    const segments = url.pathname.split('/').filter(Boolean);
    if (segments.length !== 1) return null;
    const parsed = CompetitorAvailabilityStatus.safeParse(segments[0]);
    return parsed.success ? parsed.data : null;
  } catch {
    return null;
  }
}

function collectJsonLdAvailability(value: unknown, output: string[]) {
  if (Array.isArray(value)) {
    for (const item of value) collectJsonLdAvailability(item, output);
    return;
  }
  if (typeof value !== 'object' || value === null) return;

  for (const [key, nested] of Object.entries(value)) {
    if (key === 'availability') {
      if (Array.isArray(nested)) {
        for (const item of nested) {
          if (typeof item === 'string') output.push(item);
          else if (typeof item === 'object' && item !== null && '@id' in item) {
            const id = Reflect.get(item, '@id');
            if (typeof id === 'string') output.push(id);
          }
        }
      } else if (typeof nested === 'string') {
        output.push(nested);
      } else if (typeof nested === 'object' && nested !== null && '@id' in nested) {
        const id = Reflect.get(nested, '@id');
        if (typeof id === 'string') output.push(id);
      }
    } else {
      collectJsonLdAvailability(nested, output);
    }
  }
}

function hasSchemaContext(value: unknown): boolean {
  if (Array.isArray(value)) return value.some(hasSchemaContext);
  if (typeof value !== 'object' || value === null) return false;
  const context = Reflect.get(value, '@context');
  if (typeof context === 'string' && /schema\.org/i.test(context)) return true;
  if (
    typeof context === 'object' &&
    context !== null &&
    /schema\.org/i.test(JSON.stringify(context))
  ) {
    return true;
  }
  return Object.values(value).some(hasSchemaContext);
}

/** Extracts only explicit Schema.org enum values from JSON-LD or Microdata. */
export function parseSchemaAvailability(source: string): SchemaAvailabilityExtraction {
  const values: string[] = [];

  for (const match of source.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi)) {
    const attributes = tagAttributes(match[1] ?? '');
    if (attributes.get('type')?.split(';')[0]?.trim().toLowerCase() !== 'application/ld+json') {
      continue;
    }
    try {
      collectJsonLdAvailability(JSON.parse(match[2] ?? '') as unknown, values);
    } catch {
      // A malformed page block is ignored; it cannot establish availability.
    }
  }

  for (const match of source.matchAll(/```(?:json|jsonld|ld\+json)?\s*([\s\S]*?)```/gi)) {
    try {
      const value: unknown = JSON.parse(match[1] ?? '');
      if (hasSchemaContext(value)) collectJsonLdAvailability(value, values);
    } catch {
      // A markdown code block that is not JSON-LD cannot establish availability.
    }
  }

  for (const match of source.matchAll(/<[^>]*>/g)) {
    const tag = match[0] ?? '';
    const attributes = tagAttributes(tag);
    const properties = (attributes.get('itemprop') ?? '').split(/\s+/);
    if (!properties.includes('availability')) continue;
    const value =
      attributes.get('href') ??
      attributes.get('content') ??
      attributes.get('resource') ??
      attributes.get('src') ??
      attributes.get('data');
    if (value) values.push(value);
  }

  const recognized = values.flatMap((value) => {
    const availability = normalizeSchemaAvailability(value);
    return availability ? [{ availability, evidence: value.trim() }] : [];
  });
  const uniqueStatuses = new Set(recognized.map((item) => item.availability));
  const conflicting =
    uniqueStatuses.size > 1 || (recognized.length > 0 && recognized.length < values.length);
  return {
    availability: conflicting ? null : (recognized[0]?.availability ?? null),
    evidence: conflicting
      ? [...new Set(recognized.map((item) => item.evidence))].join(' · ').slice(0, 1000) || null
      : (recognized[0]?.evidence ?? null),
    conflicting,
  };
}

function emptyResult(
  status: CompetitorExtraction['status'],
  errorCode: string | null = null,
  errorMessage: string | null = null,
): CompetitorExtraction {
  const detail = errorMessage ?? 'Kein eindeutig belegbarer Preis gefunden.';
  return {
    status,
    priceValue: null,
    currency: null,
    priceStatus: 'unreadable',
    priceErrorCode: errorCode ?? 'price_unreadable',
    priceErrorMessage: `Preis nicht auslesbar: ${detail}`,
    availability: null,
    priceEvidence: null,
    availabilityEvidence: null,
    errorCode,
    errorMessage,
  };
}

export function parseCompetitorExtraction(
  sourceText: string,
  untrustedCandidates: unknown,
  truncated = false,
): CompetitorExtraction {
  const parsed = CandidateQuotes.safeParse(untrustedCandidates);
  if (!parsed.success) {
    return emptyResult(
      'error',
      'invalid_extraction',
      'Die Seitendaten ließen sich nicht sicher auswerten.',
    );
  }

  const groundedPriceQuotes = parsed.data.priceQuotes.filter((quote) => sourceText.includes(quote));
  const groundedPriceEvidence = groundedPriceQuotes.filter(
    (quote) => /\d/.test(quote) && (currenciesIn(quote).length > 0 || /[€£$]/.test(quote)),
  );
  const prices = groundedPriceQuotes.flatMap(priceCandidates);
  const uniquePrices = new Map(
    prices.map((candidate) => [`${candidate.value}|${candidate.currency}`, candidate]),
  );

  const priceConflict = uniquePrices.size > 1;
  const structuredAvailability = parseSchemaAvailability(sourceText);
  const availabilityConflict = structuredAvailability.conflicting;
  const price = priceConflict ? undefined : [...uniquePrices.values()][0];
  const availability = availabilityConflict ? null : structuredAvailability.availability;
  const hasPrice = Boolean(price);
  const hasAvailability = Boolean(availability);

  const priceErrorCode = priceConflict
    ? 'conflicting_prices'
    : !hasPrice
      ? truncated
        ? 'truncated_page'
        : 'price_unreadable'
      : null;
  const priceErrorMessage = priceConflict
    ? 'Preis nicht auslesbar: Mehrere widersprüchliche Preisangaben wurden gefunden.'
    : !hasPrice
      ? `Preis nicht auslesbar: ${
          truncated
            ? 'Der gelesene Seitenausschnitt war unvollständig.'
            : groundedPriceQuotes.length > 0
              ? 'Die gefundenen Textstellen belegen keinen eindeutigen Betrag mit bestimmbarer Währung.'
              : 'Im Seitentext wurde kein eindeutig belegter Preis gefunden.'
        }`
      : null;
  const availabilityErrorMessage = availabilityConflict
    ? 'Mehrere widersprüchliche Verfügbarkeitsangaben wurden gefunden.'
    : null;
  const errorCode =
    priceConflict || availabilityConflict
      ? 'conflicting_signals'
      : (priceErrorCode ?? (truncated ? 'truncated_page' : null));
  const errorMessage =
    [priceErrorMessage, availabilityErrorMessage].filter(Boolean).join(' ') ||
    (truncated ? 'Der gelesene Seitenausschnitt war unvollständig.' : null);

  if (!hasPrice && !hasAvailability) {
    return {
      ...emptyResult(
        truncated
          ? 'incomplete'
          : priceConflict || availabilityConflict
            ? 'inconsistent'
            : 'no_data',
        errorCode ?? 'price_unreadable',
        errorMessage ?? priceErrorMessage ?? 'Kein eindeutig lesbarer Preis gefunden.',
      ),
      priceStatus: 'unreadable',
      priceErrorCode,
      priceErrorMessage,
      availability,
      availabilityEvidence: structuredAvailability.evidence,
      priceEvidence: [...new Set(groundedPriceEvidence)].join(' · ').slice(0, 1000) || null,
    };
  }

  return {
    status:
      priceConflict || availabilityConflict
        ? 'inconsistent'
        : truncated
          ? 'incomplete'
          : hasPrice && hasAvailability
            ? 'observed'
            : 'partial',
    priceValue: price?.value ?? null,
    currency: price?.currency ?? null,
    priceStatus: hasPrice ? 'observed' : 'unreadable',
    priceErrorCode,
    priceErrorMessage,
    availability,
    priceEvidence:
      price?.evidence ?? ([...new Set(groundedPriceEvidence)].join(' · ').slice(0, 1000) || null),
    availabilityEvidence: structuredAvailability.evidence,
    errorCode,
    errorMessage,
  };
}
