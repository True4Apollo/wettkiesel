// @polsia:user-owned — server-side authorization shared by shop product routes.
import 'server-only';
import { headers } from 'next/headers';
import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';

type ProductAdminAccess = { ok: true; userId: string } | { ok: false; response: NextResponse };

export async function authorizeProductAdmin(): Promise<ProductAdminAccess> {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session?.user) {
    return {
      ok: false,
      response: NextResponse.json({ error: 'unauthorized' }, { status: 401 }),
    };
  }

  const roles = (session.user.role ?? '').split(',').map((role) => role.trim());
  if (!roles.includes('admin')) {
    return {
      ok: false,
      response: NextResponse.json({ error: 'forbidden' }, { status: 403 }),
    };
  }

  return { ok: true, userId: session.user.id };
}
