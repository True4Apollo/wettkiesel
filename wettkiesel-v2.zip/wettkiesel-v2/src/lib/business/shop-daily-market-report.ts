// @polsia:user-owned — owner-scoped summary of stored daily competitor movements.
import 'server-only';
import { buildShopDailyMarketReport } from '@/lib/business/market-report';
import { prisma } from '@/lib/db';

const REPORTABLE_STATUSES = ['observed', 'partial'] as const;

export async function getShopDailyMarketReport(userId: string, date: string) {
  const products = await prisma.shopProduct.findMany({
    where: { userId, isArchived: false },
    select: { id: true, name: true },
  });
  if (products.length === 0) {
    return buildShopDailyMarketReport({
      date,
      generatedAt: new Date(),
      products: [],
      measurements: [],
      previousMeasurements: [],
    });
  }

  const productIds = products.map((product) => product.id);
  const dayStart = new Date(`${date}T00:00:00.000Z`);
  const dayEnd = new Date(dayStart.getTime() + 24 * 60 * 60 * 1000);
  const currentRows = await prisma.competitorCheckMeasurement.findMany({
    where: {
      run: { productId: { in: productIds } },
      targetType: 'competitor',
      status: { in: [...REPORTABLE_STATUSES] },
      checkedAt: { gte: dayStart, lt: dayEnd },
    },
    select: {
      id: true,
      competitorUrl: true,
      status: true,
      priceValue: true,
      currency: true,
      availability: true,
      checkedAt: true,
      run: { select: { productId: true } },
    },
    orderBy: [{ checkedAt: 'asc' }, { id: 'asc' }],
  });

  const competitorUrls = [...new Set(currentRows.map((measurement) => measurement.competitorUrl))];
  const previousRows = competitorUrls.length
    ? await prisma.competitorCheckMeasurement.findMany({
        where: {
          run: { productId: { in: productIds } },
          targetType: 'competitor',
          status: { in: [...REPORTABLE_STATUSES] },
          competitorUrl: { in: competitorUrls },
          checkedAt: { lt: dayStart },
        },
        select: {
          id: true,
          competitorUrl: true,
          status: true,
          priceValue: true,
          currency: true,
          availability: true,
          checkedAt: true,
          run: { select: { productId: true } },
        },
        orderBy: [{ checkedAt: 'desc' }, { id: 'desc' }],
      })
    : [];

  const observations = (
    rows: typeof currentRows,
  ): Array<{
    productId: string;
    id: string;
    competitorUrl: string;
    status: string;
    priceValue: string | null;
    currency: string | null;
    availability: string | null;
    checkedAt: Date | null;
  }> =>
    rows.map((measurement) => ({
      productId: measurement.run.productId,
      id: measurement.id,
      competitorUrl: measurement.competitorUrl,
      status: measurement.status,
      priceValue: measurement.priceValue,
      currency: measurement.currency,
      availability: measurement.availability,
      checkedAt: measurement.checkedAt,
    }));

  return buildShopDailyMarketReport({
    date,
    generatedAt: new Date(),
    products,
    measurements: observations(currentRows),
    previousMeasurements: observations(previousRows),
  });
}
