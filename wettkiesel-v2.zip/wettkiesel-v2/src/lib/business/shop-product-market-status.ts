// @polsia:user-owned — compares only consecutive saved observations per competitor.
import {
  type CompetitorAvailabilityStatus,
  parseCompetitorAvailability,
} from '@/lib/contracts/competitor-checks';
import type { ShopProductMarketStatus } from '@/lib/contracts/shop-product-overview';

const STORED_RESULT_STATUSES = new Set([
  'observed',
  'partial',
  'no_data',
  'inconsistent',
  'incomplete',
  'unreadable',
  'invalid_target',
  'error',
]);

export interface ShopProductObservation {
  id: string;
  targetType: string;
  competitorUrl: string;
  status: string;
  checkedAt: string | null;
  createdAt: string;
  priceValue: string | null;
  currency: string | null;
  priceStatus: string | null;
  availability: string | null;
}

type ReadablePrice = { amount: number; currency: string | null };

function readablePrice(observation: ShopProductObservation): ReadablePrice | null {
  const priceValue = observation.priceValue?.trim();
  const hasObservedStatus =
    observation.priceStatus === 'observed' ||
    (observation.priceStatus === null && priceValue !== undefined);
  if (!priceValue || !hasObservedStatus) return null;

  const amount = Number(priceValue);
  if (!Number.isFinite(amount) || amount < 0) return null;

  return {
    amount,
    currency: observation.currency?.trim().toUpperCase() || null,
  };
}

function compareNewest<T>(
  observations: ShopProductObservation[],
  readValue: (observation: ShopProductObservation) => T | null,
  valuesEqual: (left: T, right: T) => boolean | null,
) {
  let changed = false;
  let comparedCompetitors = 0;

  const byCompetitor = new Map<string, ShopProductObservation[]>();
  for (const observation of observations) {
    const competitorObservations = byCompetitor.get(observation.competitorUrl) ?? [];
    competitorObservations.push(observation);
    byCompetitor.set(observation.competitorUrl, competitorObservations);
  }

  for (const competitorObservations of byCompetitor.values()) {
    competitorObservations.sort((left, right) => {
      const checkedAtDifference =
        Date.parse(right.checkedAt ?? '') - Date.parse(left.checkedAt ?? '');
      if (checkedAtDifference !== 0) return checkedAtDifference;

      const createdAtDifference = Date.parse(right.createdAt) - Date.parse(left.createdAt);
      if (createdAtDifference !== 0) return createdAtDifference;
      return right.id.localeCompare(left.id);
    });

    const newest = competitorObservations[0];
    const previous = competitorObservations[1];
    if (!newest || !previous) continue;

    const newestValue = readValue(newest);
    const previousValue = readValue(previous);
    if (newestValue === null || previousValue === null) continue;

    const isEqual = valuesEqual(newestValue, previousValue);
    if (isEqual === null) continue;

    comparedCompetitors += 1;
    if (!isEqual) changed = true;
  }

  return {
    changed: comparedCompetitors > 0 ? changed : null,
    comparedCompetitors,
  };
}

export function summarizeShopProductMarketStatus(
  competitorUrls: string[],
  measurements: ShopProductObservation[],
): ShopProductMarketStatus {
  const configuredCompetitors = new Set(competitorUrls);
  const observations = measurements.filter(
    (measurement) =>
      measurement.targetType === 'competitor' &&
      configuredCompetitors.has(measurement.competitorUrl) &&
      measurement.checkedAt !== null &&
      STORED_RESULT_STATUSES.has(measurement.status),
  );

  const competitorsWithMeasurements = new Set<string>();
  for (const observation of observations) {
    const price = readablePrice(observation);
    const availability = parseCompetitorAvailability(observation.availability);
    if (price || availability) competitorsWithMeasurements.add(observation.competitorUrl);
  }

  const priceChange = compareNewest(observations, readablePrice, (left, right) => {
    if (!left.currency || !right.currency || left.currency !== right.currency) return null;
    return left.amount === right.amount;
  });

  const availabilityChange = compareNewest<CompetitorAvailabilityStatus>(
    observations,
    (observation) => parseCompetitorAvailability(observation.availability),
    (left, right) => left === right,
  );

  return {
    measurementsAvailable: competitorsWithMeasurements.size > 0,
    competitorsWithMeasurements: competitorsWithMeasurements.size,
    priceChange,
    availabilityChange,
  };
}
