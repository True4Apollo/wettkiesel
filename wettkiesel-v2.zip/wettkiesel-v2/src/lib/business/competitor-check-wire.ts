// @polsia:user-owned — converts persisted competitor checks to the shared API contract.
import {
  CompetitorCheckRun,
  CompetitorMeasurement,
  parseCompetitorAvailability,
} from '@/lib/contracts/competitor-checks';

type MeasurementRecord = {
  id: string;
  targetType: string;
  competitorUrl: string;
  status: string;
  priceValue: string | null;
  currency: string | null;
  priceStatus: string | null;
  priceErrorCode: string | null;
  priceErrorMessage: string | null;
  availability: string | null;
  priceEvidence: string | null;
  availabilityEvidence: string | null;
  errorCode: string | null;
  errorMessage: string | null;
  checkedAt: Date | null;
  attemptedAt: Date | null;
  sourceCached: boolean | null;
};

type RunRecord = {
  id: string;
  status: string;
  startedAt: Date;
  completedAt: Date | null;
  measurements: MeasurementRecord[];
};

export function toCompetitorMeasurement(record: MeasurementRecord) {
  const availability = parseCompetitorAvailability(record.availability);
  const priceStatus =
    record.priceStatus ??
    (record.priceValue !== null
      ? 'observed'
      : ['pending', 'processing', 'not_checked', 'error', 'invalid_target', 'unreadable'].includes(
            record.status,
          )
        ? 'not_checked'
        : 'unreadable');
  return CompetitorMeasurement.parse({
    ...record,
    targetType: record.targetType === 'own' ? 'own' : 'competitor',
    availability,
    availabilityEvidence: availability ? record.availabilityEvidence : null,
    priceStatus,
    priceErrorCode:
      record.priceErrorCode ?? (priceStatus === 'unreadable' ? record.errorCode : null),
    priceErrorMessage:
      record.priceErrorMessage ??
      (priceStatus === 'unreadable'
        ? (record.errorMessage ?? 'Kein eindeutig belegbarer Preis gespeichert.')
        : null),
    checkedAt: record.checkedAt?.toISOString() ?? null,
    attemptedAt: record.attemptedAt?.toISOString() ?? null,
  });
}

export function toCompetitorCheckRun(record: RunRecord) {
  return CompetitorCheckRun.parse({
    id: record.id,
    status: record.status,
    startedAt: record.startedAt.toISOString(),
    completedAt: record.completedAt?.toISOString() ?? null,
    measurements: record.measurements.map(toCompetitorMeasurement),
  });
}
