// @polsia:user-owned — rejects non-public HTTP targets before proxy reads.
import { lookup } from 'node:dns/promises';
import { isIP } from 'node:net';

type ResolvedAddress = { address: string };
type AddressResolver = (hostname: string) => Promise<readonly ResolvedAddress[]>;

const IPV4_NON_PUBLIC_RANGES: ReadonlyArray<readonly [string, number]> = [
  ['0.0.0.0', 8],
  ['10.0.0.0', 8],
  ['100.64.0.0', 10],
  ['127.0.0.0', 8],
  ['169.254.0.0', 16],
  ['172.16.0.0', 12],
  ['192.0.0.0', 24],
  ['192.0.2.0', 24],
  ['192.88.99.0', 24],
  ['192.168.0.0', 16],
  ['198.18.0.0', 15],
  ['198.51.100.0', 24],
  ['203.0.113.0', 24],
  ['224.0.0.0', 4],
  ['240.0.0.0', 4],
];

const IPV6_NON_PUBLIC_RANGES: ReadonlyArray<readonly [string, number]> = [
  ['2001::', 23],
  ['2001:db8::', 32],
  ['2002::', 16],
  ['3fff::', 20],
];

const NON_PUBLIC_HOST_SUFFIXES = [
  '.localhost',
  '.local',
  '.localdomain',
  '.internal',
  '.test',
  '.invalid',
  '.example',
  '.onion',
  '.home.arpa',
];

export class InvalidPublicHttpTargetError extends Error {
  constructor() {
    super('Das Ziel ist nicht öffentlich erreichbar.');
    this.name = 'InvalidPublicHttpTargetError';
  }
}

function ipv4Value(address: string): bigint {
  return address.split('.').reduce((value, octet) => (value << 8n) | BigInt(Number(octet)), 0n);
}

function ipv6Value(address: string): bigint | null {
  if (address.includes('%')) return null;

  let normalized = address.toLowerCase();
  if (normalized.includes('.')) {
    const separator = normalized.lastIndexOf(':');
    const ipv4 = normalized.slice(separator + 1);
    if (separator < 0 || isIP(ipv4) !== 4) return null;
    const value = ipv4Value(ipv4);
    normalized = `${normalized.slice(0, separator)}:${(value >> 16n).toString(16)}:${(value & 0xffffn).toString(16)}`;
  }

  const compression = normalized.indexOf('::');
  let groups: string[];
  if (compression >= 0) {
    if (normalized.indexOf('::', compression + 2) >= 0) return null;
    const left = normalized.slice(0, compression).split(':').filter(Boolean);
    const right = normalized
      .slice(compression + 2)
      .split(':')
      .filter(Boolean);
    if (left.length + right.length >= 8) return null;
    groups = [
      ...left,
      ...Array.from({ length: 8 - left.length - right.length }, () => '0'),
      ...right,
    ];
  } else {
    groups = normalized.split(':');
    if (groups.length !== 8) return null;
  }

  if (groups.some((group) => !/^[\da-f]{1,4}$/.test(group))) return null;
  return groups.reduce((value, group) => (value << 16n) | BigInt(`0x${group}`), 0n);
}

function matchesIpv4Prefix(address: string, network: string, prefix: number): boolean {
  const shift = 32n - BigInt(prefix);
  return ipv4Value(address) >> shift === ipv4Value(network) >> shift;
}

function matchesIpv6Prefix(address: string, network: string, prefix: number): boolean {
  const value = ipv6Value(address);
  const networkValue = ipv6Value(network);
  if (value === null || networkValue === null) return true;
  const shift = 128n - BigInt(prefix);
  return value >> shift === networkValue >> shift;
}

export function isPublicIpAddress(address: string): boolean {
  const family = isIP(address);
  if (family === 4) {
    return !IPV4_NON_PUBLIC_RANGES.some(([network, prefix]) =>
      matchesIpv4Prefix(address, network, prefix),
    );
  }
  if (family !== 6) return false;

  const value = ipv6Value(address);
  if (value === null || value >> 125n !== 1n) return false;
  return !IPV6_NON_PUBLIC_RANGES.some(([network, prefix]) =>
    matchesIpv6Prefix(address, network, prefix),
  );
}

async function resolveAll(hostname: string): Promise<readonly ResolvedAddress[]> {
  return lookup(hostname, { all: true, verbatim: true });
}

function normalizeHostname(hostname: string) {
  return hostname.toLowerCase().replace(/\.$/, '');
}

function isSpecialHostname(hostname: string) {
  return (
    hostname === 'localhost' ||
    !hostname.includes('.') ||
    NON_PUBLIC_HOST_SUFFIXES.some((suffix) => hostname.endsWith(suffix))
  );
}

/** Prüft URL und sämtliche für den Hostnamen zurückgegebenen Adressen vor dem Proxy-Abruf. */
export async function assertPublicHttpTarget(
  input: string,
  resolveAddresses: AddressResolver = resolveAll,
): Promise<void> {
  let url: URL;
  try {
    url = new URL(input);
  } catch {
    throw new InvalidPublicHttpTargetError();
  }

  if (
    !['http:', 'https:'].includes(url.protocol) ||
    !url.hostname ||
    url.username.length > 0 ||
    url.password.length > 0
  ) {
    throw new InvalidPublicHttpTargetError();
  }

  const hostname = normalizeHostname(url.hostname.replace(/^\[|\]$/g, ''));
  const family = isIP(hostname);
  if (family > 0) {
    if (!isPublicIpAddress(hostname)) throw new InvalidPublicHttpTargetError();
    return;
  }

  if (isSpecialHostname(hostname)) throw new InvalidPublicHttpTargetError();

  let addresses: readonly ResolvedAddress[];
  try {
    addresses = await resolveAddresses(hostname);
  } catch {
    throw new InvalidPublicHttpTargetError();
  }

  if (addresses.length === 0 || addresses.some(({ address }) => !isPublicIpAddress(address))) {
    throw new InvalidPublicHttpTargetError();
  }
}
