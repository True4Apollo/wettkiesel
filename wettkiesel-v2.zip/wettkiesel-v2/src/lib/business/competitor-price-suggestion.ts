// @polsia:user-owned — begrenzter Vorschlag aus gespeicherten Wettbewerberbeobachtungen.
import type {
  CompetitorCheckRun,
  CompetitorMeasurement,
  CompetitorPriceSuggestion,
} from '@/lib/contracts/competitor-checks';
import { isValidProductPriceRange } from '@/lib/contracts/shop-products';

interface SuggestionInput {
  competitorUrls: string[];
  minPriceCents: number;
  maxPriceCents: number;
  runs: CompetitorCheckRun[];
}

interface PriceCandidate {
  measurement: CompetitorMeasurement;
  cents: number;
  priceValue: string;
  checkedAt: string | null;
}

function priceCents(value: string | null) {
  if (!value?.trim()) return null;
  const amount = Number(value);
  if (!Number.isFinite(amount) || amount < 0) return null;
  return Math.round(amount * 100);
}

function isUsableCompetitorPrice(measurement: CompetitorMeasurement) {
  return (
    measurement.targetType === 'competitor' &&
    (measurement.status === 'observed' || measurement.status === 'partial') &&
    measurement.priceStatus === 'observed' &&
    measurement.currency?.trim().toUpperCase() === 'EUR' &&
    (measurement.checkedAt === null || !Number.isNaN(Date.parse(measurement.checkedAt)))
  );
}

export function getPriceSuggestionLimitEffect(
  priceValue: string,
  minPriceCents: number,
  maxPriceCents: number,
) {
  const competitorPriceCents = priceCents(priceValue);
  if (competitorPriceCents === null) return 'none' as const;
  if (competitorPriceCents < minPriceCents) return 'minimum' as const;
  if (competitorPriceCents > maxPriceCents) return 'maximum' as const;
  return 'none' as const;
}

export function selectCompetitorPriceSuggestion({
  competitorUrls,
  minPriceCents,
  maxPriceCents,
  runs,
}: SuggestionInput): CompetitorPriceSuggestion | null {
  if (!isValidProductPriceRange(minPriceCents / 100, maxPriceCents / 100)) return null;

  const savedUrls = new Set(competitorUrls);
  const candidates: PriceCandidate[] = [];
  for (const run of runs) {
    for (const measurement of run.measurements) {
      if (!savedUrls.has(measurement.competitorUrl) || !isUsableCompetitorPrice(measurement)) {
        continue;
      }
      const storedPrice = measurement.priceValue?.trim();
      const checkedAt = measurement.checkedAt;
      if (!storedPrice) continue;
      const cents = priceCents(storedPrice);
      if (cents !== null)
        candidates.push({ measurement, cents, priceValue: storedPrice, checkedAt });
    }
  }

  candidates.sort((left, right) => {
    if (left.cents !== right.cents) return left.cents - right.cents;
    const leftTime = left.checkedAt ? Date.parse(left.checkedAt) : Number.NEGATIVE_INFINITY;
    const rightTime = right.checkedAt ? Date.parse(right.checkedAt) : Number.NEGATIVE_INFINITY;
    if (leftTime !== rightTime) return rightTime - leftTime;
    return left.measurement.id.localeCompare(right.measurement.id);
  });

  const lowest = candidates[0];
  if (!lowest) return null;

  const measurement = lowest.measurement;
  return {
    priceCents: Math.min(maxPriceCents, Math.max(minPriceCents, lowest.cents)),
    currency: 'EUR',
    observation: {
      measurementId: measurement.id,
      competitorUrl: measurement.competitorUrl,
      priceValue: lowest.priceValue,
      checkedAt: lowest.checkedAt,
    },
  };
}
