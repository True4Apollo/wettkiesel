// @polsia:user-owned — persists one grounded public-page check into its product history.
import 'server-only';
import type { CompetitorExtraction } from '@/lib/business/competitor-extraction';
import { prisma } from '@/lib/db';

export type CompetitorPageResult = CompetitorExtraction & {
  checkedAt: string | null;
  sourceCached: boolean | null;
};

export async function persistCompetitorMeasurement(input: {
  measurementId: string;
  runId: string;
  attemptedAt: Date;
  result: CompetitorPageResult;
}) {
  return prisma.$transaction(async (transaction) => {
    const withoutMeasurement =
      input.result.status === 'invalid_target' || input.result.status === 'error';
    const measurement = await transaction.competitorCheckMeasurement.update({
      where: { id: input.measurementId },
      data: {
        status: input.result.status,
        priceValue: withoutMeasurement ? null : input.result.priceValue,
        currency: withoutMeasurement ? null : input.result.currency,
        priceStatus: input.result.priceStatus,
        priceErrorCode: input.result.priceErrorCode,
        priceErrorMessage: input.result.priceErrorMessage,
        availability: withoutMeasurement ? null : input.result.availability,
        priceEvidence: withoutMeasurement ? null : input.result.priceEvidence,
        availabilityEvidence: withoutMeasurement ? null : input.result.availabilityEvidence,
        errorCode: input.result.errorCode,
        errorMessage: input.result.errorMessage,
        checkedAt:
          input.result.status === 'invalid_target' || !input.result.checkedAt
            ? null
            : new Date(input.result.checkedAt),
        attemptedAt: input.attemptedAt,
        sourceCached: input.result.status === 'invalid_target' ? null : input.result.sourceCached,
        processingAt: null,
      },
    });
    const openMeasurements = await transaction.competitorCheckMeasurement.count({
      where: { runId: input.runId, status: { in: ['pending', 'processing'] } },
    });
    if (openMeasurements > 0) {
      return { measurement, runStatus: 'running' as const };
    }

    const run = await transaction.competitorCheckRun.update({
      where: { id: input.runId },
      data: { status: 'completed', completedAt: new Date() },
    });
    return { measurement, runStatus: run.status as 'completed' };
  });
}
