// @polsia:user-owned — loads only a customer's own products and persisted check results.
import 'server-only';
import {
  type ShopProductObservation,
  summarizeShopProductMarketStatus,
} from '@/lib/business/shop-product-market-status';
import { parseCompetitorAvailability } from '@/lib/contracts/competitor-checks';
import {
  ShopProductLastCheckStatus,
  ShopProductOverviewItem,
} from '@/lib/contracts/shop-product-overview';
import { prisma } from '@/lib/db';

const STORED_RESULT_STATUSES = [
  'pending',
  'processing',
  'not_checked',
  'observed',
  'partial',
  'no_data',
  'inconsistent',
  'incomplete',
  'unreadable',
  'invalid_target',
  'error',
] as const;

type OverviewProduct = Awaited<ReturnType<typeof prisma.shopProduct.findFirst>>;
type OverviewMeasurement = {
  id: string;
  status: string;
  targetType: string;
  competitorUrl: string;
  priceValue: string | null;
  currency: string | null;
  priceStatus: string | null;
  availability: string | null;
  checkedAt: Date | null;
  attemptedAt: Date | null;
  createdAt: Date;
  run: { productId: string; startedAt: Date };
};

function toObservation(measurement: OverviewMeasurement): ShopProductObservation {
  return {
    id: measurement.id,
    targetType: measurement.targetType,
    competitorUrl: measurement.competitorUrl,
    status: measurement.status,
    checkedAt: measurement.checkedAt?.toISOString() ?? null,
    createdAt: measurement.createdAt.toISOString(),
    priceValue: measurement.priceValue,
    currency: measurement.currency,
    priceStatus: measurement.priceStatus,
    availability: measurement.availability,
  };
}

function measurementTimestamp(measurement: OverviewMeasurement) {
  return (
    measurement.attemptedAt?.getTime() ??
    measurement.checkedAt?.getTime() ??
    measurement.run.startedAt.getTime()
  );
}

function isNewerMeasurement(candidate: OverviewMeasurement, current: OverviewMeasurement) {
  const timestampDifference = measurementTimestamp(candidate) - measurementTimestamp(current);
  if (timestampDifference !== 0) return timestampDifference > 0;

  const startedAtDifference = candidate.run.startedAt.getTime() - current.run.startedAt.getTime();
  if (startedAtDifference !== 0) return startedAtDifference > 0;

  const createdAtDifference = candidate.createdAt.getTime() - current.createdAt.getTime();
  if (createdAtDifference !== 0) return createdAtDifference > 0;
  return candidate.id.localeCompare(current.id) > 0;
}

async function findMeasurements(productIds: string[]) {
  if (productIds.length === 0) return [];

  return prisma.competitorCheckMeasurement.findMany({
    where: {
      run: { productId: { in: productIds } },
      status: { in: [...STORED_RESULT_STATUSES] },
    },
    select: {
      id: true,
      status: true,
      targetType: true,
      competitorUrl: true,
      priceValue: true,
      currency: true,
      priceStatus: true,
      availability: true,
      checkedAt: true,
      attemptedAt: true,
      createdAt: true,
      run: { select: { productId: true, startedAt: true } },
    },
    orderBy: [
      { run: { startedAt: 'desc' } },
      { attemptedAt: { sort: 'desc', nulls: 'last' } },
      { createdAt: 'desc' },
      { id: 'desc' },
    ],
  });
}

function toOverviewItem(
  product: NonNullable<OverviewProduct>,
  measurements: OverviewMeasurement[],
) {
  const lastMeasurement = measurements[0] ?? null;
  const latestCompetitorChecks = new Map<string, OverviewMeasurement>();
  const latestAvailabilityMeasurements = new Map<string, OverviewMeasurement>();
  for (const measurement of measurements) {
    if (measurement.targetType !== 'competitor') continue;
    if (!latestCompetitorChecks.has(measurement.competitorUrl)) {
      latestCompetitorChecks.set(measurement.competitorUrl, measurement);
    }
    const currentAvailabilityMeasurement = latestAvailabilityMeasurements.get(
      measurement.competitorUrl,
    );
    if (
      !currentAvailabilityMeasurement ||
      isNewerMeasurement(measurement, currentAvailabilityMeasurement)
    ) {
      latestAvailabilityMeasurements.set(measurement.competitorUrl, measurement);
    }
  }
  const observations = measurements.map(toObservation);

  return ShopProductOverviewItem.parse({
    id: product.id,
    isArchived: product.isArchived,
    name: product.name,
    ownUrl: product.ownUrl,
    competitorUrls: product.competitorUrls,
    minPrice: product.minPriceCents / 100,
    maxPrice: product.maxPriceCents / 100,
    createdAt: product.createdAt.toISOString(),
    updatedAt: product.updatedAt.toISOString(),
    lastCheck: lastMeasurement
      ? {
          status: ShopProductLastCheckStatus.parse(lastMeasurement.status),
          checkedAt: lastMeasurement.checkedAt?.toISOString() ?? null,
          attemptedAt: lastMeasurement.attemptedAt?.toISOString() ?? null,
        }
      : null,
    competitorLastChecks: product.competitorUrls.map((competitorUrl) => {
      const measurement = latestCompetitorChecks.get(competitorUrl);
      const availabilityMeasurement = latestAvailabilityMeasurements.get(competitorUrl);
      return {
        competitorUrl,
        lastCheck: measurement
          ? {
              status: ShopProductLastCheckStatus.parse(measurement.status),
              checkedAt: measurement.checkedAt?.toISOString() ?? null,
              attemptedAt: measurement.attemptedAt?.toISOString() ?? null,
            }
          : null,
        availabilityMeasurement: availabilityMeasurement
          ? {
              measurementId: availabilityMeasurement.id,
              availability: parseCompetitorAvailability(availabilityMeasurement.availability),
              checkedAt: availabilityMeasurement.checkedAt?.toISOString() ?? null,
              attemptedAt: availabilityMeasurement.attemptedAt?.toISOString() ?? null,
            }
          : null,
      };
    }),
    marketStatus: summarizeShopProductMarketStatus(product.competitorUrls, observations),
  });
}

export async function getShopProductOverview(userId: string) {
  const products = await prisma.shopProduct.findMany({
    where: { userId, isArchived: false },
    orderBy: { updatedAt: 'desc' },
  });
  if (products.length === 0) return [];

  const measurements = await findMeasurements(products.map((product) => product.id));
  const byProduct = new Map<string, OverviewMeasurement[]>();
  for (const measurement of measurements) {
    const productMeasurements = byProduct.get(measurement.run.productId) ?? [];
    productMeasurements.push(measurement);
    byProduct.set(measurement.run.productId, productMeasurements);
  }

  return products.map((product) => toOverviewItem(product, byProduct.get(product.id) ?? []));
}

export async function getShopProductOverviewItem(userId: string, productId: string) {
  const product = await prisma.shopProduct.findFirst({
    where: { id: productId, userId, isArchived: false },
  });
  if (!product) return null;

  const measurements = await findMeasurements([product.id]);
  return toOverviewItem(product, measurements);
}
