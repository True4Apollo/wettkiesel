// @polsia:user-owned — shared Wettkiesel mark used by the public site and account shells.

import styles from './brand-mark.module.css';

export function BrandMark({ small = false }: { small?: boolean }) {
  return (
    <span className={`${styles.root} wk-mark${small ? ' wk-mark-small' : ''}`} aria-hidden="true">
      <span />
      <span />
      <span />
      <span />
    </span>
  );
}
