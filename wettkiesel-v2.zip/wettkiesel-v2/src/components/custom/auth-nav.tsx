// @polsia:user-owned — seeded by polsia/modules/better-auth; restyle freely.
'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { signOut, useIsAdmin, useSession } from '@/lib/auth-client';

export function AuthNav() {
  const { data: session, isPending } = useSession();
  const isAdmin = useIsAdmin();

  // Render nothing until the session resolves — avoids a Sign-in→Profile flash.
  if (isPending) return null;

  if (!session?.user) {
    return (
      <nav className="flex items-center gap-2">
        <Button asChild variant="ghost" size="sm" className="hidden md:inline-flex">
          <Link href="/login">Anmelden</Link>
        </Button>
        <Button asChild size="sm">
          <Link href="/signup">Konto anlegen</Link>
        </Button>
      </nav>
    );
  }

  return (
    <nav className="flex items-center gap-2">
      {isAdmin ? (
        <Button asChild variant="secondary" size="sm">
          <Link href="/admin">Shopbereich</Link>
        </Button>
      ) : null}
      <Button asChild variant="ghost" size="sm" className="hidden sm:inline-flex">
        <Link href="/profile">Konto</Link>
      </Button>
      <Button
        variant="secondary"
        size="sm"
        className="hidden sm:inline-flex"
        onClick={async () => {
          await signOut();
          window.location.assign('/');
        }}
      >
        Abmelden
      </Button>
    </nav>
  );
}
