// @polsia:user-owned — manual public competitor measurements for the product owner.
'use client';

import { CircleAlert, CircleCheck, CircleSlash2, LoaderCircle, RefreshCw } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { toast } from 'sonner';
import { CompetitorPriceHistory } from '@/components/custom/admin/competitor-price-history';
import { CsvExporter } from '@/components/custom/csv-exporter';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader } from '@/components/ui/card';
import { apiFetch } from '@/lib/api-client';
import { selectOwnProductPrice } from '@/lib/business/own-product-price';
import {
  type CompetitorAvailabilityStatus,
  CompetitorCheckResponse,
  type CompetitorCheckRun,
  type CompetitorMeasurement,
  CompetitorMeasurementResponse,
  type CompetitorMeasurementStatus,
  LatestCompetitorCheckResponse,
  type ProductPriceSuggestion,
} from '@/lib/contracts/competitor-checks';

interface CompetitorMeasurementPanelProps {
  productId: string;
  competitorCount: number;
  isArchived: boolean;
  ownerScoped?: boolean;
  showCsvExport?: boolean;
  onUpdate?: () => void | Promise<void>;
}

const statusLabels: Record<CompetitorMeasurementStatus, string> = {
  pending: 'Ausstehend',
  processing: 'Wird geprüft',
  not_checked: 'Nicht geprüft',
  observed: 'Daten gefunden',
  partial: 'Teilweise ausgelesen',
  no_data: 'Keine eindeutigen Angaben',
  inconsistent: 'Widersprüchliche Angaben',
  incomplete: 'Seitenausschnitt unvollständig',
  unreadable: 'Seite nicht lesbar',
  invalid_target: 'Ziel nicht öffentlich erreichbar',
  error: 'Abruf fehlgeschlagen',
};

const availabilityLabels: Record<CompetitorAvailabilityStatus, string> = {
  BackOrder: 'Nachbestellbar',
  Discontinued: 'Nicht mehr erhältlich',
  InStock: 'Auf Lager',
  InStoreOnly: 'Nur im Geschäft',
  LimitedAvailability: 'Begrenzt verfügbar',
  MadeToOrder: 'Auf Bestellung gefertigt',
  OnlineOnly: 'Nur online',
  OutOfStock: 'Nicht auf Lager',
  PreOrder: 'Vorbestellbar',
  PreSale: 'Im Vorverkauf',
  Reserved: 'Reserviert',
  SoldOut: 'Ausverkauft',
};

const errorStatuses = new Set<CompetitorMeasurementStatus>([
  'inconsistent',
  'not_checked',
  'no_data',
  'incomplete',
  'unreadable',
  'invalid_target',
  'error',
]);

function checkRunLabel(historyRun: CompetitorCheckRun) {
  if (historyRun.status === 'running') {
    const hasOpenMeasurements = historyRun.measurements.some(
      (measurement) => measurement.status === 'pending' || measurement.status === 'processing',
    );
    return hasOpenMeasurements ? 'Läuft' : 'Unterbrochen';
  }

  return historyRun.measurements.some((measurement) => errorStatuses.has(measurement.status))
    ? 'Abgeschlossen · mit Hinweisen'
    : 'Abgeschlossen';
}

const ownPriceStatusLabels = {
  missing: 'Noch keine eigene Preismessung gespeichert.',
  pending: 'Der eigene Produktpreis wird gerade geprüft.',
  not_checked: 'Der letzte eigene Abruf hat keinen Preis ausgelesen.',
  observed: 'Der letzte eigene Abruf hat einen Preis gespeichert.',
  unreadable: 'Der letzte eigene Abruf war nicht auslesbar.',
} as const;

const formatCurrency = new Intl.NumberFormat('de-DE', {
  style: 'currency',
  currency: 'EUR',
});

function formatCheckedAt(value: string | null) {
  if (!value) return null;
  return new Intl.DateTimeFormat('de-DE', {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(new Date(value));
}

function formatPrice(value: string | null, currency: string | null) {
  const normalizedValue = value?.trim();
  if (!normalizedValue) return null;

  const numericValue = Number(normalizedValue);
  if (!Number.isFinite(numericValue) || numericValue < 0) return null;

  const fractionDigits = normalizedValue.split('.')[1]?.length ?? 0;
  const displayFractionDigits = Math.max(2, fractionDigits);
  const amount = new Intl.NumberFormat('de-DE', {
    minimumFractionDigits: displayFractionDigits,
    maximumFractionDigits: displayFractionDigits,
  }).format(numericValue);
  return currency ? `${amount} ${currency}` : amount;
}

function MeasurementRow({ measurement }: { measurement: CompetitorMeasurement }) {
  const checkedAt = formatCheckedAt(measurement.checkedAt);
  const attemptedAt = formatCheckedAt(measurement.attemptedAt);
  const attention =
    errorStatuses.has(measurement.status) || measurement.priceStatus === 'unreadable';
  const price = formatPrice(measurement.priceValue, measurement.currency);
  const availability = measurement.availability
    ? availabilityLabels[measurement.availability]
    : measurement.status === 'pending' || measurement.status === 'processing'
      ? 'Noch nicht gemessen'
      : 'Unbekannt';
  const measurementTime = checkedAt
    ? `Messzeitpunkt: ${checkedAt}`
    : attemptedAt
      ? `Prüfversuch am ${attemptedAt} · kein Messzeitpunkt gespeichert`
      : 'Kein Messzeitpunkt gespeichert';

  return (
    <li
      id={`measurement-${measurement.id}`}
      className="grid gap-3 rounded-lg border border-border/70 bg-background p-4"
    >
      <div className="flex min-w-0 flex-wrap items-start justify-between gap-3">
        <div className="grid min-w-0 gap-1">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            {measurement.targetType === 'own' ? 'Eigenes Produkt' : 'Wettbewerber'}
          </p>
          <a
            href={measurement.competitorUrl}
            target="_blank"
            rel="noreferrer noopener"
            className="min-w-0 break-all text-sm font-medium text-primary underline-offset-4 hover:underline"
          >
            {measurement.competitorUrl}
          </a>
        </div>
        <Badge variant={attention ? 'outline' : 'secondary'} className="shrink-0">
          {measurement.status === 'error' ||
          measurement.status === 'unreadable' ||
          measurement.priceStatus === 'unreadable' ? (
            <CircleAlert aria-hidden="true" className="mr-1 size-3.5" />
          ) : measurement.status === 'observed' || measurement.status === 'partial' ? (
            <CircleCheck aria-hidden="true" className="mr-1 size-3.5" />
          ) : measurement.status === 'invalid_target' ? (
            <CircleSlash2 aria-hidden="true" className="mr-1 size-3.5" />
          ) : measurement.status === 'processing' ? (
            <LoaderCircle aria-hidden="true" className="mr-1 size-3.5 animate-spin" />
          ) : null}
          {statusLabels[measurement.status]}
        </Badge>
      </div>

      <div className="grid gap-2 text-sm sm:grid-cols-2">
        <div>
          <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Preis</p>
          <p className="mt-1 font-semibold text-foreground">
            {price ??
              (measurement.priceStatus === 'unreadable'
                ? 'Nicht auslesbar'
                : measurement.priceStatus === 'not_checked'
                  ? 'Noch nicht geprüft'
                  : 'Kein Preiswert gespeichert')}
          </p>
          {measurement.priceStatus === 'observed' ? (
            <p className="mt-1 text-xs font-medium text-emerald-700 dark:text-emerald-300">
              Belegter Preis
            </p>
          ) : null}
          {measurement.priceErrorMessage ? (
            <p className="mt-1 text-xs leading-5 text-destructive">
              {measurement.priceErrorMessage}
            </p>
          ) : null}
          {measurement.priceEvidence ? (
            <p className="mt-1 break-words text-xs leading-5 text-muted-foreground">
              Beleg: „{measurement.priceEvidence}“
            </p>
          ) : null}
        </div>
        <div>
          <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
            Verfügbarkeit
          </p>
          <p className="mt-1 text-foreground">{availability}</p>
          {measurement.availabilityEvidence ? (
            <p className="mt-1 break-words text-xs leading-5 text-muted-foreground">
              Beleg: „{measurement.availabilityEvidence}“
            </p>
          ) : null}
        </div>
      </div>

      {measurement.errorMessage && measurement.errorMessage !== measurement.priceErrorMessage ? (
        <p className="text-sm text-muted-foreground">{measurement.errorMessage}</p>
      ) : null}
      <p className="text-xs text-muted-foreground">
        {measurementTime}
        {checkedAt && measurement.sourceCached ? ' · Seitendaten aus Cache gelesen' : null}
      </p>
    </li>
  );
}

export function CompetitorMeasurementPanel({
  productId,
  competitorCount,
  isArchived,
  ownerScoped = false,
  showCsvExport,
  onUpdate,
}: CompetitorMeasurementPanelProps) {
  const routeBase = `/api/${ownerScoped ? 'shop' : 'admin'}/products/${encodeURIComponent(productId)}/competitor-checks`;
  const csvExportVisible = showCsvExport ?? !ownerScoped;
  const [run, setRun] = useState<CompetitorCheckRun | null>(null);
  const [runs, setRuns] = useState<CompetitorCheckRun[]>([]);
  const [ownUrl, setOwnUrl] = useState<string | null>(null);
  const [priceSuggestion, setPriceSuggestion] = useState<ProductPriceSuggestion | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [loadError, setLoadError] = useState(false);

  const refresh = useCallback(async () => {
    setLoadError(false);
    try {
      const result = await apiFetch(routeBase, {
        schema: LatestCompetitorCheckResponse,
      });
      setRun(result.run);
      setRuns(result.runs);
      setOwnUrl(result.ownUrl);
      setPriceSuggestion(result.priceSuggestion);
    } catch {
      setLoadError(true);
    } finally {
      setLoading(false);
    }
  }, [routeBase]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const runSteps = useCallback(
    async (initialRun: CompetitorCheckRun) => {
      if (isArchived) return;
      setBusy(true);
      let currentRun = initialRun;
      try {
        for (const measurement of initialRun.measurements) {
          if (measurement.status !== 'pending' && measurement.status !== 'processing') continue;
          const result = await apiFetch(`${routeBase}/${encodeURIComponent(measurement.id)}`, {
            method: 'POST',
            schema: CompetitorMeasurementResponse,
          });
          currentRun = {
            ...currentRun,
            status: result.runStatus,
            completedAt: null,
            measurements: currentRun.measurements.map((item) =>
              item.id === result.measurement.id ? result.measurement : item,
            ),
          };
          setRun(currentRun);
          setRuns((previousRuns) =>
            previousRuns.map((item) => (item.id === currentRun.id ? currentRun : item)),
          );
        }
        await refresh();
        await onUpdate?.();
        if (
          currentRun.status === 'completed' &&
          !currentRun.measurements.some((item) => errorStatuses.has(item.status))
        ) {
          toast.success(
            'Die Prüfrunde wurde abgeschlossen. Gespeicherte Ergebnisse stehen im Verlauf.',
          );
        } else if (currentRun.status === 'completed') {
          toast.error(
            'Die Prüfrunde wurde mit Fehlern oder Hinweisen abgeschlossen. Details stehen im Verlauf.',
          );
        } else {
          toast.error(
            'Die Prüfrunde ist noch nicht abgeschlossen. Gespeicherte Zustände bleiben im Verlauf sichtbar.',
          );
        }
      } catch {
        await refresh();
        await onUpdate?.();
        toast.error('Die Prüfung wurde unterbrochen. Gespeicherte Ergebnisse bleiben erhalten.');
      } finally {
        setBusy(false);
      }
    },
    [isArchived, onUpdate, refresh, routeBase],
  );

  async function startRun() {
    if (isArchived) return;
    setBusy(true);
    try {
      const result = await apiFetch(routeBase, {
        method: 'POST',
        schema: CompetitorCheckResponse,
      });
      setRun(result.run);
      setRuns((previousRuns) => [
        result.run,
        ...previousRuns.filter((item) => item.id !== result.run.id),
      ]);
      await runSteps(result.run);
    } catch {
      setBusy(false);
      toast.error('Eine neue Prüfung konnte nicht gestartet werden.');
      await refresh();
    }
  }

  const hasResumableChecks = Boolean(
    !isArchived &&
      run?.measurements.some(
        (measurement) => measurement.status === 'pending' || measurement.status === 'processing',
      ),
  );
  const savedMeasurementCount = runs.reduce((total, historyRun) => {
    return total + historyRun.measurements.length;
  }, 0);
  const hasSavedMeasurements = savedMeasurementCount > 0;
  const ownPriceSummary = ownUrl ? selectOwnProductPrice(runs, ownUrl) : null;
  const ownPrice = ownPriceSummary?.lastReadablePrice ?? null;

  return (
    <Card className="border-border/70 shadow-sm">
      <CardHeader>
        <h2 className="text-base font-semibold leading-none tracking-tight">
          Produkt- und Wettbewerberprüfungen
        </h2>
        <CardDescription>
          Die gespeicherte Produkt-URL und alle hinterlegten Wettbewerber-URLs werden manuell und
          täglich geprüft. Messwerte, Belege, Status und Messzeitpunkt bleiben im geschützten
          Produktverlauf; Shoppreise werden nicht verändert.
        </CardDescription>
      </CardHeader>
      <CardContent className="grid gap-4">
        {isArchived ? (
          <Alert>
            <AlertTitle>Produkt archiviert</AlertTitle>
            <AlertDescription>
              Es werden keine neuen manuellen Prüfungen gestartet. Gespeicherte Messungen bleiben
              weiter unten im Verlauf abrufbar.
            </AlertDescription>
          </Alert>
        ) : (
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <Button
              type="button"
              className="w-full whitespace-normal text-center sm:w-auto sm:whitespace-nowrap"
              onClick={() => void startRun()}
              disabled={busy || loading}
            >
              {busy ? (
                <LoaderCircle aria-hidden="true" className="size-4 animate-spin" />
              ) : (
                <RefreshCw aria-hidden="true" className="size-4" />
              )}
              {hasSavedMeasurements ? 'Neue Prüfrunde starten' : 'Erste manuelle Prüfrunde starten'}
            </Button>
            {hasResumableChecks ? (
              <Button
                type="button"
                variant="outline"
                disabled={busy}
                onClick={() => run && void runSteps(run)}
              >
                Ausstehende URLs fortsetzen
              </Button>
            ) : null}
            <span className="text-xs text-muted-foreground">
              1 eigene URL · {competitorCount} gespeicherte{' '}
              {competitorCount === 1 ? 'Wettbewerber-URL' : 'Wettbewerber-URLs'}
            </span>
          </div>
        )}

        {loadError ? (
          <Alert variant="destructive">
            <AlertTitle>Messverlauf nicht verfügbar</AlertTitle>
            <AlertDescription className="flex flex-col items-start gap-3">
              Die gespeicherten Prüfergebnisse konnten nicht geladen werden.
              <Button type="button" size="sm" variant="outline" onClick={() => void refresh()}>
                Erneut laden
              </Button>
            </AlertDescription>
          </Alert>
        ) : null}

        {loading ? (
          <p aria-live="polite" className="text-sm text-muted-foreground">
            Messverlauf wird geladen …
          </p>
        ) : null}

        {!loading && !loadError && hasSavedMeasurements ? (
          <div className="grid gap-2 border-t border-border/70 pt-4">
            <p className="text-sm text-muted-foreground">
              {savedMeasurementCount} gespeicherte{' '}
              {savedMeasurementCount === 1 ? 'Messung' : 'Messungen'} für dieses Produkt.
            </p>
            {csvExportVisible ? (
              <CsvExporter
                sourceId="product_competitor_measurements"
                filters={{ productId }}
                label="Messwerte als CSV exportieren"
              />
            ) : null}
          </div>
        ) : null}

        {!loading && !loadError ? (
          <section
            aria-label="Unverbindlicher Preisvorschlag"
            className="grid gap-2 rounded-lg border border-primary/30 bg-primary/5 p-4"
          >
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Unverbindlicher Preisvorschlag
            </p>
            {priceSuggestion ? (
              <>
                <p className="text-2xl font-semibold tabular-nums text-foreground">
                  {formatCurrency.format(priceSuggestion.priceCents / 100)}
                </p>
                <p className="text-sm leading-6 text-muted-foreground">
                  Verwendeter Wettbewerberpreis:{' '}
                  {formatCurrency.format(Number(priceSuggestion.observation.priceValue))} · Quelle:{' '}
                  <a
                    href={priceSuggestion.observation.competitorUrl}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="break-all text-primary underline underline-offset-4"
                  >
                    {priceSuggestion.observation.competitorUrl}
                  </a>
                  .
                </p>
                <p className="text-sm leading-6 text-muted-foreground">
                  {formatCheckedAt(priceSuggestion.observation.checkedAt)
                    ? `Gemessen am ${formatCheckedAt(priceSuggestion.observation.checkedAt)}.`
                    : 'Für diese Messung ist kein Messzeitpunkt gespeichert.'}
                </p>
                <p className="text-xs leading-5 text-muted-foreground">
                  {priceSuggestion.limitEffect === 'minimum'
                    ? `Der Wettbewerberpreis liegt unter deinem gespeicherten Mindestpreis. Der Mindestpreis von ${formatCurrency.format(priceSuggestion.limitPriceCents / 100)} begrenzt den Vorschlag.`
                    : priceSuggestion.limitEffect === 'maximum'
                      ? `Der Wettbewerberpreis liegt über deinem gespeicherten Höchstpreis. Der Höchstpreis von ${formatCurrency.format(priceSuggestion.limitPriceCents / 100)} begrenzt den Vorschlag.`
                      : 'Keine gespeicherte Preisgrenze begrenzt den Vorschlag.'}
                </p>
                <p className="text-xs leading-5 text-muted-foreground">
                  Der Vorschlag ist unverbindlich. Er ändert den tatsächlichen Shoppreis nicht und
                  wird nicht in den Shop übertragen.
                </p>
              </>
            ) : (
              <p className="text-sm leading-6 text-muted-foreground">
                Kein Vorschlag verfügbar. Dafür braucht es gültige gespeicherte Preisgrenzen und
                eine passende Wettbewerbermessung mit belegtem Preis.
              </p>
            )}
          </section>
        ) : null}

        {!loading && !loadError && ownPriceSummary ? (
          <section
            aria-label="Zuletzt gespeicherter Eigenpreis"
            aria-live="polite"
            className="grid gap-2 rounded-lg border border-primary/30 bg-primary/5 p-4"
          >
            <div className="grid gap-1">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Zuletzt gespeicherter lesbarer Eigenpreis
              </p>
              {ownPrice ? (
                <p className="text-xl font-semibold text-foreground">
                  {formatPrice(ownPrice.priceValue, ownPrice.currency)}
                </p>
              ) : (
                <p className="text-sm font-medium text-foreground">
                  {ownPriceStatusLabels[ownPriceSummary.status]}
                </p>
              )}
            </div>
            {ownPrice ? (
              <p className="text-xs text-muted-foreground">
                Tatsächlicher Messzeitpunkt: {formatCheckedAt(ownPrice.checkedAt)}
              </p>
            ) : null}
            {ownPriceSummary.status !== 'observed' ? (
              <p className="text-sm text-muted-foreground">
                {ownPrice
                  ? `${ownPriceStatusLabels[ownPriceSummary.status]} Angezeigt wird weiterhin der zuletzt gespeicherte Wert vom genannten Messzeitpunkt.`
                  : 'Es wird kein Preis aus Preisgrenzen oder Wettbewerbermessungen übernommen.'}
              </p>
            ) : null}
          </section>
        ) : null}

        {!loading && !loadError ? <CompetitorPriceHistory runs={runs} /> : null}

        {!loading && hasSavedMeasurements ? (
          <section aria-label="Produkt- und Wettbewerber-Prüfverlauf" className="grid gap-3">
            <h3 className="border-t border-border/70 pt-4 text-sm font-semibold text-foreground">
              Gespeicherter Prüfverlauf
            </h3>
            {runs.map((historyRun, index) => (
              <details
                key={historyRun.id}
                open={index === 0}
                className="rounded-lg border border-border/70 bg-background p-4"
              >
                <summary className="cursor-pointer text-sm font-medium text-foreground">
                  {index === 0 ? 'Neueste Prüfrunde' : 'Prüfrunde'} ·{' '}
                  {formatCheckedAt(historyRun.startedAt)} · {checkRunLabel(historyRun)}
                  {historyRun.completedAt
                    ? ` · beendet ${formatCheckedAt(historyRun.completedAt)}`
                    : null}
                </summary>
                <ul className="mt-4 grid gap-3">
                  {historyRun.measurements.map((measurement) => (
                    <MeasurementRow key={measurement.id} measurement={measurement} />
                  ))}
                </ul>
              </details>
            ))}
          </section>
        ) : !loading && !loadError ? (
          <output className="text-sm text-muted-foreground">
            Noch keine Produkt- oder Wettbewerbermessungen gespeichert. Nach der ersten Prüfung
            erscheinen die gespeicherten Messwerte und Laufzustände hier.
          </output>
        ) : null}
      </CardContent>
    </Card>
  );
}
