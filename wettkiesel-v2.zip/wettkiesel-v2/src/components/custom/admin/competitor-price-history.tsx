// @polsia:user-owned — compact per-competitor chart for persisted price observations.
'use client';

import {
  type CompetitorPricePoint,
  selectCompetitorPriceHistory,
} from '@/lib/business/competitor-price-history';
import type { CompetitorCheckRun } from '@/lib/contracts/competitor-checks';

type CompetitorPriceHistoryProps = { runs: CompetitorCheckRun[] };

function formatDate(value: string) {
  return new Intl.DateTimeFormat('de-DE', {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(new Date(value));
}

function formatPrice(point: CompetitorPricePoint) {
  const fractionDigits = point.priceValue.split('.')[1]?.length ?? 0;
  const amount = new Intl.NumberFormat('de-DE', {
    minimumFractionDigits: Math.max(2, fractionDigits),
    maximumFractionDigits: Math.max(2, fractionDigits),
  }).format(point.numericValue);

  return point.currency ? `${amount} ${point.currency}` : amount;
}

function pointPosition(index: number, pointCount: number, value: number, min: number, max: number) {
  const x = pointCount === 1 ? 320 : 32 + (index / (pointCount - 1)) * 576;
  const y = max === min ? 82 : 132 - ((value - min) / (max - min)) * 100;
  return { x, y };
}

function CompetitorSeries({
  competitorUrl,
  points,
}: {
  competitorUrl: string;
  points: CompetitorPricePoint[];
}) {
  const values = points.map((point) => point.numericValue);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const plottedPoints = points.map((point, index) => ({
    point,
    ...pointPosition(index, points.length, point.numericValue, min, max),
  }));

  return (
    <figure className="grid min-w-0 gap-2 rounded-lg border border-border/70 bg-background p-3 sm:p-4">
      <figcaption className="grid min-w-0 gap-1">
        <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Wettbewerber
        </span>
        <span className="break-all text-sm font-medium text-foreground">{competitorUrl}</span>
      </figcaption>
      <svg
        aria-label={`Preisverlauf für ${competitorUrl} mit ${points.length} gespeicherten Messpunkten`}
        className="h-36 w-full overflow-visible text-primary"
        role="img"
        viewBox="0 0 640 160"
        preserveAspectRatio="none"
      >
        <line x1="16" y1="132" x2="624" y2="132" className="stroke-border" strokeWidth="1" />
        {points.length > 1 ? (
          <polyline
            points={plottedPoints.map(({ x, y }) => `${x},${y}`).join(' ')}
            fill="none"
            className="stroke-primary"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
            vectorEffect="non-scaling-stroke"
          />
        ) : null}
        {plottedPoints.map(({ point, x, y }) => {
          return (
            <circle
              key={point.id}
              cx={x}
              cy={y}
              r="5"
              className="fill-primary stroke-background"
              strokeWidth="2"
            >
              <title>{`${formatDate(point.checkedAt)} · ${formatPrice(point)}`}</title>
            </circle>
          );
        })}
      </svg>
      <ol aria-label={`Gespeicherte Preise für ${competitorUrl}`} className="grid gap-1">
        {points.map((point) => (
          <li
            key={point.id}
            className="grid grid-cols-[minmax(0,1fr)_auto] gap-3 border-t border-border/60 py-1.5 text-xs"
          >
            <time className="min-w-0 text-muted-foreground" dateTime={point.checkedAt}>
              {formatDate(point.checkedAt)}
            </time>
            <span className="font-semibold tabular-nums text-foreground">{formatPrice(point)}</span>
          </li>
        ))}
      </ol>
    </figure>
  );
}

export function CompetitorPriceHistory({ runs }: CompetitorPriceHistoryProps) {
  const series = selectCompetitorPriceHistory(runs);

  return (
    <section
      aria-label="Wettbewerber-Preisverlauf"
      className="grid gap-3 border-t border-border/70 pt-4"
    >
      <div className="grid gap-1">
        <h3 className="text-sm font-semibold text-foreground">Preisverlauf je Wettbewerber</h3>
        <p className="text-xs text-muted-foreground">
          Gezeigt werden nur gespeicherte Preise mit tatsächlichem Messzeitpunkt.
        </p>
      </div>
      {series.length > 0 ? (
        <div className="grid gap-3 lg:grid-cols-2">
          {series.map((competitor) => (
            <CompetitorSeries
              key={competitor.competitorUrl}
              competitorUrl={competitor.competitorUrl}
              points={competitor.points}
            />
          ))}
        </div>
      ) : (
        <p className="rounded-lg border border-dashed border-border px-4 py-5 text-sm text-muted-foreground">
          Noch keine gespeicherten Wettbewerberpreise. Sobald ein Preis mit Messdatum vorliegt,
          erscheint der Verlauf hier.
        </p>
      )}
    </section>
  );
}
