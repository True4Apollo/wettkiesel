// @polsia:user-owned
'use client';

import {
  Archive,
  ArrowUpRight,
  CircleSlash2,
  ExternalLink,
  PackagePlus,
  RefreshCw,
} from 'lucide-react';
import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { apiFetch } from '@/lib/api-client';
import {
  isValidProductPriceRange,
  ShopProductArchiveResponse,
  type ShopProductItem,
  ShopProductList as ShopProductListSchema,
} from '@/lib/contracts/shop-products';

const formatPrice = new Intl.NumberFormat('de-DE', {
  style: 'currency',
  currency: 'EUR',
});

export function ShopProductList() {
  const [products, setProducts] = useState<ShopProductItem[] | null>(null);
  const [archivedProducts, setArchivedProducts] = useState<ShopProductItem[] | null>(null);
  const [error, setError] = useState(false);
  const [archivedError, setArchivedError] = useState(false);
  const [archivedLoading, setArchivedLoading] = useState(false);
  const [showArchived, setShowArchived] = useState(false);
  const [archiveTarget, setArchiveTarget] = useState<ShopProductItem | null>(null);
  const [archiving, setArchiving] = useState(false);

  const loadProducts = useCallback(async () => {
    setError(false);
    try {
      const result = await apiFetch('/api/admin/products', { schema: ShopProductListSchema });
      setProducts(result.items);
    } catch {
      setError(true);
    }
  }, []);

  useEffect(() => {
    void loadProducts();
  }, [loadProducts]);

  async function toggleArchivedProducts() {
    if (showArchived) {
      setShowArchived(false);
      return;
    }

    setShowArchived(true);
    if (archivedProducts !== null) return;

    setArchivedError(false);
    setArchivedLoading(true);
    try {
      const result = await apiFetch('/api/admin/products?status=archived', {
        schema: ShopProductListSchema,
      });
      setArchivedProducts(result.items);
    } catch {
      setArchivedError(true);
    } finally {
      setArchivedLoading(false);
    }
  }

  async function confirmArchive() {
    if (!archiveTarget) return;
    setArchiving(true);
    try {
      const result = await apiFetch(`/api/admin/products/${archiveTarget.id}/archive`, {
        method: 'POST',
        body: JSON.stringify({ confirmed: true }),
        schema: ShopProductArchiveResponse,
      });
      setProducts((current) => current?.filter((product) => product.id !== result.item.id) ?? null);
      setArchivedProducts((current) =>
        current ? [{ ...archiveTarget, isArchived: true }, ...current] : current,
      );
      setArchiveTarget(null);
      toast.success('Produkt archiviert. Messverlauf und Berichte bleiben erhalten.');
    } catch {
      toast.error('Das Produkt konnte nicht archiviert werden. Bitte lade die Liste neu.');
    } finally {
      setArchiving(false);
    }
  }

  return (
    <div className="grid gap-6">
      <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="grid gap-2">
          <p className="text-sm font-medium uppercase tracking-[0.12em] text-primary">
            Shopverwaltung
          </p>
          <h1 className="text-3xl font-semibold tracking-tight text-foreground">Produkte</h1>
          <p className="max-w-2xl text-sm leading-6 text-muted-foreground">
            Hinterlege Produktseiten und Preisgrenzen für deinen Wettbewerbsüberblick.
          </p>
        </div>
        <Button asChild className="w-full sm:w-auto">
          <Link href="/admin/products/new">
            <PackagePlus aria-hidden="true" className="size-4" />
            Produkt hinzufügen
          </Link>
        </Button>
      </header>

      <Card className="border-border/70 shadow-sm">
        <CardHeader className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="grid gap-1">
            <CardTitle className="text-base">Aktive Produkte</CardTitle>
            <p className="text-sm text-muted-foreground">
              {products === null
                ? 'Bestand wird geladen'
                : `${products.length} aktiv${products.length === 1 ? '' : 'e'}`}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="secondary" className="gap-1.5 font-medium">
              <CircleSlash2 aria-hidden="true" className="size-3.5" />
              Preisänderungen aus
            </Badge>
            <Button type="button" variant="outline" onClick={() => void toggleArchivedProducts()}>
              <Archive aria-hidden="true" className="size-4" />
              {showArchived ? 'Archivierte ausblenden' : 'Archivierte anzeigen'}
            </Button>
            <Button
              type="button"
              variant="outline"
              size="icon"
              aria-label="Produktliste neu laden"
              onClick={() => void loadProducts()}
            >
              <RefreshCw aria-hidden="true" className="size-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {products === null && !error ? (
            <output
              aria-live="polite"
              className="block py-8 text-center text-sm text-muted-foreground"
            >
              Produktbestand wird geladen …
            </output>
          ) : null}

          {error ? (
            <div className="grid justify-items-center gap-3 py-8 text-center">
              <p role="alert" className="text-sm text-destructive">
                Die Produktliste konnte nicht geladen werden.
              </p>
              <Button type="button" variant="outline" onClick={() => void loadProducts()}>
                Erneut versuchen
              </Button>
            </div>
          ) : null}

          {products?.length === 0 && !error ? (
            <div className="grid justify-items-center gap-4 rounded-lg border border-dashed border-border px-5 py-10 text-center sm:px-8 sm:py-12">
              <span className="grid size-11 place-items-center rounded-full bg-secondary text-secondary-foreground">
                <PackagePlus aria-hidden="true" className="size-5" />
              </span>
              <div className="grid gap-1">
                <h2 className="font-semibold">Keine aktiven Produkte</h2>
                <p className="max-w-md text-sm leading-6 text-muted-foreground">
                  Starte direkt mit deinem ersten Produkt. Dafür brauchst du keine bestehenden
                  Produkt- oder anderen Datensätze.
                </p>
              </div>
              <div className="grid w-full max-w-md gap-2 rounded-md bg-secondary/50 p-4 text-left">
                <p className="text-sm font-medium text-foreground">
                  Diese Angaben kommen als Nächstes:
                </p>
                <ul className="grid gap-1.5 text-sm leading-6 text-muted-foreground">
                  <li>Eigene Produkt-URL</li>
                  <li>Wettbewerber-URLs, jeweils eine pro Zeile</li>
                  <li>Mindestpreis und Höchstpreis</li>
                </ul>
              </div>
              <Button asChild className="mt-1">
                <Link href="/admin/products/new">Erstes Produkt anlegen</Link>
              </Button>
            </div>
          ) : null}

          {products && products.length > 0 ? (
            <ul className="grid gap-3">
              {products.map((product) => (
                <li key={product.id}>
                  <article className="grid gap-4 rounded-lg border border-border/80 p-4 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center sm:p-5">
                    <div className="grid min-w-0 gap-3 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center sm:gap-6">
                      <div className="grid min-w-0 gap-1.5">
                        <h2 className="truncate font-semibold text-card-foreground">
                          {product.name}
                        </h2>
                        {!isValidProductPriceRange(product.minPrice, product.maxPrice) ? (
                          <Badge
                            variant="outline"
                            className="w-fit border-destructive text-destructive"
                          >
                            Ungültige Preisgrenzen prüfen
                          </Badge>
                        ) : null}
                        <a
                          href={product.ownUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="flex min-w-0 items-center gap-1.5 truncate text-sm text-muted-foreground underline-offset-4 hover:text-foreground hover:underline"
                        >
                          <span className="truncate">{product.ownUrl}</span>
                          <ExternalLink aria-hidden="true" className="size-3.5 shrink-0" />
                        </a>
                        <p className="text-xs text-muted-foreground">
                          {product.competitorUrls.length} Wettbewerber-URLs
                        </p>
                      </div>
                      <div className="grid grid-cols-2 gap-x-5 gap-y-1 text-sm sm:min-w-48">
                        <span className="text-muted-foreground">Mindestpreis</span>
                        <span className="text-right font-medium">
                          {formatPrice.format(product.minPrice)}
                        </span>
                        <span className="text-muted-foreground">Höchstpreis</span>
                        <span className="text-right font-medium">
                          {formatPrice.format(product.maxPrice)}
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-col gap-2 sm:flex-row">
                      <Button asChild variant="outline" className="w-full sm:w-auto">
                        <Link href={`/admin/products/${product.id}`}>
                          Bearbeiten
                          <ArrowUpRight aria-hidden="true" className="size-4" />
                        </Link>
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        className="w-full sm:w-auto"
                        onClick={() => setArchiveTarget(product)}
                      >
                        <Archive aria-hidden="true" className="size-4" />
                        Archivieren
                      </Button>
                    </div>
                  </article>
                </li>
              ))}
            </ul>
          ) : null}

          {showArchived ? (
            <section aria-label="Archivierte Produkte" className="grid gap-3 border-t pt-5">
              <div className="grid gap-1">
                <h2 className="text-base font-semibold">Archivierte Produkte</h2>
                <p className="text-sm text-muted-foreground">
                  Diese Produkte zählen nicht zum aktiven Bestand. Messverläufe und Berichte bleiben
                  über „Verlauf öffnen“ erreichbar.
                </p>
              </div>
              {archivedLoading ? (
                <output aria-live="polite" className="text-sm text-muted-foreground">
                  Archivbestand wird geladen …
                </output>
              ) : null}
              {archivedError ? (
                <p role="alert" className="text-sm text-destructive">
                  Der Archivbestand konnte nicht geladen werden.
                </p>
              ) : null}
              {archivedProducts?.length === 0 && !archivedError ? (
                <p className="text-sm text-muted-foreground">Keine archivierten Produkte.</p>
              ) : null}
              {archivedProducts && archivedProducts.length > 0 ? (
                <ul className="grid gap-3">
                  {archivedProducts.map((product) => (
                    <li key={product.id}>
                      <article className="grid gap-4 rounded-lg border border-border/80 p-4 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center sm:p-5">
                        <div className="grid min-w-0 gap-2">
                          <div className="flex flex-wrap items-center gap-2">
                            <h3 className="truncate font-semibold text-card-foreground">
                              {product.name}
                            </h3>
                            <Badge variant="outline">Archiviert</Badge>
                            {!isValidProductPriceRange(product.minPrice, product.maxPrice) ? (
                              <Badge
                                variant="outline"
                                className="border-destructive text-destructive"
                              >
                                Ungültige Preisgrenzen prüfen
                              </Badge>
                            ) : null}
                          </div>
                          <a
                            href={product.ownUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="flex min-w-0 items-center gap-1.5 truncate text-sm text-muted-foreground underline-offset-4 hover:text-foreground hover:underline"
                          >
                            <span className="truncate">{product.ownUrl}</span>
                            <ExternalLink aria-hidden="true" className="size-3.5 shrink-0" />
                          </a>
                          <p className="text-xs text-muted-foreground">
                            {product.competitorUrls.length} gespeicherte Wettbewerber-URLs
                          </p>
                        </div>
                        <Button asChild variant="outline" className="w-full sm:w-auto">
                          <Link href={`/admin/products/${product.id}`}>
                            Verlauf öffnen
                            <ArrowUpRight aria-hidden="true" className="size-4" />
                          </Link>
                        </Button>
                      </article>
                    </li>
                  ))}
                </ul>
              ) : null}
            </section>
          ) : null}
        </CardContent>
      </Card>

      <section
        aria-label="Preisänderungen"
        className="flex flex-col gap-3 rounded-lg border border-border/70 bg-secondary/40 p-4 sm:flex-row sm:items-center sm:justify-between sm:p-5"
      >
        <div className="flex items-start gap-3">
          <CircleSlash2
            aria-hidden="true"
            className="mt-0.5 size-5 shrink-0 text-muted-foreground"
          />
          <div className="grid gap-1">
            <h2 className="text-sm font-semibold">Preisänderungen sind deaktiviert</h2>
            <p className="text-sm leading-6 text-muted-foreground">
              Shopplattform: nicht verbunden. Betreiber-API-Zugangsdaten: nicht hinterlegt.
              Preisgrenzen bleiben interne Angaben; Shoppreise werden nicht geändert.
            </p>
          </div>
        </div>
      </section>

      <Dialog
        open={archiveTarget !== null}
        onOpenChange={(open) => {
          if (!open && !archiving) setArchiveTarget(null);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Produkt archivieren?</DialogTitle>
            <DialogDescription>
              {archiveTarget ? `„${archiveTarget.name}“` : 'Dieses Produkt'} wird aus dem aktiven
              Bestand und der Prüfplanung genommen. Gespeicherte Messungen und Berichte bleiben
              erhalten und im Archiv abrufbar.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              className="order-2 sm:order-1"
              disabled={archiving}
              onClick={() => setArchiveTarget(null)}
            >
              Abbrechen
            </Button>
            <Button
              type="button"
              variant="default"
              className="order-1 sm:order-2"
              disabled={archiving}
              onClick={() => void confirmArchive()}
            >
              {archiving ? 'Wird archiviert …' : 'Produkt archivieren'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
