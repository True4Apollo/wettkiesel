// @polsia:user-owned — Rückmeldeformular für einen gespeicherten Tagesbericht.
'use client';

import { LoaderCircle } from 'lucide-react';
import { type FormEvent, useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { apiFetch } from '@/lib/api-client';
import {
  MarketReportFeedbackResponse,
  type MarketReportFeedback as MarketReportFeedbackType,
} from '@/lib/contracts/market-reports';

interface MarketReportFeedbackFormProps {
  productId: string;
  reportId: string;
  initialFeedback: MarketReportFeedbackType | null;
}

export function MarketReportFeedbackForm({
  productId,
  reportId,
  initialFeedback,
}: MarketReportFeedbackFormProps) {
  const [feedback, setFeedback] = useState(initialFeedback);
  const [isUseful, setIsUseful] = useState<boolean | null>(initialFeedback?.isUseful ?? null);
  const [reason, setReason] = useState(initialFeedback?.reason ?? '');
  const [editing, setEditing] = useState(initialFeedback === null);
  const [saving, setSaving] = useState(false);

  async function submitFeedback(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (isUseful === null) return;

    setSaving(true);
    try {
      const result = await apiFetch(`/api/admin/products/${productId}/market-report/feedback`, {
        method: 'POST',
        body: JSON.stringify({
          reportId,
          isUseful,
          reason: reason.trim() || undefined,
        }),
        schema: MarketReportFeedbackResponse,
      });
      setFeedback(result.feedback);
      setEditing(false);
      toast.success('Danke für deine Rückmeldung.');
    } catch {
      toast.error('Deine Rückmeldung konnte nicht gespeichert werden.');
    } finally {
      setSaving(false);
    }
  }

  function cancelEditing() {
    setIsUseful(feedback?.isUseful ?? null);
    setReason(feedback?.reason ?? '');
    setEditing(false);
  }

  return (
    <section aria-labelledby="market-report-feedback-title" className="grid gap-3 border-t pt-4">
      <div className="grid gap-1">
        <h3 id="market-report-feedback-title" className="text-sm font-semibold text-foreground">
          War der Tagesbericht hilfreich?
        </h3>
        <p className="text-xs text-muted-foreground">
          Deine Rückmeldung bezieht sich auf diesen gespeicherten Bericht.
        </p>
      </div>

      {feedback && !editing ? (
        <output className="grid gap-2 rounded-lg border border-border/70 bg-background p-3">
          <p className="text-sm text-foreground">
            {feedback.isUseful
              ? 'Du hast den Bericht als hilfreich bewertet.'
              : 'Du hast den Bericht als nicht hilfreich bewertet.'}
          </p>
          {feedback.reason ? (
            <p className="break-words text-sm text-muted-foreground">„{feedback.reason}“</p>
          ) : (
            <p className="text-xs text-muted-foreground">Ohne zusätzlichen Grund.</p>
          )}
          <div>
            <Button type="button" size="sm" variant="outline" onClick={() => setEditing(true)}>
              Rückmeldung ändern
            </Button>
          </div>
        </output>
      ) : (
        <form onSubmit={(event) => void submitFeedback(event)} className="grid gap-3">
          <fieldset className="grid gap-2">
            <legend className="text-sm font-medium text-foreground">Deine Bewertung</legend>
            <div className="flex flex-wrap gap-2">
              <Button
                type="button"
                variant={isUseful === true ? 'default' : 'outline'}
                aria-pressed={isUseful === true}
                onClick={() => setIsUseful(true)}
              >
                Ja, hilfreich
              </Button>
              <Button
                type="button"
                variant={isUseful === false ? 'default' : 'outline'}
                aria-pressed={isUseful === false}
                onClick={() => setIsUseful(false)}
              >
                Nein, nicht hilfreich
              </Button>
            </div>
          </fieldset>

          <div className="grid gap-2">
            <Label htmlFor={`market-report-feedback-reason-${reportId}`}>Grund (optional)</Label>
            <Textarea
              id={`market-report-feedback-reason-${reportId}`}
              value={reason}
              maxLength={300}
              rows={3}
              placeholder="Was hätte den Bericht nützlicher gemacht?"
              onChange={(event) => setReason(event.currentTarget.value)}
            />
            <p className="text-xs text-muted-foreground">{reason.length}/300 Zeichen</p>
          </div>

          <div className="flex flex-wrap gap-2">
            <Button type="submit" disabled={saving || isUseful === null}>
              {saving ? <LoaderCircle aria-hidden="true" className="size-4 animate-spin" /> : null}
              {saving
                ? 'Wird gespeichert …'
                : feedback
                  ? 'Rückmeldung speichern'
                  : 'Rückmeldung absenden'}
            </Button>
            {feedback ? (
              <Button type="button" variant="ghost" onClick={cancelEditing} disabled={saving}>
                Abbrechen
              </Button>
            ) : null}
          </div>
        </form>
      )}
    </section>
  );
}
