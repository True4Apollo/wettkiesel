// @polsia:user-owned — saved daily market reports in the owner shop area.
'use client';

import { ArrowDownRight, ArrowUpRight, LoaderCircle, Minus, RefreshCw } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { toast } from 'sonner';
import { MarketReportFeedbackForm } from '@/components/custom/admin/market-report-feedback';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { apiFetch } from '@/lib/api-client';
import {
  MarketReportCreateResponse,
  type MarketReportFeedback as MarketReportFeedbackType,
  type MarketReportObservation,
  MarketReportQueryResponse,
  type MarketReport as MarketReportType,
} from '@/lib/contracts/market-reports';

interface MarketReportPanelProps {
  productId: string;
}

function formatDateTime(value: string) {
  return new Intl.DateTimeFormat('de-DE', {
    dateStyle: 'medium',
    timeStyle: 'short',
    timeZone: 'UTC',
  }).format(new Date(value));
}

function formatPrice(value: string, currency: string | null) {
  const formatted = new Intl.NumberFormat('de-DE', { maximumFractionDigits: 4 }).format(
    Number(value),
  );
  return currency ? `${formatted} ${currency}` : formatted;
}

function PriceMovement({ observation }: { observation: MarketReportObservation }) {
  if (!observation.priceDirection || !observation.previousPriceValue || !observation.priceValue) {
    return null;
  }

  const direction = observation.priceDirection;
  const Icon =
    direction === 'increase' ? ArrowUpRight : direction === 'decrease' ? ArrowDownRight : Minus;
  const label =
    direction === 'increase'
      ? 'Preis gestiegen'
      : direction === 'decrease'
        ? 'Preis gesunken'
        : 'Preis unverändert';

  return (
    <p className="flex items-center gap-1.5 text-sm font-medium text-foreground">
      <Icon aria-hidden="true" className="size-4" />
      {label}: {formatPrice(observation.previousPriceValue, observation.currency)} →{' '}
      {formatPrice(observation.priceValue, observation.currency)}
    </p>
  );
}

function ObservationCard({ observation }: { observation: MarketReportObservation }) {
  return (
    <li className="grid gap-3 rounded-lg border border-border/70 bg-background p-4">
      <div className="grid gap-1">
        <a
          href={observation.competitorUrl}
          target="_blank"
          rel="noreferrer noopener"
          className="break-all text-sm font-medium text-primary underline-offset-4 hover:underline"
        >
          {observation.competitorUrl}
        </a>
        <p className="text-xs text-muted-foreground">
          Beobachtet am {formatDateTime(observation.observedAt)} UTC
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div className="grid gap-1">
          <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Preis</p>
          <p className="text-sm font-semibold text-foreground">
            {observation.priceValue
              ? formatPrice(observation.priceValue, observation.currency)
              : 'Kein eindeutiger Preis gespeichert'}
          </p>
          <PriceMovement observation={observation} />
        </div>
        <div className="grid gap-1">
          <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
            Verfügbarkeit
          </p>
          <p className="text-sm text-foreground">
            {observation.availability ?? 'Keine eindeutige Verfügbarkeit gespeichert'}
          </p>
          {observation.availabilityChanged === true ? (
            <p className="text-sm font-medium text-foreground">
              Gegenüber der gespeicherten Vergleichsmessung verändert
            </p>
          ) : observation.availabilityChanged === false ? (
            <p className="text-sm text-muted-foreground">
              Gegenüber der Vergleichsmessung unverändert
            </p>
          ) : null}
        </div>
      </div>

      {observation.comparisonAt ? (
        <p className="text-xs text-muted-foreground">
          Vergleich mit letzter gespeicherter Messung vom {formatDateTime(observation.comparisonAt)}{' '}
          UTC.
          {!observation.priceDirection && observation.priceValue
            ? ' Kein vergleichbarer Preis mit gleicher Währung vorhanden.'
            : null}
        </p>
      ) : (
        <p className="text-xs text-muted-foreground">
          Kein früherer gespeicherter Vergleichswert für diese URL.
        </p>
      )}
    </li>
  );
}

export function MarketReportPanel({ productId }: MarketReportPanelProps) {
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [report, setReport] = useState<MarketReportType | null>(null);
  const [reportId, setReportId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<MarketReportFeedbackType | null>(null);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [loadError, setLoadError] = useState(false);

  const loadReport = useCallback(async () => {
    setLoading(true);
    setLoadError(false);
    try {
      const query = new URLSearchParams({ date });
      const result = await apiFetch(
        `/api/admin/products/${productId}/market-report?${query.toString()}`,
        { schema: MarketReportQueryResponse },
      );
      setReport(result.report);
      setReportId(result.reportId);
      setFeedback(result.feedback);
    } catch {
      setReport(null);
      setReportId(null);
      setFeedback(null);
      setLoadError(true);
    } finally {
      setLoading(false);
    }
  }, [date, productId]);

  useEffect(() => {
    void loadReport();
  }, [loadReport]);

  async function createReport() {
    setCreating(true);
    try {
      const result = await apiFetch(`/api/admin/products/${productId}/market-report`, {
        method: 'POST',
        body: JSON.stringify({ date }),
        schema: MarketReportCreateResponse,
      });
      setReport(result.report);
      setReportId(result.reportId);
      setFeedback(result.feedback);
      toast.success('Tagesbericht gespeichert.');
    } catch {
      toast.error('Der Tagesbericht konnte nicht erstellt werden.');
    } finally {
      setCreating(false);
    }
  }

  return (
    <Card className="border-border/70 shadow-sm">
      <CardHeader>
        <h2 className="text-base font-semibold leading-none tracking-tight">
          Gespeicherter Marktbericht
        </h2>
        <CardDescription>
          Wertet ausschließlich gespeicherte Wettbewerbermessungen dieses Produkts aus. Vergleiche
          werden nur bei passenden gespeicherten Vorwerten angezeigt.
        </CardDescription>
      </CardHeader>
      <CardContent className="grid gap-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div className="grid max-w-xs gap-2">
            <Label htmlFor="market-report-date">Auswertungstag (UTC)</Label>
            <Input
              id="market-report-date"
              type="date"
              value={date}
              max={new Date().toISOString().slice(0, 10)}
              onChange={(event) => setDate(event.currentTarget.value)}
            />
          </div>
          <Button type="button" onClick={() => void createReport()} disabled={creating || loading}>
            {creating ? (
              <LoaderCircle aria-hidden="true" className="size-4 animate-spin" />
            ) : (
              <RefreshCw aria-hidden="true" className="size-4" />
            )}
            {creating ? 'Bericht wird gespeichert …' : 'Tagesbericht erstellen'}
          </Button>
        </div>

        {loadError ? (
          <Alert variant="destructive">
            <AlertTitle>Gespeicherter Bericht nicht verfügbar</AlertTitle>
            <AlertDescription className="flex flex-col items-start gap-3">
              Der Bericht konnte nicht geladen werden.
              <Button type="button" size="sm" variant="outline" onClick={() => void loadReport()}>
                Erneut laden
              </Button>
            </AlertDescription>
          </Alert>
        ) : null}

        {loading ? (
          <p aria-live="polite" className="text-sm text-muted-foreground">
            Gespeicherter Tagesbericht wird geladen …
          </p>
        ) : null}

        {!loading && !loadError && !report ? (
          <p className="text-sm text-muted-foreground">
            Für diesen Tag ist noch kein Bericht gespeichert. Beim Erstellen werden nur tatsächlich
            gespeicherte Messungen dieses Produkts berücksichtigt.
          </p>
        ) : null}

        {!loading && !loadError && report && report.observations.length === 0 ? (
          <Alert>
            <AlertTitle>Keine verwertbaren Messungen für diesen Tag</AlertTitle>
            <AlertDescription>
              {report.storedMeasurementCount === 0
                ? 'Für diesen Tag wurden keine gespeicherten Wettbewerbermessungen gefunden.'
                : report.storedMeasurementCount === 1
                  ? '1 gespeicherte Messung enthält keine verwertbaren Preis- oder Verfügbarkeitswerte.'
                  : `${report.storedMeasurementCount} gespeicherte Messungen enthalten keine verwertbaren Preis- oder Verfügbarkeitswerte.`}{' '}
              Es wurden keine Marktbewegungen abgeleitet.
            </AlertDescription>
          </Alert>
        ) : null}

        {!loading && !loadError && report && report.observations.length > 0 ? (
          <section aria-label="Gespeicherter Tagesbericht" className="grid gap-3">
            <div className="flex flex-wrap items-center justify-between gap-2 border-t border-border/70 pt-4">
              <div>
                <h3 className="text-sm font-semibold text-foreground">
                  Bericht für {report.date} UTC
                </h3>
                <p className="text-xs text-muted-foreground">
                  {report.observations.length} verwertbare Wettbewerber-URL
                  {report.observations.length === 1 ? '' : 's'} · erstellt am{' '}
                  {formatDateTime(report.generatedAt)} UTC
                </p>
              </div>
              <p className="text-xs text-muted-foreground">
                {report.storedMeasurementCount} gespeicherte Messung
                {report.storedMeasurementCount === 1 ? '' : 'en'} an diesem Tag
              </p>
            </div>
            <ul className="grid gap-3">
              {report.observations.map((observation) => (
                <ObservationCard key={observation.measurementId} observation={observation} />
              ))}
            </ul>
          </section>
        ) : null}

        {!loading && !loadError && report && reportId ? (
          <MarketReportFeedbackForm
            key={reportId}
            productId={productId}
            reportId={reportId}
            initialFeedback={feedback}
          />
        ) : null}
      </CardContent>
    </Card>
  );
}
