// @polsia:user-owned — Kompakte Adminansicht vorhandener Tagesbericht-Bewertungen.
'use client';

import { LoaderCircle, RefreshCw, ThumbsDown, ThumbsUp } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { apiFetch } from '@/lib/api-client';
import {
  type MarketReportFeedbackSummary as MarketReportFeedbackSummaryData,
  MarketReportFeedbackSummary as MarketReportFeedbackSummarySchema,
} from '@/lib/contracts/market-report-feedback-summary';

function formatDate(value: string) {
  return new Intl.DateTimeFormat('de-DE', {
    dateStyle: 'medium',
    timeZone: 'UTC',
  }).format(new Date(value));
}

function formatReportDate(value: string) {
  return new Intl.DateTimeFormat('de-DE', {
    dateStyle: 'long',
    timeZone: 'UTC',
  }).format(new Date(`${value}T00:00:00.000Z`));
}

export function MarketReportFeedbackSummary() {
  const [summary, setSummary] = useState<MarketReportFeedbackSummaryData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const loadSummary = useCallback(async () => {
    setLoading(true);
    setError(false);
    try {
      const result = await apiFetch('/api/admin/market-report-feedback', {
        schema: MarketReportFeedbackSummarySchema,
      });
      setSummary(result);
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadSummary();
  }, [loadSummary]);

  const helpfulCount = summary?.helpfulCount ?? 0;
  const notHelpfulCount = summary?.notHelpfulCount ?? 0;
  const totalCount = helpfulCount + notHelpfulCount;
  const helpfulPercent = totalCount === 0 ? 0 : (helpfulCount / totalCount) * 100;

  return (
    <div className="grid gap-5" aria-busy={loading}>
      {error ? (
        <Alert variant="destructive">
          <AlertTitle>Feedback nicht verfügbar</AlertTitle>
          <AlertDescription className="flex flex-wrap items-center justify-between gap-3">
            <span>Die gespeicherten Bewertungen konnten gerade nicht geladen werden.</span>
            <Button type="button" size="sm" variant="outline" onClick={() => void loadSummary()}>
              <RefreshCw aria-hidden="true" className="size-4" />
              Erneut laden
            </Button>
          </AlertDescription>
        </Alert>
      ) : null}

      <section aria-label="Verteilung der Bewertungen" className="grid gap-4">
        <div className="grid grid-cols-2 gap-3 sm:gap-4">
          <Card className="border-border/70 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between gap-3 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Hilfreich</CardTitle>
              <ThumbsUp aria-hidden="true" className="size-4 text-primary" />
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-semibold tabular-nums text-foreground">
                {loading && !summary ? (
                  <LoaderCircle aria-label="Wird geladen" className="size-6 animate-spin" />
                ) : error && !summary ? (
                  '–'
                ) : (
                  helpfulCount
                )}
              </p>
            </CardContent>
          </Card>
          <Card className="border-border/70 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between gap-3 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Nicht hilfreich
              </CardTitle>
              <ThumbsDown aria-hidden="true" className="size-4 text-destructive" />
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-semibold tabular-nums text-foreground">
                {loading && !summary ? (
                  <LoaderCircle aria-label="Wird geladen" className="size-6 animate-spin" />
                ) : error && !summary ? (
                  '–'
                ) : (
                  notHelpfulCount
                )}
              </p>
            </CardContent>
          </Card>
        </div>

        <Card className="border-border/70 shadow-sm">
          <CardContent className="grid gap-3 pt-5">
            <div className="flex flex-wrap items-center justify-between gap-2 text-sm">
              <span className="font-medium text-foreground">Gespeicherte Bewertungen</span>
              <span className="tabular-nums text-muted-foreground">{totalCount} insgesamt</span>
            </div>
            <div
              role="img"
              aria-label={`${helpfulCount} hilfreich und ${notHelpfulCount} nicht hilfreich`}
              className="flex h-3 overflow-hidden rounded-full bg-muted"
            >
              <span
                aria-hidden="true"
                className="bg-primary"
                style={{ width: `${helpfulPercent}%` }}
              />
              <span
                aria-hidden="true"
                className="bg-destructive"
                style={{ width: `${totalCount === 0 ? 0 : 100 - helpfulPercent}%` }}
              />
            </div>
            <div className="flex flex-wrap gap-x-5 gap-y-2 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-2">
                <span aria-hidden="true" className="size-2 rounded-full bg-primary" />
                Hilfreich
              </span>
              <span className="inline-flex items-center gap-2">
                <span aria-hidden="true" className="size-2 rounded-full bg-destructive" />
                Nicht hilfreich
              </span>
            </div>
          </CardContent>
        </Card>
      </section>

      <section aria-labelledby="feedback-reasons-heading" className="grid gap-3">
        <div className="flex flex-wrap items-end justify-between gap-2">
          <div className="grid gap-1">
            <h2 id="feedback-reasons-heading" className="text-lg font-semibold text-foreground">
              Vorhandene Gründe
            </h2>
            <p className="text-sm text-muted-foreground">
              Optionale Angaben zu gespeicherten Marktberichten.
            </p>
          </div>
          {loading && summary ? (
            <LoaderCircle
              aria-label="Wird aktualisiert"
              className="size-4 animate-spin text-muted-foreground"
            />
          ) : null}
        </div>

        {loading && !summary ? (
          <p className="rounded-lg border border-dashed border-border p-5 text-sm text-muted-foreground">
            Gespeicherte Bewertungen werden geladen …
          </p>
        ) : error && !summary ? null : summary?.reasons.length ? (
          <ul className="grid gap-3">
            {summary.reasons.map((entry) => {
              const Icon = entry.isUseful ? ThumbsUp : ThumbsDown;
              return (
                <li
                  key={entry.feedbackId}
                  className="grid gap-3 rounded-lg border border-border/70 bg-card p-4 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-start"
                >
                  <div className="flex min-w-0 items-start gap-3">
                    <Icon
                      aria-hidden="true"
                      className={`mt-0.5 size-4 shrink-0 ${entry.isUseful ? 'text-primary' : 'text-destructive'}`}
                    />
                    <div className="grid min-w-0 gap-2">
                      <p className="break-words text-sm leading-6 text-foreground">
                        {entry.reason}
                      </p>
                      <p className="text-xs leading-5 text-muted-foreground">
                        {entry.productName || 'Produkt ohne Namen'} · Marktbericht vom{' '}
                        {formatReportDate(entry.reportDate)}
                      </p>
                    </div>
                  </div>
                  <time
                    dateTime={entry.submittedAt}
                    className="pl-7 text-xs text-muted-foreground sm:pl-0 sm:text-right"
                  >
                    {formatDate(entry.submittedAt)}
                  </time>
                </li>
              );
            })}
          </ul>
        ) : (
          <p className="rounded-lg border border-dashed border-border p-5 text-sm text-muted-foreground">
            {totalCount === 0
              ? 'Für gespeicherte Marktberichte liegen noch keine Bewertungen vor.'
              : 'Zu den gespeicherten Bewertungen wurden keine Gründe angegeben.'}
          </p>
        )}
      </section>
    </div>
  );
}
