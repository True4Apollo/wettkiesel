// @polsia:user-owned
'use client';

import { ArrowLeft, CircleSlash2, LoaderCircle, Save } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { type FormEvent, useEffect, useState } from 'react';
import { toast } from 'sonner';
import { CompetitorMeasurementPanel } from '@/components/custom/admin/competitor-measurement-panel';
import { MarketReportPanel } from '@/components/custom/admin/market-report-panel';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { apiFetch } from '@/lib/api-client';
import {
  isValidProductPriceRange,
  ShopProductInput,
  type ShopProductItem,
  ShopProductResponse,
} from '@/lib/contracts/shop-products';

interface ProductFormValues {
  name: string;
  ownUrl: string;
  competitorUrls: string;
  minPrice: string;
  maxPrice: string;
}

interface ShopProductFormProps {
  productId?: string;
  createAsShopUser?: boolean;
}

const emptyValues: ProductFormValues = {
  name: '',
  ownUrl: '',
  competitorUrls: '',
  minPrice: '',
  maxPrice: '',
};

function valuesFromProduct(product: ShopProductItem): ProductFormValues {
  return {
    name: product.name,
    ownUrl: product.ownUrl,
    competitorUrls: product.competitorUrls.join('\n'),
    minPrice: String(product.minPrice),
    maxPrice: String(product.maxPrice),
  };
}

function errorsFromApi(error: unknown) {
  if (error instanceof Error && error.cause && typeof error.cause === 'object') {
    const body = error.cause as { errors?: Record<string, string> };
    if (body.errors) return body.errors;
  }
  return { form: 'Die Angaben konnten nicht gespeichert werden. Bitte versuche es erneut.' };
}

function priceNumber(value: string) {
  return value.trim() === '' ? Number.NaN : Number(value);
}

export function ShopProductForm({ productId, createAsShopUser = false }: ShopProductFormProps) {
  const router = useRouter();
  const editing = Boolean(productId);
  const productListPath = createAsShopUser ? '/dashboard/products' : '/admin/products';
  const [values, setValues] = useState<ProductFormValues>(emptyValues);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(editing);
  const [loadError, setLoadError] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savedCompetitorCount, setSavedCompetitorCount] = useState(0);
  const [savedProductVersion, setSavedProductVersion] = useState<string | null>(null);
  const [isArchived, setIsArchived] = useState(false);
  const minimumPrice = priceNumber(values.minPrice);
  const maximumPrice = priceNumber(values.maxPrice);
  const minimumPriceError =
    errors.minPrice ??
    (editing && (!Number.isFinite(minimumPrice) || minimumPrice <= 0)
      ? 'Der Mindestpreis muss größer als 0 € sein.'
      : undefined);
  const maximumPriceError =
    errors.maxPrice ??
    (editing && (!Number.isFinite(maximumPrice) || maximumPrice <= 0)
      ? 'Der Höchstpreis muss größer als 0 € sein.'
      : editing && minimumPrice > maximumPrice
        ? 'Der Höchstpreis muss mindestens dem Mindestpreis entsprechen.'
        : undefined);
  const invalidPriceRange = editing && !isValidProductPriceRange(minimumPrice, maximumPrice);

  useEffect(() => {
    if (!productId) return;
    let active = true;
    apiFetch(`/api/admin/products/${productId}`, { schema: ShopProductResponse })
      .then(({ item }) => {
        if (active) {
          setValues(valuesFromProduct(item));
          setSavedCompetitorCount(item.competitorUrls.length);
          setIsArchived(item.isArchived);
          setSavedProductVersion(item.updatedAt);
        }
      })
      .catch(() => {
        if (active) setLoadError(true);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [productId]);

  function updateValue(field: keyof ProductFormValues, value: string) {
    setValues((current) => ({ ...current, [field]: value }));
    setErrors((current) => {
      const next = { ...current };
      if (field === 'minPrice' || field === 'maxPrice') {
        delete next.minPrice;
        delete next.maxPrice;
      } else {
        delete next[field];
      }
      delete next.form;
      return next;
    });
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setErrors({});

    const parsed = ShopProductInput.safeParse({
      name: values.name,
      ownUrl: values.ownUrl,
      competitorUrls: values.competitorUrls
        .split('\n')
        .map((url) => url.trim())
        .filter(Boolean),
      minPrice: priceNumber(values.minPrice),
      maxPrice: priceNumber(values.maxPrice),
    });

    if (!parsed.success) {
      const next: Record<string, string> = {};
      for (const issue of parsed.error.issues) {
        const field = String(issue.path[0] ?? 'form');
        next[field] ??= issue.message;
      }
      setErrors(next);
      return;
    }

    setSaving(true);
    try {
      const result = await apiFetch(
        editing
          ? `/api/admin/products/${productId}`
          : createAsShopUser
            ? '/api/shop/products'
            : '/api/admin/products',
        {
          method: editing ? 'PATCH' : 'POST',
          body: JSON.stringify(parsed.data),
          schema: ShopProductResponse,
        },
      );
      toast.success(editing ? 'Produktangaben gespeichert.' : 'Produkt angelegt.');
      if (editing) {
        setValues(valuesFromProduct(result.item));
        setSavedCompetitorCount(result.item.competitorUrls.length);
        setSavedProductVersion(result.item.updatedAt);
        router.refresh();
      } else {
        router.push(`${createAsShopUser ? '/dashboard' : '/admin'}/products/${result.item.id}`);
      }
    } catch (error) {
      setErrors(errorsFromApi(error));
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <output aria-live="polite" className="block py-12 text-center text-sm text-muted-foreground">
        Produkt wird geladen …
      </output>
    );
  }

  if (loadError) {
    return (
      <Alert variant="destructive">
        <AlertTitle>Produkt nicht verfügbar</AlertTitle>
        <AlertDescription>
          Das Produkt konnte nicht geladen werden oder gehört nicht zu diesem Owner-Konto.
        </AlertDescription>
        <Button asChild variant="outline" className="mt-4">
          <Link href={productListPath}>Zur Produktliste</Link>
        </Button>
      </Alert>
    );
  }

  return (
    <div className="grid min-w-0 max-w-full grid-cols-[minmax(0,1fr)] gap-5">
      <div className="grid min-w-0 max-w-full grid-cols-[minmax(0,1fr)] gap-5">
        <Button asChild variant="ghost" className="w-fit -ml-3">
          <Link href={productListPath}>
            <ArrowLeft aria-hidden="true" className="size-4" />
            Zur Produktliste
          </Link>
        </Button>

        <header className="grid gap-2">
          <p className="text-sm font-medium uppercase tracking-[0.12em] text-primary">
            {editing
              ? 'Produkt bearbeiten'
              : createAsShopUser
                ? 'Shopbereich'
                : 'Produktverwaltung'}
          </p>
          <h1 className="text-3xl font-semibold tracking-tight text-foreground">
            {editing ? values.name || 'Produkt bearbeiten' : 'Erstes Produkt anlegen'}
          </h1>
          {isArchived ? (
            <Badge variant="outline" className="w-fit">
              Archiviert
            </Badge>
          ) : null}
          <p className="max-w-2xl text-sm leading-6 text-muted-foreground">
            Erfasse deine Produktseite, passende Wettbewerber und den Preisrahmen in Euro.
          </p>
        </header>

        <form onSubmit={submit} className="grid gap-5">
          <Card className="border-border/70 shadow-sm">
            <CardHeader>
              <CardTitle className="text-base">Produkt und Marktvergleich</CardTitle>
              <CardDescription>
                {createAsShopUser
                  ? 'Diese Angaben werden deinem Konto zugeordnet.'
                  : 'Diese Angaben bleiben deinem Owner-Konto zugeordnet.'}
              </CardDescription>
            </CardHeader>
            <CardContent className="grid gap-5">
              <div className="grid gap-2">
                <Label htmlFor="product-name">Produktname</Label>
                <Input
                  id="product-name"
                  autoComplete="off"
                  value={values.name}
                  aria-invalid={Boolean(errors.name)}
                  aria-describedby={errors.name ? 'product-name-error' : undefined}
                  onChange={(event) => updateValue('name', event.currentTarget.value)}
                />
                {errors.name ? (
                  <p id="product-name-error" className="text-sm text-destructive">
                    {errors.name}
                  </p>
                ) : null}
              </div>

              <div className="grid gap-2">
                <Label htmlFor="own-url">Eigene Produkt-URL</Label>
                <Input
                  id="own-url"
                  type="url"
                  inputMode="url"
                  autoComplete="url"
                  value={values.ownUrl}
                  aria-invalid={Boolean(errors.ownUrl)}
                  aria-describedby={errors.ownUrl ? 'own-url-error' : 'own-url-help'}
                  onChange={(event) => updateValue('ownUrl', event.currentTarget.value)}
                />
                <p id="own-url-help" className="text-sm text-muted-foreground">
                  Vollständige URL mit http:// oder https://
                </p>
                {errors.ownUrl ? (
                  <p id="own-url-error" className="text-sm text-destructive">
                    {errors.ownUrl}
                  </p>
                ) : null}
              </div>

              <div className="grid gap-2">
                <Label htmlFor="competitor-urls">Wettbewerber-URLs</Label>
                <Textarea
                  id="competitor-urls"
                  rows={4}
                  value={values.competitorUrls}
                  aria-invalid={Boolean(errors.competitorUrls)}
                  aria-describedby={
                    errors.competitorUrls ? 'competitor-urls-error' : 'competitor-urls-help'
                  }
                  onChange={(event) => updateValue('competitorUrls', event.currentTarget.value)}
                />
                <p id="competitor-urls-help" className="text-sm text-muted-foreground">
                  Eine URL pro Zeile. Dieses Feld kann leer bleiben.
                </p>
                {errors.competitorUrls ? (
                  <p id="competitor-urls-error" className="text-sm text-destructive">
                    {errors.competitorUrls}
                  </p>
                ) : null}
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/70 shadow-sm">
            <CardHeader>
              <CardTitle className="text-base">Deine Preisgrenzen</CardTitle>
              <CardDescription>
                Die Grenzwerte lassen sich unabhängig von Plattform-Zugangsdaten pflegen.
              </CardDescription>
            </CardHeader>
            <CardContent className="grid gap-5 sm:grid-cols-2">
              <div className="grid content-start gap-2">
                <Label htmlFor="minimum-price">Mindestpreis</Label>
                <div className="relative">
                  <Input
                    id="minimum-price"
                    type="number"
                    step="0.01"
                    inputMode="decimal"
                    className="pr-10"
                    value={values.minPrice}
                    aria-invalid={Boolean(minimumPriceError)}
                    aria-describedby={minimumPriceError ? 'minimum-price-error' : 'price-help'}
                    onChange={(event) => updateValue('minPrice', event.currentTarget.value)}
                  />
                  <span
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-y-0 right-3 flex items-center text-sm text-muted-foreground"
                  >
                    €
                  </span>
                </div>
                {minimumPriceError ? (
                  <p id="minimum-price-error" className="text-sm text-destructive">
                    {minimumPriceError}
                  </p>
                ) : null}
              </div>
              <div className="grid content-start gap-2">
                <Label htmlFor="maximum-price">Höchstpreis</Label>
                <div className="relative">
                  <Input
                    id="maximum-price"
                    type="number"
                    step="0.01"
                    inputMode="decimal"
                    className="pr-10"
                    value={values.maxPrice}
                    aria-invalid={Boolean(maximumPriceError)}
                    aria-describedby={maximumPriceError ? 'maximum-price-error' : 'price-help'}
                    onChange={(event) => updateValue('maxPrice', event.currentTarget.value)}
                  />
                  <span
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-y-0 right-3 flex items-center text-sm text-muted-foreground"
                  >
                    €
                  </span>
                </div>
                {maximumPriceError ? (
                  <p id="maximum-price-error" className="text-sm text-destructive">
                    {maximumPriceError}
                  </p>
                ) : null}
              </div>
              <p id="price-help" className="text-sm leading-6 text-muted-foreground sm:col-span-2">
                Diese Grenzen werden in Euro gespeichert. Sie ändern keinen Preis in einem Shop.
              </p>
            </CardContent>
          </Card>

          {invalidPriceRange ? (
            <Alert variant="destructive">
              <AlertTitle>Gespeicherte Preisgrenzen prüfen</AlertTitle>
              <AlertDescription>
                Mindestens eine gespeicherte Preisgrenze ist nicht positiv oder der Mindestpreis
                liegt über dem Höchstpreis. Korrigiere die Fehler direkt bei den Preisfeldern.
              </AlertDescription>
            </Alert>
          ) : null}

          {editing ? (
            <Alert>
              <CircleSlash2 aria-hidden="true" className="size-4" />
              <AlertTitle>Automatische Preisänderungen sind deaktiviert</AlertTitle>
              <AlertDescription>
                Shopplattform: nicht verbunden. Betreiber-API-Zugangsdaten: nicht hinterlegt. Die
                Einrichtung ist nicht abgeschlossen. Produktdaten und Preisgrenzen bleiben
                bearbeitbar; Shoppreise werden nicht geändert.
              </AlertDescription>
            </Alert>
          ) : null}

          {errors.form ? (
            <p role="alert" className="text-sm text-destructive">
              {errors.form}
            </p>
          ) : null}

          <div className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
            <Button asChild variant="outline">
              <Link href={productListPath}>Abbrechen</Link>
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? (
                <LoaderCircle aria-hidden="true" className="size-4 animate-spin" />
              ) : (
                <Save aria-hidden="true" className="size-4" />
              )}
              {saving
                ? 'Wird gespeichert …'
                : editing
                  ? 'Änderungen speichern'
                  : 'Produkt speichern'}
            </Button>
          </div>
        </form>
      </div>
      {editing && productId ? (
        <div className="grid min-w-0 max-w-full grid-cols-[minmax(0,1fr)] gap-6">
          <CompetitorMeasurementPanel
            key={savedProductVersion}
            productId={productId}
            competitorCount={savedCompetitorCount}
            isArchived={isArchived}
          />
          <MarketReportPanel productId={productId} />
        </div>
      ) : null}
    </div>
  );
}
