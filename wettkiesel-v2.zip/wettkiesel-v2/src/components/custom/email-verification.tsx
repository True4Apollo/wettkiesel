// @polsia:user-owned
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { authClient } from '@/lib/auth-client';

export function EmailVerification({
  email,
  callbackURL = '/profile',
}: {
  email: string;
  callbackURL?: string;
}) {
  const [pending, setPending] = useState(false);
  const [sent, setSent] = useState(false);
  const [failed, setFailed] = useState(false);

  async function resend() {
    setPending(true);
    setSent(false);
    setFailed(false);
    try {
      const result = await authClient.sendVerificationEmail({ email, callbackURL });
      if (result.error) setFailed(true);
      else setSent(true);
    } catch {
      setFailed(true);
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="flex flex-col gap-3">
      <h2 className="text-lg font-semibold">E-Mail-Adresse bestätigen</h2>
      <p className="text-sm text-muted-foreground">
        Bestätige {email} über den Link in der E-Mail. Falls du keine Nachricht erhalten hast,
        kannst du unten eine neue anfordern.
      </p>
      {sent ? (
        <output>Der Bestätigungslink wurde angefordert. Prüfe deinen Posteingang.</output>
      ) : null}
      {failed ? (
        <p role="alert" className="text-sm text-destructive">
          Die Bestätigungs-E-Mail konnte nicht angefordert werden. Bitte versuche es später erneut.
        </p>
      ) : null}
      <Button type="button" onClick={resend} disabled={pending}>
        {pending ? 'Wird angefordert …' : 'Bestätigungslink erneut anfordern'}
      </Button>
    </div>
  );
}
