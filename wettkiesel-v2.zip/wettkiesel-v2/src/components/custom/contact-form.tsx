'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { apiFetch } from '@/lib/api-client';
import { shopSystemOptions, willingnessOptions } from '@/lib/contact/schema';
import styles from './pilot-interest.module.css';

const inputStyle = { backgroundColor: 'var(--card)', color: 'var(--card-foreground)' };
const competitorSlots = [0, 1, 2, 3, 4];

export function ContactForm({ tarif }: { tarif?: string }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [shopUrl, setShopUrl] = useState('');
  const [shopSystem, setShopSystem] = useState('');
  const [competitors, setCompetitors] = useState<string[]>(['', '', '', '', '']);
  const [willingness, setWillingness] = useState('');
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    setError(null);

    const competitorList = competitors.map((c) => c.trim()).filter(Boolean);
    const message = [
      'Wettkiesel — Pilotanfrage',
      `Shop-URL: ${shopUrl.trim()}`,
      `Shopsystem: ${shopSystem || 'Keine Angabe'}`,
      `Interessanter Tarif: ${tarif || 'Keine Angabe'}`,
      'Wettbewerber:',
      ...(competitorList.length ? competitorList.map((c) => `- ${c}`) : ['Keine Angabe']),
    ].join('\n');
    const fields: Record<string, string> = {
      'Shop-URL': shopUrl.trim(),
      Shopsystem: shopSystem || 'Keine Angabe',
      Tarif: tarif || 'Keine Angabe',
    };
    competitorList.forEach((c, i) => {
      fields[`Wettbewerber ${i + 1}`] = c;
    });

    try {
      await apiFetch('/api/contact', {
        method: 'POST',
        body: JSON.stringify({
          name,
          email,
          message,
          fields,
          willingness: willingness || undefined,
        }),
      });
      setSubmitted(true);
    } catch {
      setError('Deine Anfrage konnte gerade nicht gesendet werden. Bitte versuche es erneut.');
    } finally {
      setPending(false);
    }
  }

  if (submitted) {
    return (
      <output className={styles.success} aria-live="polite">
        <span className={styles.successMark} aria-hidden="true">
          ✓
        </span>
        <div>
          <strong>Danke! Deine Pilotanfrage ist angekommen.</strong>
          <p>Wir melden uns per E-Mail, um die Einrichtung abzustimmen.</p>
        </div>
      </output>
    );
  }

  return (
    <form onSubmit={handleSubmit} className={styles.form}>
      <div className={styles.contactFields}>
        <div className={styles.field}>
          <Label htmlFor="pilot-name">Dein Name</Label>
          <Input
            id="pilot-name"
            name="name"
            autoComplete="name"
            style={inputStyle}
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div className={styles.field}>
          <Label htmlFor="pilot-email">E-Mail-Adresse</Label>
          <Input
            id="pilot-email"
            name="email"
            type="email"
            autoComplete="email"
            style={inputStyle}
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className={styles.field}>
          <Label htmlFor="pilot-shop">Shop-URL</Label>
          <Input
            id="pilot-shop"
            name="shopUrl"
            type="url"
            placeholder="https://dein-shop.de"
            style={inputStyle}
            value={shopUrl}
            onChange={(e) => setShopUrl(e.target.value)}
            required
          />
        </div>
        <div className={styles.field}>
          <Label htmlFor="pilot-system">Shopsystem</Label>
          <select
            id="pilot-system"
            name="shopSystem"
            className="h-9 w-full rounded-md border border-input px-3 text-sm"
            style={inputStyle}
            value={shopSystem}
            onChange={(e) => setShopSystem(e.target.value)}
            required
          >
            <option value="">Bitte wählen</option>
            {shopSystemOptions.map((o) => (
              <option key={o} value={o}>
                {o}
              </option>
            ))}
          </select>
        </div>
      </div>

      <fieldset className={styles.willingnessGroup}>
        <legend className={styles.willingnessLegend}>Wettbewerber (optional, 3–5 URLs)</legend>
        <p className={styles.willingnessQuestion}>
          Shop- oder Produktseiten deiner wichtigsten Wettbewerber. Kannst du auch später
          nachreichen.
        </p>
        {competitorSlots.map((i) => (
          <Input
            key={i}
            aria-label={`Wettbewerber ${i + 1}`}
            type="url"
            placeholder={`https://wettbewerber-${i + 1}.de`}
            style={{ ...inputStyle, marginTop: '0.5rem' }}
            value={competitors[i]}
            onChange={(e) =>
              setCompetitors((cur) => cur.map((v, j) => (j === i ? e.target.value : v)))
            }
          />
        ))}
      </fieldset>

      <fieldset className={styles.willingnessGroup}>
        <legend className={styles.willingnessLegend}>Budget · optional & unverbindlich</legend>
        <p className={styles.willingnessQuestion}>
          Welche monatliche Größenordnung wäre für dich grundsätzlich realistisch?
        </p>
        <div className={styles.willingnessOptions}>
          {willingnessOptions.map((option) => (
            <label className={styles.willingnessOption} key={option}>
              <input
                type="radio"
                name="willingness"
                value={option}
                checked={willingness === option}
                onChange={(e) => setWillingness(e.target.value)}
              />
              <span>{option}</span>
            </label>
          ))}
        </div>
      </fieldset>

      <p className={styles.privacy}>
        Bitte teile keine Passwörter oder API-Schlüssel. Hinweise zur Verarbeitung findest du in der{' '}
        <a href="/datenschutz">Datenschutzerklärung</a>.
      </p>
      {error ? (
        <p className={styles.error} role="alert">
          {error}
        </p>
      ) : null}
      <Button type="submit" disabled={pending} className={styles.submit}>
        {pending ? 'Wird gesendet …' : 'Kostenlosen Pilot anfragen'}
        <span aria-hidden="true">→</span>
      </Button>
      <p className={styles.requiredNote}>Pflicht: Name, E-Mail, Shop-URL, Shopsystem.</p>
    </form>
  );
}
