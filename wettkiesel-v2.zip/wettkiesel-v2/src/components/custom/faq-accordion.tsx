// @polsia:user-owned — FAQ display. Restyle this freely, or swap the accordion
// for a card grid / whatever the brief calls for. It receives the SAME items the
// page emits as FAQPage JSON-LD, so changing the LOOK here never affects the
// structured data.
'use client';

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import type { FaqItem } from '@/lib/faq/content';

export function FaqAccordion({ items }: { items: FaqItem[] }) {
  return (
    <Accordion type="multiple" defaultValue={items.map((item) => item.id)} className="w-full">
      {items.map((item) => (
        <AccordionItem key={item.id} value={item.id} className="px-6">
          <AccordionTrigger>{item.question}</AccordionTrigger>
          <AccordionContent className="text-muted-foreground">{item.answer}</AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
}
