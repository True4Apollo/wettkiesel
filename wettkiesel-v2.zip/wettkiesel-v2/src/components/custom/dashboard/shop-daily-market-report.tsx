// @polsia:user-owned — compact, owner-scoped display of saved market movements.
'use client';

import { ExternalLink, RefreshCw, TrendingDown, TrendingUp } from 'lucide-react';
import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { apiFetch } from '@/lib/api-client';
import type { CompetitorAvailabilityStatus } from '@/lib/contracts/competitor-checks';
import {
  type ShopDailyMarketChange,
  ShopDailyMarketReport as ShopDailyMarketReportSchema,
  type ShopDailyMarketReport as ShopDailyMarketReportType,
} from '@/lib/contracts/market-reports';

const dateTimeFormat = new Intl.DateTimeFormat('de-DE', {
  dateStyle: 'medium',
  timeStyle: 'short',
  timeZone: 'UTC',
});

const dateFormat = new Intl.DateTimeFormat('de-DE', {
  dateStyle: 'long',
  timeZone: 'UTC',
});

const availabilityLabels: Record<CompetitorAvailabilityStatus, string> = {
  BackOrder: 'Rückstand',
  Discontinued: 'Nicht mehr verfügbar',
  InStock: 'Auf Lager',
  InStoreOnly: 'Nur im Geschäft',
  LimitedAvailability: 'Begrenzt verfügbar',
  MadeToOrder: 'Auf Bestellung',
  OnlineOnly: 'Nur online',
  OutOfStock: 'Nicht auf Lager',
  PreOrder: 'Vorbestellbar',
  PreSale: 'Vorverkauf',
  Reserved: 'Reserviert',
  SoldOut: 'Ausverkauft',
};

function competitorLabel(value: string) {
  try {
    return new URL(value).hostname;
  } catch {
    return value;
  }
}

function formatPrice(value: string, currency: string) {
  return `${new Intl.NumberFormat('de-DE', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 4,
  }).format(Number(value))} ${currency}`;
}

function MeasurementTime({ label, value }: { label: string; value: string }) {
  return (
    <p className="text-xs leading-5 text-muted-foreground">
      {label}: <time dateTime={value}>{dateTimeFormat.format(new Date(value))} UTC</time>
    </p>
  );
}

function ChangeCard({ change }: { change: ShopDailyMarketChange }) {
  const priceIncreased =
    change.price !== null && Number(change.price.currentValue) > Number(change.price.previousValue);

  return (
    <li className="grid gap-4 rounded-lg border border-border/80 bg-background p-4 sm:p-5">
      <div className="flex min-w-0 flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="grid min-w-0 gap-1">
          <h3 className="truncate font-semibold text-card-foreground">{change.productName}</h3>
          <a
            href={change.competitorUrl}
            target="_blank"
            rel="noreferrer noopener"
            className="flex min-w-0 items-center gap-1.5 text-sm text-primary underline-offset-4 hover:underline"
          >
            <span className="truncate">{competitorLabel(change.competitorUrl)}</span>
            <ExternalLink aria-hidden="true" className="size-3.5 shrink-0" />
          </a>
        </div>
        <Button asChild variant="outline" size="sm" className="w-full sm:w-auto">
          <Link href={change.productHref}>Produktdetails</Link>
        </Button>
      </div>

      <div className="grid gap-3 rounded-md bg-secondary/50 p-3 sm:grid-cols-2">
        <MeasurementTime label="Vorherige Messung" value={change.previousAt} />
        <MeasurementTime label="Aktuelle Messung" value={change.currentAt} />
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {change.price ? (
          <div className="grid content-start gap-1.5">
            <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              {priceIncreased ? (
                <TrendingUp aria-hidden="true" className="size-4" />
              ) : (
                <TrendingDown aria-hidden="true" className="size-4" />
              )}
              Preisänderung
            </p>
            <p className="text-sm text-foreground">
              {formatPrice(change.price.previousValue, change.price.currency)}
              <span className="px-2 text-muted-foreground" aria-hidden="true">
                →
              </span>
              {formatPrice(change.price.currentValue, change.price.currency)}
            </p>
          </div>
        ) : null}

        {change.availability ? (
          <div className="grid content-start gap-1.5">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Verfügbarkeit geändert
            </p>
            <p className="text-sm text-foreground">
              {availabilityLabels[change.availability.previousValue]}
              <span className="px-2 text-muted-foreground" aria-hidden="true">
                →
              </span>
              {availabilityLabels[change.availability.currentValue]}
            </p>
          </div>
        ) : null}
      </div>
    </li>
  );
}

export function ShopDailyMarketReport() {
  const [report, setReport] = useState<ShopDailyMarketReportType | null>(null);
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);

  const loadReport = useCallback(async () => {
    setLoading(true);
    setError(false);
    try {
      const result = await apiFetch('/api/shop/daily-market-report', {
        schema: ShopDailyMarketReportSchema,
      });
      setReport(result);
    } catch {
      setError(true);
      setReport(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadReport();
  }, [loadReport]);

  return (
    <Card className="border-border/70 shadow-sm">
      <CardHeader className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="grid gap-1.5">
          <CardTitle className="text-base">Tagesbericht: Marktbewegungen</CardTitle>
          <p className="text-sm text-muted-foreground">
            {report
              ? `Gespeicherte Wettbewerbermessungen vom ${dateFormat.format(new Date(`${report.date}T00:00:00.000Z`))} (UTC).`
              : 'Preis- und Verfügbarkeitsänderungen aus gespeicherten Messungen.'}
          </p>
        </div>
        <Button
          type="button"
          variant="outline"
          size="sm"
          className="w-full sm:w-auto"
          onClick={() => void loadReport()}
          disabled={loading}
        >
          <RefreshCw aria-hidden="true" className="size-4" />
          Bericht aktualisieren
        </Button>
      </CardHeader>
      <CardContent>
        {loading ? (
          <output aria-live="polite" className="block py-5 text-sm text-muted-foreground">
            Gespeicherte Marktbewegungen werden geladen …
          </output>
        ) : null}

        {error ? (
          <div className="grid gap-3 rounded-md border border-destructive/40 p-4">
            <p role="alert" className="text-sm text-destructive">
              Der Tagesbericht konnte nicht geladen werden. Es werden keine Änderungen geschätzt.
            </p>
            <Button
              type="button"
              variant="outline"
              className="w-fit"
              onClick={() => void loadReport()}
            >
              Erneut versuchen
            </Button>
          </div>
        ) : null}

        {report && !loading && report.status === 'no_measurements' ? (
          <output className="block rounded-md border border-dashed border-border px-4 py-6 text-sm leading-6 text-muted-foreground">
            Für deine aktiven Produkte liegen an diesem Tag keine verwertbaren Messdaten vor.
            Fehlgeschlagene oder unvollständige Prüfungen gelten nicht als Messung.
          </output>
        ) : null}

        {report && !loading && report.status === 'no_active_products' ? (
          <output className="block rounded-md border border-dashed border-border px-4 py-6 text-sm leading-6 text-muted-foreground">
            Es gibt keine aktiven Produkte, für die der Tagesbericht Messdaten auswerten kann.
          </output>
        ) : null}

        {report && !loading && report.status === 'no_movements' ? (
          <output className="block rounded-md border border-dashed border-border px-4 py-6 text-sm leading-6 text-muted-foreground">
            Für diesen Tag liegen verwertbare Messdaten vor, aber keine gespeicherte Preis- oder
            Verfügbarkeitsänderung. Unveränderte Werte und fehlende Vergleichswerte werden nicht als
            Marktbewegung angezeigt.
          </output>
        ) : null}

        {report && !loading && report.status === 'movements' ? (
          <ul className="grid gap-3">
            {report.changes.map((change) => (
              <ChangeCard key={change.id} change={change} />
            ))}
          </ul>
        ) : null}
      </CardContent>
    </Card>
  );
}
