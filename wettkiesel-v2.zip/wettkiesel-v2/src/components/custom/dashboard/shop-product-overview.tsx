// @polsia:user-owned
'use client';

import {
  AlertCircle,
  CheckCircle2,
  CircleHelp,
  ExternalLink,
  PackagePlus,
  PackageSearch,
  RefreshCw,
} from 'lucide-react';
import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import { ShopDailyMarketReport } from '@/components/custom/dashboard/shop-daily-market-report';
import { ShopProductMarketStatus } from '@/components/custom/dashboard/shop-product-market-status';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { apiFetch } from '@/lib/api-client';
import {
  type ShopProductLastCheckStatus,
  type ShopProductOverviewItem,
  ShopProductOverviewList as ShopProductOverviewListSchema,
} from '@/lib/contracts/shop-product-overview';
import { isValidProductPriceRange } from '@/lib/contracts/shop-products';

const formatPrice = new Intl.NumberFormat('de-DE', {
  style: 'currency',
  currency: 'EUR',
});

const formatDate = new Intl.DateTimeFormat('de-DE', {
  dateStyle: 'medium',
  timeStyle: 'short',
});

function checkLabel(status: ShopProductLastCheckStatus) {
  switch (status) {
    case 'pending':
      return 'Ausstehend';
    case 'processing':
      return 'Wird geprüft';
    case 'not_checked':
      return 'Nicht geprüft';
    case 'observed':
      return 'Erfolgreich';
    case 'partial':
      return 'Teilweise erfolgreich';
    case 'no_data':
      return 'Keine Daten gefunden';
    case 'inconsistent':
      return 'Widersprüchliche Daten';
    case 'incomplete':
      return 'Prüfung unvollständig';
    case 'unreadable':
      return 'Seite nicht lesbar';
    case 'invalid_target':
      return 'Ungültiges Prüfziel';
    case 'error':
      return 'Prüfung fehlgeschlagen';
  }
}

function LastCheck({ product }: { product: ShopProductOverviewItem }) {
  const check = product.lastCheck;
  if (!check) {
    return (
      <div className="grid content-start gap-2">
        <p className="text-sm font-medium text-muted-foreground">Letzte Prüfung</p>
        <Badge variant="outline" className="w-fit gap-1.5 font-medium">
          <CircleHelp aria-hidden="true" className="size-3.5" />
          Ungeprüft
        </Badge>
        <p className="text-xs leading-5 text-muted-foreground">
          Es liegt noch kein Prüfversuch vor.
        </p>
      </div>
    );
  }

  const successful = check.status === 'observed';
  const partial = check.status === 'partial';
  const inProgress = check.status === 'pending' || check.status === 'processing';
  const Icon = successful
    ? CheckCircle2
    : partial
      ? CircleHelp
      : inProgress
        ? RefreshCw
        : AlertCircle;

  return (
    <div className="grid content-start gap-2">
      <p className="text-sm font-medium text-muted-foreground">Letzte gespeicherte Prüfung</p>
      <Badge
        variant={
          successful ? 'default' : partial ? 'secondary' : inProgress ? 'outline' : 'destructive'
        }
        className={
          successful || partial || inProgress
            ? 'w-fit gap-1.5 font-medium'
            : 'w-fit gap-1.5 font-medium text-white dark:text-background'
        }
      >
        <Icon aria-hidden="true" className="size-3.5" />
        {checkLabel(check.status)}
      </Badge>
      <p className="text-xs leading-5 text-muted-foreground">
        {check.checkedAt
          ? `Gemessen am ${formatDate.format(new Date(check.checkedAt))}`
          : check.attemptedAt
            ? `Prüfversuch am ${formatDate.format(new Date(check.attemptedAt))} · kein Messzeitpunkt gespeichert`
            : 'Noch kein Messzeitpunkt gespeichert.'}
      </p>
    </div>
  );
}

export function ShopProductOverview() {
  const [products, setProducts] = useState<ShopProductOverviewItem[] | null>(null);
  const [error, setError] = useState(false);

  const loadProducts = useCallback(async () => {
    setError(false);
    setProducts(null);
    try {
      const result = await apiFetch('/api/shop/products', {
        schema: ShopProductOverviewListSchema,
      });
      setProducts(result.items);
    } catch {
      setError(true);
    }
  }, []);

  useEffect(() => {
    void loadProducts();
  }, [loadProducts]);

  return (
    <div className="grid gap-6">
      <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="grid gap-2">
          <p className="text-sm font-medium uppercase tracking-[0.12em] text-primary">
            Kundenkonto
          </p>
          <h1 className="text-3xl font-semibold tracking-tight text-foreground">Meine Produkte</h1>
          <p className="max-w-2xl text-sm leading-6 text-muted-foreground">
            Hier siehst du deine Produkte und den Status der gespeicherten Wettbewerbermessungen.
          </p>
        </div>
        <Button
          type="button"
          variant="outline"
          className="w-full sm:w-auto"
          onClick={() => void loadProducts()}
        >
          <RefreshCw aria-hidden="true" className="size-4" />
          Übersicht neu laden
        </Button>
      </header>

      <Card className="border-border/70 shadow-sm">
        <CardHeader>
          <CardTitle className="text-base">Produktübersicht</CardTitle>
          <p className="text-sm text-muted-foreground">
            {products === null
              ? error
                ? 'Bestand nicht verfügbar'
                : 'Bestand wird geladen'
              : `${products.length} gespeichert`}
          </p>
        </CardHeader>
        <CardContent>
          {products === null && !error ? (
            <output
              aria-live="polite"
              className="block py-8 text-center text-sm text-muted-foreground"
            >
              Produktbestand wird geladen …
            </output>
          ) : null}

          {error ? (
            <div className="grid justify-items-center gap-3 py-8 text-center">
              <p role="alert" className="text-sm text-destructive">
                Die Produktübersicht konnte nicht geladen werden. Prüfergebnisse sind bis zu einem
                erfolgreichen Abruf nicht verfügbar.
              </p>
              <Button type="button" variant="outline" onClick={() => void loadProducts()}>
                Erneut versuchen
              </Button>
            </div>
          ) : null}

          {products?.length === 0 && !error ? (
            <div className="grid justify-items-center gap-3 rounded-lg border border-dashed border-border px-5 py-12 text-center">
              <span className="grid size-11 place-items-center rounded-full bg-secondary text-secondary-foreground">
                <PackageSearch aria-hidden="true" className="size-5" />
              </span>
              <div className="grid gap-1">
                <h2 className="font-semibold">Lege dein erstes Produkt an</h2>
                <p className="max-w-md text-sm leading-6 text-muted-foreground">
                  Ergänze deine Produktseite und Preisgrenzen. Das Produkt wird deinem Konto
                  zugeordnet; Beispielprodukte oder Kundenkonten werden dabei nicht angelegt.
                </p>
              </div>
              <Button asChild>
                <Link href="/dashboard/products/new">
                  <PackagePlus aria-hidden="true" className="size-4" />
                  Erstes Produkt anlegen
                </Link>
              </Button>
            </div>
          ) : null}

          {products && products.length > 0 ? (
            <ul className="grid gap-3">
              {products.map((product) => (
                <li key={product.id}>
                  <article className="grid gap-5 rounded-lg border border-border/80 p-4 sm:grid-cols-[minmax(0,1.4fr)_minmax(180px,0.8fr)_minmax(180px,0.8fr)] sm:items-center sm:p-5">
                    <div className="grid min-w-0 gap-2">
                      <h2 className="break-words font-semibold text-card-foreground sm:truncate">
                        <Link
                          href={`/dashboard/products/${encodeURIComponent(product.id)}`}
                          aria-label={`Produktdetails für ${product.name} öffnen`}
                          className="underline-offset-4 hover:underline"
                        >
                          {product.name}
                        </Link>
                      </h2>
                      <a
                        href={product.ownUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="flex min-w-0 items-center gap-1.5 truncate text-sm text-muted-foreground underline-offset-4 hover:text-foreground hover:underline"
                      >
                        <span className="truncate">{product.ownUrl}</span>
                        <ExternalLink aria-hidden="true" className="size-3.5 shrink-0" />
                      </a>
                      <p className="text-xs text-muted-foreground">
                        {product.competitorUrls.length} Wettbewerber-URLs
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm sm:grid-cols-1 sm:gap-y-2">
                      <span className="text-muted-foreground">Preisgrenze</span>
                      <span className="text-right font-medium sm:text-left">
                        {formatPrice.format(product.minPrice)}–
                        {formatPrice.format(product.maxPrice)}
                      </span>
                      {!isValidProductPriceRange(product.minPrice, product.maxPrice) ? (
                        <Badge
                          variant="outline"
                          className="col-span-2 w-fit border-destructive text-destructive sm:col-span-1"
                        >
                          Ungültige Preisgrenzen prüfen
                        </Badge>
                      ) : null}
                    </div>

                    <LastCheck product={product} />
                    <ShopProductMarketStatus
                      status={product.marketStatus}
                      className="sm:col-span-3"
                    />
                  </article>
                </li>
              ))}
            </ul>
          ) : null}
        </CardContent>
      </Card>

      <ShopDailyMarketReport />
    </div>
  );
}
