// @polsia:user-owned
'use client';

import {
  ArrowLeft,
  CheckCircle2,
  CircleAlert,
  CircleHelp,
  ExternalLink,
  Plus,
  RefreshCw,
} from 'lucide-react';
import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import { CompetitorMeasurementPanel } from '@/components/custom/admin/competitor-measurement-panel';
import { ShopProductMarketStatus } from '@/components/custom/dashboard/shop-product-market-status';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { apiFetch } from '@/lib/api-client';
import type { CompetitorAvailabilityStatus } from '@/lib/contracts/competitor-checks';
import {
  type ShopProductLastCheckStatus,
  type ShopProductOverviewItem,
  ShopProductOverviewResponse,
} from '@/lib/contracts/shop-product-overview';
import { isValidProductPriceRange } from '@/lib/contracts/shop-products';

const formatPrice = new Intl.NumberFormat('de-DE', {
  style: 'currency',
  currency: 'EUR',
});

const formatDate = new Intl.DateTimeFormat('de-DE', {
  dateStyle: 'medium',
  timeStyle: 'short',
});

const availabilityLabels: Record<CompetitorAvailabilityStatus, string> = {
  BackOrder: 'Nachbestellbar',
  Discontinued: 'Nicht mehr erhältlich',
  InStock: 'Auf Lager',
  InStoreOnly: 'Nur im Geschäft',
  LimitedAvailability: 'Begrenzt verfügbar',
  MadeToOrder: 'Auf Bestellung gefertigt',
  OnlineOnly: 'Nur online',
  OutOfStock: 'Nicht auf Lager',
  PreOrder: 'Vorbestellbar',
  PreSale: 'Im Vorverkauf',
  Reserved: 'Reserviert',
  SoldOut: 'Ausverkauft',
};

const unavailableStatuses = new Set<CompetitorAvailabilityStatus>([
  'Discontinued',
  'OutOfStock',
  'SoldOut',
]);

function checkLabel(status: ShopProductLastCheckStatus) {
  switch (status) {
    case 'pending':
      return 'Ausstehend';
    case 'processing':
      return 'Wird geprüft';
    case 'not_checked':
      return 'Nicht geprüft';
    case 'observed':
      return 'Erfolgreich';
    case 'partial':
      return 'Teilweise erfolgreich';
    case 'no_data':
      return 'Keine Daten gefunden';
    case 'inconsistent':
      return 'Widersprüchliche Daten';
    case 'incomplete':
      return 'Prüfung unvollständig';
    case 'unreadable':
      return 'Seite nicht lesbar';
    case 'invalid_target':
      return 'Ungültiges Prüfziel';
    case 'error':
      return 'Prüfung fehlgeschlagen';
  }
}

function LastCheck({ product }: { product: ShopProductOverviewItem }) {
  const check = product.lastCheck;
  if (!check) {
    return (
      <div className="grid gap-2">
        <h2 className="text-sm font-medium text-muted-foreground">Letzte Prüfung</h2>
        <Badge variant="outline" className="w-fit">
          Ungeprüft
        </Badge>
        <p className="text-sm leading-6 text-muted-foreground">
          Es liegt noch kein gespeicherter Prüfversuch vor.
        </p>
      </div>
    );
  }

  const successful = check.status === 'observed';
  const partial = check.status === 'partial';
  const inProgress = check.status === 'pending' || check.status === 'processing';
  const Icon = successful
    ? CheckCircle2
    : partial
      ? CircleHelp
      : inProgress
        ? RefreshCw
        : CircleAlert;

  return (
    <div className="grid gap-2">
      <h2 className="text-sm font-medium text-muted-foreground">
        Letzter gespeicherter Messstatus
      </h2>
      <Badge
        variant={
          successful ? 'default' : partial ? 'secondary' : inProgress ? 'outline' : 'destructive'
        }
        className="w-fit"
      >
        <Icon aria-hidden="true" className="mr-1 size-3.5" />
        {checkLabel(check.status)}
      </Badge>
      <p className="text-sm text-muted-foreground">
        {check.checkedAt
          ? `Gemessen am ${formatDate.format(new Date(check.checkedAt))}`
          : check.attemptedAt
            ? `Prüfversuch am ${formatDate.format(new Date(check.attemptedAt))} · kein Messzeitpunkt gespeichert`
            : 'Noch kein Messzeitpunkt gespeichert.'}
      </p>
    </div>
  );
}

export function ShopProductDetail({ productId }: { productId: string }) {
  const [product, setProduct] = useState<ShopProductOverviewItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [unavailable, setUnavailable] = useState(false);
  const [error, setError] = useState(false);

  const fetchProduct = useCallback(async () => {
    const result = await apiFetch(`/api/shop/products/${encodeURIComponent(productId)}`, {
      schema: ShopProductOverviewResponse,
    });
    setProduct(result.item);
  }, [productId]);

  const refreshProduct = useCallback(async () => {
    try {
      await fetchProduct();
    } catch {
      setError(true);
    }
  }, [fetchProduct]);

  const loadProduct = useCallback(async () => {
    setLoading(true);
    setUnavailable(false);
    setError(false);
    try {
      await fetchProduct();
    } catch (cause) {
      setProduct(null);
      const body = cause instanceof Error ? cause.cause : null;
      const notFound =
        typeof body === 'object' && body !== null && 'error' in body && body.error === 'not_found';
      setUnavailable(notFound);
      setError(!notFound);
    } finally {
      setLoading(false);
    }
  }, [fetchProduct]);

  useEffect(() => {
    void loadProduct();
  }, [loadProduct]);

  return (
    <div className="grid min-w-0 grid-cols-[minmax(0,1fr)] gap-6">
      <div>
        <Button asChild variant="ghost" className="-ml-3">
          <Link href="/dashboard/products">
            <ArrowLeft aria-hidden="true" className="size-4" />
            Zurück zu meinen Produkten
          </Link>
        </Button>
      </div>

      {loading ? (
        <output aria-live="polite" className="block py-8 text-center text-sm text-muted-foreground">
          Produktdetails werden geladen …
        </output>
      ) : null}

      {unavailable ? (
        <div className="grid justify-items-start gap-3 rounded-lg border border-border/80 p-6">
          <h1 className="text-xl font-semibold">Produkt nicht verfügbar</h1>
          <p className="text-sm leading-6 text-muted-foreground">
            Dieses Produkt ist in deinem Konto nicht verfügbar.
          </p>
        </div>
      ) : null}

      {error ? (
        <div className="grid justify-items-start gap-3 rounded-lg border border-border/80 p-6">
          <p role="alert" className="text-sm text-destructive">
            Produktdetails konnten nicht geladen werden.
          </p>
          <Button type="button" variant="outline" onClick={() => void loadProduct()}>
            <RefreshCw aria-hidden="true" className="size-4" />
            Erneut versuchen
          </Button>
        </div>
      ) : null}

      {product ? (
        <>
          <header className="grid gap-2">
            <p className="text-sm font-medium uppercase tracking-[0.12em] text-primary">
              Produktdetails
            </p>
            <h1 className="text-3xl font-semibold tracking-tight text-foreground">
              {product.name}
            </h1>
          </header>

          <Card className="border-border/70 shadow-sm">
            <CardHeader>
              <CardTitle className="text-base">Marktstatus</CardTitle>
              <p className="text-sm text-muted-foreground">
                Verglichen werden jeweils die zwei neuesten gespeicherten Beobachtungen pro
                Wettbewerber.
              </p>
            </CardHeader>
            <CardContent>
              <ShopProductMarketStatus status={product.marketStatus} />
            </CardContent>
          </Card>

          <Card className="border-border/70 shadow-sm">
            <CardHeader>
              <CardTitle className="text-base">Produktangaben</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-6 sm:grid-cols-2">
              <div className="grid content-start gap-2">
                <h2 className="text-sm font-medium text-muted-foreground">Eigene Produktseite</h2>
                <a
                  href={product.ownUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="flex min-w-0 items-center gap-2 break-all text-sm underline underline-offset-4"
                >
                  <span>{product.ownUrl}</span>
                  <ExternalLink aria-hidden="true" className="size-3.5 shrink-0" />
                </a>
              </div>
              <div className="grid content-start gap-2">
                <h2 className="text-sm font-medium text-muted-foreground">Preisgrenze</h2>
                <p className="text-sm font-medium">
                  {formatPrice.format(product.minPrice)}–{formatPrice.format(product.maxPrice)}
                </p>
                {!isValidProductPriceRange(product.minPrice, product.maxPrice) ? (
                  <Badge variant="outline" className="w-fit border-destructive text-destructive">
                    Ungültige Preisgrenzen prüfen
                  </Badge>
                ) : null}
              </div>
              <LastCheck product={product} />
              <div className="grid content-start gap-3 sm:col-span-2">
                <h2 className="text-sm font-medium text-muted-foreground">Wettbewerber</h2>
                {product.competitorLastChecks.length > 0 ? (
                  <ul className="grid gap-4">
                    {product.competitorLastChecks.map(
                      ({ competitorUrl, lastCheck, availabilityMeasurement }) => (
                        <li key={competitorUrl} className="grid min-w-0 gap-1.5">
                          <a
                            href={competitorUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="block break-all text-sm text-foreground underline underline-offset-4"
                          >
                            {competitorUrl}
                          </a>
                          <div className="grid gap-2 rounded-md border border-border/70 bg-muted/20 p-3">
                            <h3 className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                              Letzte gespeicherte Verfügbarkeit
                            </h3>
                            {availabilityMeasurement ? (
                              <>
                                <Badge
                                  variant={
                                    availabilityMeasurement.availability &&
                                    unavailableStatuses.has(availabilityMeasurement.availability)
                                      ? 'destructive'
                                      : availabilityMeasurement.availability
                                        ? 'secondary'
                                        : 'outline'
                                  }
                                  className="w-fit"
                                >
                                  {availabilityMeasurement.availability
                                    ? availabilityLabels[availabilityMeasurement.availability]
                                    : 'Nicht erhoben / keine Angabe'}
                                </Badge>
                                <p className="text-xs text-muted-foreground">
                                  {availabilityMeasurement.checkedAt
                                    ? `Messzeitpunkt: ${formatDate.format(new Date(availabilityMeasurement.checkedAt))}`
                                    : availabilityMeasurement.attemptedAt
                                      ? `Prüfversuch: ${formatDate.format(new Date(availabilityMeasurement.attemptedAt))} · kein Messzeitpunkt gespeichert`
                                      : 'Für diesen Datensatz ist kein Messzeitpunkt gespeichert.'}
                                </p>
                                <a
                                  href={`#measurement-${availabilityMeasurement.measurementId}`}
                                  className="w-fit text-xs text-primary underline underline-offset-4"
                                  aria-label={`Messdatensatz ${availabilityMeasurement.measurementId} im Prüfverlauf anzeigen`}
                                >
                                  Messdatensatz {availabilityMeasurement.measurementId} im Verlauf
                                  anzeigen
                                </a>
                              </>
                            ) : (
                              <p className="text-sm text-muted-foreground">
                                Noch kein passender Messdatensatz gespeichert.
                              </p>
                            )}
                          </div>
                          {lastCheck ? (
                            <div className="grid justify-items-start gap-1">
                              <Badge
                                variant={lastCheck.status === 'observed' ? 'default' : 'secondary'}
                                className="w-fit"
                              >
                                {checkLabel(lastCheck.status)}
                              </Badge>
                              {lastCheck.checkedAt || lastCheck.attemptedAt ? (
                                <time
                                  dateTime={
                                    lastCheck.checkedAt ?? lastCheck.attemptedAt ?? undefined
                                  }
                                  className="text-sm text-muted-foreground"
                                >
                                  {lastCheck.checkedAt
                                    ? `Letzte Messung: ${formatDate.format(new Date(lastCheck.checkedAt))}`
                                    : `Prüfversuch: ${formatDate.format(new Date(lastCheck.attemptedAt ?? ''))} · kein Messzeitpunkt gespeichert`}
                                </time>
                              ) : (
                                <p className="text-sm text-muted-foreground">Messung ausstehend.</p>
                              )}
                            </div>
                          ) : (
                            <p className="text-sm text-muted-foreground">
                              Noch kein Prüfversuch gespeichert.
                            </p>
                          )}
                        </li>
                      ),
                    )}
                  </ul>
                ) : (
                  <div className="grid justify-items-start gap-4 rounded-lg border border-dashed border-border bg-muted/30 p-5 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center">
                    <div className="grid gap-1.5">
                      <p className="font-medium text-foreground">
                        Noch keine Wettbewerber hinterlegt.
                      </p>
                      <p
                        id="competitor-add-unavailable"
                        className="max-w-xl text-sm leading-6 text-muted-foreground"
                      >
                        Das Ergänzungsformular für bestehende Produkte im Shopbereich fehlt derzeit.
                        Deshalb ist das Hinzufügen hier noch nicht möglich.
                      </p>
                    </div>
                    <Button
                      type="button"
                      variant="outline"
                      disabled
                      aria-describedby="competitor-add-unavailable"
                      className="w-full disabled:opacity-100 disabled:text-foreground/70 sm:w-auto"
                    >
                      <Plus aria-hidden="true" className="size-4" />
                      Wettbewerber hinzufügen
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <CompetitorMeasurementPanel
            productId={product.id}
            competitorCount={product.competitorUrls.length}
            isArchived={product.isArchived}
            ownerScoped
            onUpdate={refreshProduct}
          />
        </>
      ) : null}
    </div>
  );
}
