// @polsia:user-owned
'use client';

import { ClipboardList, MessageSquareText, PackageSearch, Store } from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';

// Add every admin feature here; child pages inherit this navigation.
const navItems = [
  { href: '/admin', label: 'Shopübersicht', icon: Store },
  { href: '/admin/pilotanfragen', label: 'Pilotanfragen', icon: ClipboardList },
  {
    href: '/admin/tagesbericht-feedback',
    label: 'Tagesbericht-Feedback',
    icon: MessageSquareText,
  },
  { href: '/admin/products', label: 'Produkte', icon: PackageSearch },
];

export function AdminNav() {
  const pathname = usePathname();

  return (
    <nav aria-label="Shopverwaltung" className="flex flex-wrap gap-2 pb-1 lg:grid lg:pb-0">
      {navItems.map((item) => {
        const Icon = item.icon;
        const active =
          pathname === item.href ||
          (item.href !== '/admin' && pathname.startsWith(`${item.href}/`));

        return (
          <Link
            key={item.href}
            href={item.href}
            aria-current={active ? 'page' : undefined}
            className={cn(
              'flex h-10 shrink-0 items-center gap-2 rounded-md px-3 text-sm font-medium transition-colors',
              active
                ? 'bg-secondary text-secondary-foreground'
                : 'text-muted-foreground hover:bg-secondary/70 hover:text-foreground',
            )}
          >
            <Icon aria-hidden="true" className="size-4" />
            <span>{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
