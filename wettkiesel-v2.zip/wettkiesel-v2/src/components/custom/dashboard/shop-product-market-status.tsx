// @polsia:user-owned — concise view of saved competitor measurements.
import { Badge } from '@/components/ui/badge';
import type { ShopProductMarketStatus as MarketStatus } from '@/lib/contracts/shop-product-overview';

function changeLabel(changed: boolean | null, comparedCompetitors: number) {
  if (changed === null) return 'Noch nicht vergleichbar';
  if (changed) return 'Änderung erkannt';
  return `Keine Änderung (${comparedCompetitors} ${comparedCompetitors === 1 ? 'Vergleich' : 'Vergleiche'})`;
}

export function ShopProductMarketStatus({
  status,
  className = '',
}: {
  status: MarketStatus;
  className?: string;
}) {
  return (
    <section
      aria-label="Wettbewerberstatus"
      className={`grid gap-3 border-t border-border/70 pt-4 sm:grid-cols-3 sm:items-start ${className}`}
    >
      <div className="grid content-start gap-2">
        <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          Gespeicherte Messwerte
        </p>
        <Badge variant={status.measurementsAvailable ? 'secondary' : 'outline'} className="w-fit">
          {status.measurementsAvailable
            ? `Bei ${status.competitorsWithMeasurements} ${status.competitorsWithMeasurements === 1 ? 'Wettbewerber' : 'Wettbewerbern'} vorhanden`
            : 'Keine auswertbaren Messwerte'}
        </Badge>
      </div>
      <div className="grid content-start gap-2">
        <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Preis</p>
        <p className="text-sm font-medium text-foreground">
          {changeLabel(status.priceChange.changed, status.priceChange.comparedCompetitors)}
        </p>
      </div>
      <div className="grid content-start gap-2">
        <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          Verfügbarkeit
        </p>
        <p className="text-sm font-medium text-foreground">
          {changeLabel(
            status.availabilityChange.changed,
            status.availabilityChange.comparedCompetitors,
          )}
        </p>
      </div>
    </section>
  );
}
