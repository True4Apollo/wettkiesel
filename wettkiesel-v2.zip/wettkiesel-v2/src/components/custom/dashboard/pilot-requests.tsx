// @polsia:user-owned
'use client';

import { CalendarDays, Inbox, MessageSquareText } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { apiFetch } from '@/lib/api-client';
import { PilotRequestList } from '@/lib/contracts/pilot-requests';

type LoadState = 'loading' | 'ready' | 'error';

export function PilotRequests() {
  const [items, setItems] = useState<PilotRequestList['items']>([]);
  const [loadState, setLoadState] = useState<LoadState>('loading');

  const loadRequests = useCallback(() => {
    setLoadState('loading');

    apiFetch('/api/admin/pilot-requests', { schema: PilotRequestList })
      .then((result) => {
        setItems(result.items);
        setLoadState('ready');
      })
      .catch(() => setLoadState('error'));
  }, []);

  useEffect(() => {
    loadRequests();
  }, [loadRequests]);

  return (
    <div className="grid gap-6">
      <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="grid gap-2">
          <p className="text-sm font-medium uppercase tracking-[0.12em] text-primary">
            Wettkiesel · Pilot
          </p>
          <h1 className="text-3xl font-semibold tracking-tight text-foreground">Pilotanfragen</h1>
          <p className="max-w-2xl text-sm leading-6 text-muted-foreground">
            Eingegangene Antworten zur unverbindlichen Zahlungsbereitschaft.
          </p>
        </div>
        {loadState === 'ready' ? (
          <div className="rounded-lg border border-border/70 bg-card px-4 py-3 sm:min-w-32">
            <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Anfragen
            </p>
            <p className="mt-1 text-2xl font-semibold tabular-nums text-foreground">
              {items.length}
            </p>
          </div>
        ) : null}
      </header>

      {loadState === 'loading' ? (
        <output
          className="grid gap-3"
          aria-label="Pilotanfragen werden geladen"
          aria-busy="true"
          aria-live="polite"
        >
          {['pilot-loading-eins', 'pilot-loading-zwei'].map((item) => (
            <div
              key={item}
              className="h-36 animate-pulse rounded-xl border border-border/70 bg-card"
            />
          ))}
        </output>
      ) : null}

      {loadState === 'error' ? (
        <Card>
          <CardContent className="grid justify-items-start gap-3 p-6">
            <p role="alert" className="text-sm leading-6 text-muted-foreground">
              Pilotanfragen konnten nicht geladen werden. Bitte versuche es erneut.
            </p>
            <Button type="button" variant="outline" onClick={loadRequests}>
              Erneut laden
            </Button>
          </CardContent>
        </Card>
      ) : null}

      {loadState === 'ready' && items.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="grid justify-items-center gap-3 px-6 py-12 text-center">
            <span className="flex size-12 items-center justify-center rounded-full bg-secondary text-secondary-foreground">
              <Inbox aria-hidden="true" className="size-5" />
            </span>
            <div className="grid gap-1">
              <h2 className="font-semibold text-foreground">Noch keine Pilotanfragen</h2>
              <p className="max-w-md text-sm leading-6 text-muted-foreground">
                Sobald jemand das Pilotformular absendet, erscheint die Anfrage hier.
              </p>
            </div>
          </CardContent>
        </Card>
      ) : null}

      {loadState === 'ready' && items.length > 0 ? (
        <section aria-label="Eingegangene Pilotanfragen" className="grid gap-4">
          {items.map((item) => (
            <Card key={item.id} className="border-border/70 shadow-sm">
              <CardHeader className="gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="grid gap-2">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <MessageSquareText aria-hidden="true" className="size-4 text-primary" />
                    Pilotanfrage
                  </CardTitle>
                  <p className="flex items-center gap-2 text-sm text-muted-foreground">
                    <CalendarDays aria-hidden="true" className="size-4 shrink-0" />
                    <span>
                      Eingegangen am{' '}
                      {new Intl.DateTimeFormat('de-DE', {
                        dateStyle: 'medium',
                        timeStyle: 'short',
                        timeZone: 'Europe/Berlin',
                      }).format(new Date(item.createdAt))}
                    </span>
                  </p>
                </div>
                <div className="grid gap-2 sm:justify-items-end">
                  <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                    Zahlungsbereitschaft · unverbindlich
                  </p>
                  <Badge variant="secondary" className="w-fit text-sm sm:w-auto">
                    {item.willingness ?? 'Keine Antwort gespeichert'}
                  </Badge>
                </div>
              </CardHeader>
              {item.answers ? (
                <CardContent className="border-t border-border/70 pt-4">
                  <details className="group">
                    <summary className="w-fit cursor-pointer text-sm font-medium text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring">
                      Weitere Antworten anzeigen
                    </summary>
                    <p className="mt-3 whitespace-pre-wrap break-words text-sm leading-6 text-muted-foreground">
                      {item.answers}
                    </p>
                  </details>
                </CardContent>
              ) : null}
            </Card>
          ))}
        </section>
      ) : null}
    </div>
  );
}
