// @polsia:user-owned
'use client';

import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import type { CsvDelimiter, CsvExportErrorCode } from '@/modules/csv-export/contracts';
import { exportErrorSchema } from '@/modules/csv-export/contracts';
import { requestCsvExport, saveCsvFile } from '@/modules/csv-export/download';

const exportErrorMessages: Record<CsvExportErrorCode, string> = {
  UNAUTHENTICATED: 'Melde dich an, um Messwerte zu exportieren.',
  FORBIDDEN: 'Du bist nicht berechtigt, diese Messwerte zu exportieren.',
  INVALID_REQUEST: 'Die Exportanfrage ist ungültig. Bitte versuche es erneut.',
  INVALID_FILTERS: 'Die Produktauswahl ist ungültig. Bitte lade die Seite neu.',
  SOURCE_NOT_FOUND: 'Die CSV-Quelle ist nicht verfügbar.',
  NO_RESULTS: 'Für dieses Produkt liegen keine Messwerte zum Export vor.',
  ROW_LIMIT: 'Der Export umfasst zu viele Zeilen. Bitte grenze die Auswahl ein.',
  BYTE_LIMIT: 'Die Exportdatei ist zu groß. Bitte grenze die Auswahl ein.',
  CELL_LIMIT: 'Ein Messwert ist zu lang; die CSV-Datei wurde nicht erstellt.',
  BODY_LIMIT: 'Die Exportanfrage ist zu groß. Bitte versuche es erneut.',
  READ_FAILED: 'Die Messwerte konnten nicht gelesen werden. Es wurde keine Datei erstellt.',
  INVALID_SOURCE: 'Die Exportdaten sind ungültig. Es wurde keine Datei erstellt.',
  TIMEOUT: 'Der Export hat zu lange gedauert. Bitte versuche es erneut.',
  CANCELLED: 'Der Export wurde abgebrochen.',
};

function exportErrorMessage(error: unknown) {
  if (error instanceof Error) {
    const parsed = exportErrorSchema.safeParse(error.cause);
    if (parsed.success) {
      const match = Object.entries(exportErrorMessages).find(
        ([code]) => code === parsed.data.error.code,
      );
      if (match) return match[1];
    }
  }
  return 'Der CSV-Download ist fehlgeschlagen. Bitte versuche es erneut.';
}

export interface CsvExporterProps {
  sourceId: string;
  filters: unknown;
  columns?: string[];
  delimiter?: CsvDelimiter;
  label?: string;
}

export function CsvExporter({
  sourceId,
  filters,
  columns,
  delimiter = ',',
  label = 'CSV exportieren',
}: CsvExporterProps) {
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState('');
  const active = useRef<AbortController | null>(null);
  const requestKey = JSON.stringify({ sourceId, filters, columns, delimiter });

  useEffect(() => {
    // Changing active filters/source invalidates an outstanding export.
    if (requestKey) {
      setStatus('idle');
      setMessage('');
    }
    return () => {
      active.current?.abort();
      active.current = null;
    };
  }, [requestKey]);

  async function download() {
    if (active.current) return;
    const controller = new AbortController();
    active.current = controller;
    setStatus('loading');
    setMessage('');
    try {
      const result = await requestCsvExport(
        { sourceId, filters, columns, delimiter },
        controller.signal,
      );
      if (controller.signal.aborted || active.current !== controller) return;
      saveCsvFile(result.data.csv, result.data.filename);
      const recordLabel =
        result.data.records === 1 ? 'Messung exportiert.' : 'Messungen exportiert.';
      setMessage(`${result.data.records.toLocaleString('de-DE')} ${recordLabel}`);
      setStatus('success');
    } catch (error) {
      if (controller.signal.aborted || active.current !== controller) return;
      setMessage(exportErrorMessage(error));
      setStatus('error');
    } finally {
      if (active.current === controller) active.current = null;
    }
  }

  return (
    <div className="space-y-2">
      <Button
        type="button"
        disabled={status === 'loading'}
        onClick={download}
        aria-busy={status === 'loading'}
      >
        {status === 'loading' ? 'CSV wird erstellt…' : label}
      </Button>
      {message && (
        <p className="text-sm" role={status === 'error' ? 'alert' : 'status'}>
          {message}
        </p>
      )}
    </div>
  );
}
