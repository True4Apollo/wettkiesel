// @polsia:user-owned — seeded by polsia/modules/better-auth; restyle freely.

import Link from 'next/link';
import { SignUpForm } from '@/components/custom/sign-up-form';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

export default function SignupPage() {
  return (
    <main className="min-h-dvh flex items-center justify-center px-gutter py-section bg-[var(--background)]">
      <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
        <div className="absolute top-[-30%] left-1/2 -translate-x-1/2 w-[800px] h-[800px] rounded-full bg-[var(--brand-100)] opacity-40 blur-3xl" />
        <div className="absolute bottom-[-20%] left-[-10%] w-[500px] h-[500px] rounded-full bg-[var(--brand-200)] opacity-30 blur-3xl" />
      </div>

      <Card className="relative w-full max-w-md shadow-brand border border-border/60 bg-card/95 backdrop-blur-sm">
        <CardHeader className="text-center pb-2">
          <CardTitle className="text-h4">Wettkiesel-Konto anlegen</CardTitle>
          <CardDescription>
            Das Konto kann auch ohne vorhandenes Produkt angelegt werden.
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-4">
          <SignUpForm />
          <p className="mt-4 text-sm leading-6 text-muted-foreground">
            Owner-Rechte erhält nur die bestätigte E-Mail-Adresse, die Wettkiesel als Inhaberadresse
            hinterlegt hat. Für den Zugang sind keine Plattform-Zugangsdaten erforderlich.
          </p>
          <p className="mt-4 text-center text-sm text-muted-foreground">
            Du hast bereits ein Konto?{' '}
            <Link
              href="/login"
              className="font-medium text-primary underline-offset-4 hover:underline"
            >
              Anmelden
            </Link>
          </p>
        </CardContent>
      </Card>
    </main>
  );
}
