// @polsia:user-owned
import 'server-only';
import { NextResponse } from 'next/server';
import { authorizeProductAdmin } from '@/lib/business/product-admin-auth';
import {
  ShopProductInput,
  ShopProductItem,
  ShopProductResponse,
} from '@/lib/contracts/shop-products';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

type RouteContext = { params: Promise<{ productId: string }> };

function toItem(product: {
  id: string;
  isArchived: boolean;
  name: string;
  ownUrl: string;
  competitorUrls: string[];
  minPriceCents: number;
  maxPriceCents: number;
  createdAt: Date;
  updatedAt: Date;
}) {
  return ShopProductItem.parse({
    id: product.id,
    isArchived: product.isArchived,
    name: product.name,
    ownUrl: product.ownUrl,
    competitorUrls: product.competitorUrls,
    minPrice: product.minPriceCents / 100,
    maxPrice: product.maxPriceCents / 100,
    createdAt: product.createdAt.toISOString(),
    updatedAt: product.updatedAt.toISOString(),
  });
}

function invalidInput(error: {
  flatten: () => { fieldErrors: Record<string, string[] | undefined> };
}) {
  const fieldErrors: Record<string, string> = {};
  for (const [field, messages] of Object.entries(error.flatten().fieldErrors)) {
    const message = messages?.[0];
    if (message) fieldErrors[field] = message;
  }
  return NextResponse.json({ errors: fieldErrors }, { status: 400 });
}

export async function GET(_request: Request, context: RouteContext) {
  const access = await authorizeProductAdmin();
  if (!access.ok) return access.response;
  const { productId } = await context.params;
  const product = await prisma.shopProduct.findFirst({
    where: { id: productId, userId: access.userId },
  });
  if (!product) return NextResponse.json({ error: 'not_found' }, { status: 404 });
  return NextResponse.json(ShopProductResponse.parse({ item: toItem(product) }));
}

export async function PATCH(request: Request, context: RouteContext) {
  const access = await authorizeProductAdmin();
  if (!access.ok) return access.response;
  const { productId } = await context.params;

  const body: unknown = await request.json().catch(() => null);
  const parsed = ShopProductInput.safeParse(body);
  if (!parsed.success) return invalidInput(parsed.error);

  try {
    const updated = await prisma.shopProduct.updateMany({
      where: { id: productId, userId: access.userId },
      data: {
        name: parsed.data.name,
        ownUrl: parsed.data.ownUrl,
        competitorUrls: parsed.data.competitorUrls,
        minPriceCents: Math.round(parsed.data.minPrice * 100),
        maxPriceCents: Math.round(parsed.data.maxPrice * 100),
      },
    });
    if (updated.count === 0) return NextResponse.json({ error: 'not_found' }, { status: 404 });

    const product = await prisma.shopProduct.findFirst({
      where: { id: productId, userId: access.userId },
    });
    if (!product) return NextResponse.json({ error: 'not_found' }, { status: 404 });
    return NextResponse.json(ShopProductResponse.parse({ item: toItem(product) }));
  } catch {
    return NextResponse.json({ error: 'internal_error' }, { status: 500 });
  }
}
