// @polsia:user-owned
import 'server-only';
import { NextResponse } from 'next/server';
import { authorizeProductAdmin } from '@/lib/business/product-admin-auth';

export const dynamic = 'force-dynamic';

type RouteContext = { params: Promise<{ productId: string }> };

export async function POST(_request: Request, _context: RouteContext) {
  const access = await authorizeProductAdmin();
  if (!access.ok) return access.response;

  return NextResponse.json(
    {
      error: 'price_changes_disabled',
      reasons: ['shop_platform_not_connected', 'operator_api_credentials_missing'],
      message:
        'Preisänderungen bleiben gesperrt: Shopplattform nicht verbunden und Betreiber-API-Zugangsdaten nicht hinterlegt.',
    },
    { status: 403 },
  );
}
