// @polsia:user-owned — Eigentümergebundenes Nützlichkeitsfeedback zu Marktberichten.
import 'server-only';
import { NextResponse } from 'next/server';
import { authorizeProductAdmin } from '@/lib/business/product-admin-auth';
import {
  MarketReportFeedbackInput,
  MarketReportFeedbackResponse,
} from '@/lib/contracts/market-reports';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

type RouteContext = { params: Promise<{ productId: string }> };

function invalidInput(error: {
  flatten: () => { fieldErrors: Record<string, string[] | undefined> };
}) {
  const errors: Record<string, string> = {};
  for (const [field, messages] of Object.entries(error.flatten().fieldErrors)) {
    const message = messages?.[0];
    if (message) errors[field] = message;
  }
  return NextResponse.json({ errors }, { status: 400 });
}

export async function POST(request: Request, context: RouteContext) {
  const access = await authorizeProductAdmin();
  if (!access.ok) return access.response;

  const body: unknown = await request.json().catch(() => null);
  const parsed = MarketReportFeedbackInput.safeParse(body);
  if (!parsed.success) return invalidInput(parsed.error);

  const { productId } = await context.params;
  const product = await prisma.shopProduct.findFirst({
    where: { id: productId, userId: access.userId },
    select: { id: true },
  });
  if (!product) return NextResponse.json({ error: 'not_found' }, { status: 404 });

  const report = await prisma.shopMarketReport.findFirst({
    where: { id: parsed.data.reportId, productId: product.id },
    select: { id: true },
  });
  if (!report) return NextResponse.json({ error: 'not_found' }, { status: 404 });

  const reason = parsed.data.reason?.trim() || null;
  const feedback = await prisma.shopMarketReportFeedback.upsert({
    where: { reportId_userId: { reportId: report.id, userId: access.userId } },
    create: {
      reportId: report.id,
      userId: access.userId,
      isUseful: parsed.data.isUseful,
      reason,
    },
    update: { isUseful: parsed.data.isUseful, reason },
    select: {
      id: true,
      reportId: true,
      isUseful: true,
      reason: true,
      createdAt: true,
      updatedAt: true,
    },
  });

  return NextResponse.json(
    MarketReportFeedbackResponse.parse({
      feedback: {
        ...feedback,
        createdAt: feedback.createdAt.toISOString(),
        updatedAt: feedback.updatedAt.toISOString(),
      },
    }),
  );
}
