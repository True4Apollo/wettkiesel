// @polsia:user-owned — confirmation-gated, owner-scoped product archive action.
import 'server-only';
import { NextResponse } from 'next/server';
import { archiveShopProductForOwner } from '@/lib/business/archive-shop-product';
import { authorizeProductAdmin } from '@/lib/business/product-admin-auth';
import { ShopProductArchiveInput, ShopProductArchiveResponse } from '@/lib/contracts/shop-products';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

type RouteContext = { params: Promise<{ productId: string }> };

export async function POST(request: Request, context: RouteContext) {
  const access = await authorizeProductAdmin();
  if (!access.ok) return access.response;

  const body: unknown = await request.json().catch(() => null);
  const confirmation = ShopProductArchiveInput.safeParse(body);
  if (!confirmation.success) {
    return NextResponse.json({ error: 'confirmation_required' }, { status: 400 });
  }

  const { productId } = await context.params;
  const archived = await archiveShopProductForOwner(prisma, productId, access.userId);
  if (!archived) return NextResponse.json({ error: 'not_found' }, { status: 404 });

  return NextResponse.json(
    ShopProductArchiveResponse.parse({ item: { id: productId, isArchived: true } }),
  );
}
