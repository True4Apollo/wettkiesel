// @polsia:user-owned — persisted owner-scoped daily market reports.
import 'server-only';
import { NextResponse } from 'next/server';
import { buildMarketReport } from '@/lib/business/market-report';
import { authorizeProductAdmin } from '@/lib/business/product-admin-auth';
import { parseCompetitorAvailability } from '@/lib/contracts/competitor-checks';
import {
  MarketReport,
  MarketReportCreateInput,
  MarketReportCreateResponse,
  MarketReportQueryResponse,
} from '@/lib/contracts/market-reports';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

type RouteContext = { params: Promise<{ productId: string }> };

function invalidDate() {
  return NextResponse.json({ error: 'invalid_date' }, { status: 400 });
}

function normalizeSavedReport(value: unknown) {
  if (typeof value !== 'object' || value === null || !('observations' in value)) {
    return MarketReport.parse(value);
  }
  const record = value as Record<string, unknown>;
  if (!Array.isArray(record.observations)) return MarketReport.parse(value);
  return MarketReport.parse({
    ...record,
    observations: record.observations.map((item) => {
      if (typeof item !== 'object' || item === null) return item;
      const observation = item as Record<string, unknown>;
      return {
        ...observation,
        availability: parseCompetitorAvailability(
          typeof observation.availability === 'string' ? observation.availability : null,
        ),
        previousAvailability: parseCompetitorAvailability(
          typeof observation.previousAvailability === 'string'
            ? observation.previousAvailability
            : null,
        ),
      };
    }),
  });
}

export async function GET(request: Request, context: RouteContext) {
  const access = await authorizeProductAdmin();
  if (!access.ok) return access.response;

  const dateInput = new URL(request.url).searchParams.get('date');
  const parsedDate = MarketReportCreateInput.safeParse({ date: dateInput });
  if (!parsedDate.success) return invalidDate();

  const { productId } = await context.params;
  const product = await prisma.shopProduct.findFirst({
    where: { id: productId, userId: access.userId },
    select: { id: true },
  });
  if (!product) return NextResponse.json({ error: 'not_found' }, { status: 404 });

  const saved = await prisma.shopMarketReport.findUnique({
    where: { productId_dateKey: { productId, dateKey: parsedDate.data.date } },
    select: { id: true, report: true },
  });
  const feedback = saved
    ? await prisma.shopMarketReportFeedback.findUnique({
        where: { reportId_userId: { reportId: saved.id, userId: access.userId } },
        select: {
          id: true,
          reportId: true,
          isUseful: true,
          reason: true,
          createdAt: true,
          updatedAt: true,
        },
      })
    : null;
  return NextResponse.json(
    MarketReportQueryResponse.parse({
      report: saved ? normalizeSavedReport(saved.report) : null,
      reportId: saved?.id ?? null,
      feedback: feedback
        ? {
            ...feedback,
            createdAt: feedback.createdAt.toISOString(),
            updatedAt: feedback.updatedAt.toISOString(),
          }
        : null,
    }),
  );
}

export async function POST(request: Request, context: RouteContext) {
  const access = await authorizeProductAdmin();
  if (!access.ok) return access.response;

  const body: unknown = await request.json().catch(() => null);
  const parsedInput = MarketReportCreateInput.safeParse(body);
  if (!parsedInput.success) return invalidDate();

  const { productId } = await context.params;
  const product = await prisma.shopProduct.findFirst({
    where: { id: productId, userId: access.userId },
    select: { id: true },
  });
  if (!product) return NextResponse.json({ error: 'not_found' }, { status: 404 });

  const dayStart = new Date(`${parsedInput.data.date}T00:00:00.000Z`);
  const dayEnd = new Date(dayStart.getTime() + 24 * 60 * 60 * 1000);
  const measurements = await prisma.competitorCheckMeasurement.findMany({
    where: {
      run: { productId },
      targetType: 'competitor',
      checkedAt: { gte: dayStart, lt: dayEnd },
    },
    orderBy: [{ checkedAt: 'asc' }, { id: 'asc' }],
    select: {
      id: true,
      competitorUrl: true,
      status: true,
      priceValue: true,
      currency: true,
      availability: true,
      checkedAt: true,
    },
  });
  const previousMeasurements = measurements.length
    ? await prisma.competitorCheckMeasurement.findMany({
        where: {
          run: { productId },
          targetType: 'competitor',
          competitorUrl: { in: [...new Set(measurements.map((item) => item.competitorUrl))] },
          checkedAt: { lt: dayStart },
        },
        orderBy: [{ checkedAt: 'desc' }, { id: 'desc' }],
        select: {
          id: true,
          competitorUrl: true,
          status: true,
          priceValue: true,
          currency: true,
          availability: true,
          checkedAt: true,
        },
      })
    : [];

  const generatedAt = new Date();
  const report = buildMarketReport({
    productId,
    date: parsedInput.data.date,
    generatedAt,
    measurements,
    previousMeasurements,
  });
  const saved = await prisma.shopMarketReport.upsert({
    where: { productId_dateKey: { productId, dateKey: parsedInput.data.date } },
    create: {
      productId,
      dateKey: parsedInput.data.date,
      report,
      generatedAt,
    },
    update: { report, generatedAt },
  });
  const feedback = await prisma.shopMarketReportFeedback.findUnique({
    where: { reportId_userId: { reportId: saved.id, userId: access.userId } },
    select: {
      id: true,
      reportId: true,
      isUseful: true,
      reason: true,
      createdAt: true,
      updatedAt: true,
    },
  });

  return NextResponse.json(
    MarketReportCreateResponse.parse({
      report: MarketReport.parse(saved.report),
      reportId: saved.id,
      feedback: feedback
        ? {
            ...feedback,
            createdAt: feedback.createdAt.toISOString(),
            updatedAt: feedback.updatedAt.toISOString(),
          }
        : null,
    }),
  );
}
