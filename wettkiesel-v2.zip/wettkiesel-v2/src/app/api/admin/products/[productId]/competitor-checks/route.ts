// @polsia:user-owned — owner-admin routes for saved competitor check history.
import 'server-only';
import { NextResponse } from 'next/server';
import { toCompetitorCheckRun } from '@/lib/business/competitor-check-wire';
import {
  getPriceSuggestionLimitEffect,
  selectCompetitorPriceSuggestion,
} from '@/lib/business/competitor-price-suggestion';
import { authorizeProductAdmin } from '@/lib/business/product-admin-auth';
import {
  CompetitorCheckResponse,
  LatestCompetitorCheckResponse,
} from '@/lib/contracts/competitor-checks';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

type RouteContext = { params: Promise<{ productId: string }> };

export async function GET(_request: Request, context: RouteContext) {
  const access = await authorizeProductAdmin();
  if (!access.ok) return access.response;

  const { productId } = await context.params;
  const product = await prisma.shopProduct.findFirst({
    where: { id: productId, userId: access.userId },
    select: {
      id: true,
      ownUrl: true,
      competitorUrls: true,
      minPriceCents: true,
      maxPriceCents: true,
    },
  });
  if (!product) return NextResponse.json({ error: 'not_found' }, { status: 404 });

  const storedRuns = await prisma.competitorCheckRun.findMany({
    where: { productId },
    orderBy: { startedAt: 'desc' },
    include: { measurements: { orderBy: { createdAt: 'asc' } } },
  });
  const runs = storedRuns.map(toCompetitorCheckRun);
  const suggestion = selectCompetitorPriceSuggestion({
    competitorUrls: product.competitorUrls,
    minPriceCents: product.minPriceCents,
    maxPriceCents: product.maxPriceCents,
    runs,
  });
  const productPriceSuggestion = suggestion
    ? (() => {
        const limitEffect = getPriceSuggestionLimitEffect(
          suggestion.observation.priceValue,
          product.minPriceCents,
          product.maxPriceCents,
        );
        if (limitEffect === 'minimum') {
          return { ...suggestion, limitEffect, limitPriceCents: product.minPriceCents };
        }
        if (limitEffect === 'maximum') {
          return { ...suggestion, limitEffect, limitPriceCents: product.maxPriceCents };
        }
        return { ...suggestion, limitEffect, limitPriceCents: null };
      })()
    : null;
  return NextResponse.json(
    LatestCompetitorCheckResponse.parse({
      ownUrl: product.ownUrl,
      run: runs[0] ?? null,
      runs,
      priceSuggestion: productPriceSuggestion,
    }),
  );
}

export async function POST(_request: Request, context: RouteContext) {
  const access = await authorizeProductAdmin();
  if (!access.ok) return access.response;

  const { productId } = await context.params;
  const product = await prisma.shopProduct.findFirst({
    where: { id: productId, userId: access.userId },
    select: { id: true, isArchived: true, ownUrl: true, competitorUrls: true },
  });
  if (!product) return NextResponse.json({ error: 'not_found' }, { status: 404 });
  if (product.isArchived) {
    return NextResponse.json({ error: 'product_archived' }, { status: 409 });
  }
  const run = await prisma.competitorCheckRun.create({
    data: {
      productId,
      measurements: {
        create: [
          { targetType: 'own', competitorUrl: product.ownUrl },
          ...product.competitorUrls.map((competitorUrl) => ({
            targetType: 'competitor',
            competitorUrl,
          })),
        ],
      },
    },
    include: { measurements: { orderBy: { createdAt: 'asc' } } },
  });

  return NextResponse.json(CompetitorCheckResponse.parse({ run: toCompetitorCheckRun(run) }), {
    status: 201,
  });
}
