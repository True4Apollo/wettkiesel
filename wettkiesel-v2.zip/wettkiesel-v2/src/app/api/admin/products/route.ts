// @polsia:user-owned
import 'server-only';
import { NextResponse } from 'next/server';
import { authorizeProductAdmin } from '@/lib/business/product-admin-auth';
import { ShopProductInput, ShopProductItem, ShopProductList } from '@/lib/contracts/shop-products';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

function toItem(product: {
  id: string;
  isArchived: boolean;
  name: string;
  ownUrl: string;
  competitorUrls: string[];
  minPriceCents: number;
  maxPriceCents: number;
  createdAt: Date;
  updatedAt: Date;
}) {
  return ShopProductItem.parse({
    id: product.id,
    isArchived: product.isArchived,
    name: product.name,
    ownUrl: product.ownUrl,
    competitorUrls: product.competitorUrls,
    minPrice: product.minPriceCents / 100,
    maxPrice: product.maxPriceCents / 100,
    createdAt: product.createdAt.toISOString(),
    updatedAt: product.updatedAt.toISOString(),
  });
}

function invalidInput(error: {
  flatten: () => { fieldErrors: Record<string, string[] | undefined> };
}) {
  const fieldErrors: Record<string, string> = {};
  for (const [field, messages] of Object.entries(error.flatten().fieldErrors)) {
    const message = messages?.[0];
    if (message) fieldErrors[field] = message;
  }
  return NextResponse.json({ errors: fieldErrors }, { status: 400 });
}

export async function GET(request: Request) {
  const access = await authorizeProductAdmin();
  if (!access.ok) return access.response;

  const status = new URL(request.url).searchParams.get('status');
  const products = await prisma.shopProduct.findMany({
    where: { userId: access.userId, isArchived: status === 'archived' },
    orderBy: { updatedAt: 'desc' },
  });
  return NextResponse.json(ShopProductList.parse({ items: products.map(toItem) }));
}

export async function POST(request: Request) {
  const access = await authorizeProductAdmin();
  if (!access.ok) return access.response;

  const body: unknown = await request.json().catch(() => null);
  const parsed = ShopProductInput.safeParse(body);
  if (!parsed.success) return invalidInput(parsed.error);

  try {
    const product = await prisma.shopProduct.create({
      data: {
        userId: access.userId,
        name: parsed.data.name,
        ownUrl: parsed.data.ownUrl,
        competitorUrls: parsed.data.competitorUrls,
        minPriceCents: Math.round(parsed.data.minPrice * 100),
        maxPriceCents: Math.round(parsed.data.maxPrice * 100),
      },
    });
    return NextResponse.json({ item: toItem(product) }, { status: 201 });
  } catch {
    return NextResponse.json({ error: 'internal_error' }, { status: 500 });
  }
}
