// @polsia:user-owned — Ausschließlich lesender Adminabruf vorhandener Berichtsbewertungen.
import 'server-only';
import { headers } from 'next/headers';
import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { MarketReportFeedbackSummary } from '@/lib/contracts/market-report-feedback-summary';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

const privateHeaders = { 'Cache-Control': 'private, no-store' };

export async function GET() {
  try {
    const session = await auth.api.getSession({ headers: await headers() });
    if (!session) {
      return NextResponse.json(
        { error: 'Nicht angemeldet.' },
        { status: 401, headers: privateHeaders },
      );
    }
    if (session.user.role !== 'admin') {
      return NextResponse.json(
        { error: 'Kein Adminzugriff.' },
        { status: 403, headers: privateHeaders },
      );
    }

    const feedback = await prisma.shopMarketReportFeedback.findMany({
      select: {
        id: true,
        isUseful: true,
        reason: true,
        createdAt: true,
        report: {
          select: {
            dateKey: true,
            product: { select: { name: true } },
          },
        },
      },
      orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
    });

    const summary = {
      helpfulCount: feedback.filter((entry) => entry.isUseful).length,
      notHelpfulCount: feedback.filter((entry) => !entry.isUseful).length,
      reasons: feedback.flatMap((entry) => {
        const reason = entry.reason?.trim();
        if (!reason) return [];

        return [
          {
            feedbackId: entry.id,
            isUseful: entry.isUseful,
            reason,
            reportDate: entry.report.dateKey,
            productName: entry.report.product.name,
            submittedAt: entry.createdAt.toISOString(),
          },
        ];
      }),
    };

    return NextResponse.json(MarketReportFeedbackSummary.parse(summary), {
      headers: privateHeaders,
    });
  } catch {
    return NextResponse.json(
      { error: 'Tagesbericht-Feedback konnte nicht geladen werden.' },
      { status: 500, headers: privateHeaders },
    );
  }
}
