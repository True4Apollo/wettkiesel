// @polsia:user-owned
import 'server-only';
import { NextResponse } from 'next/server';
import { getShopProductOverview } from '@/lib/business/shop-product-overview';
import { ShopProductOverviewList } from '@/lib/contracts/shop-product-overview';
import {
  ShopProductInput,
  ShopProductItem,
  ShopProductResponse,
} from '@/lib/contracts/shop-products';
import { prisma } from '@/lib/db';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(request);
  } catch (response) {
    return response as Response;
  }

  const items = await getShopProductOverview(user.id);
  return NextResponse.json(ShopProductOverviewList.parse({ items }));
}

export async function POST(request: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(request);
  } catch (response) {
    return response as Response;
  }

  const body: unknown = await request.json().catch(() => null);
  const parsed = ShopProductInput.safeParse(body);
  if (!parsed.success) {
    const errors: Record<string, string> = {};
    for (const [field, messages] of Object.entries(parsed.error.flatten().fieldErrors)) {
      const message = messages?.[0];
      if (message) errors[field] = message;
    }
    return NextResponse.json({ errors }, { status: 400 });
  }

  try {
    const product = await prisma.shopProduct.create({
      data: {
        userId: user.id,
        name: parsed.data.name,
        ownUrl: parsed.data.ownUrl,
        competitorUrls: parsed.data.competitorUrls,
        minPriceCents: Math.round(parsed.data.minPrice * 100),
        maxPriceCents: Math.round(parsed.data.maxPrice * 100),
      },
    });
    const item = ShopProductItem.parse({
      id: product.id,
      isArchived: product.isArchived,
      name: product.name,
      ownUrl: product.ownUrl,
      competitorUrls: product.competitorUrls,
      minPrice: product.minPriceCents / 100,
      maxPrice: product.maxPriceCents / 100,
      createdAt: product.createdAt.toISOString(),
      updatedAt: product.updatedAt.toISOString(),
    });
    return NextResponse.json(ShopProductResponse.parse({ item }), { status: 201 });
  } catch {
    return NextResponse.json({ error: 'internal_error' }, { status: 500 });
  }
}
