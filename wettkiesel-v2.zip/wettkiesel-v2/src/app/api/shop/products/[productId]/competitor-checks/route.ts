// @polsia:user-owned — owner-scoped manual competitor check history.
import 'server-only';
import { NextResponse } from 'next/server';
import { toCompetitorCheckRun } from '@/lib/business/competitor-check-wire';
import {
  getPriceSuggestionLimitEffect,
  selectCompetitorPriceSuggestion,
} from '@/lib/business/competitor-price-suggestion';
import {
  CompetitorCheckResponse,
  LatestCompetitorCheckResponse,
} from '@/lib/contracts/competitor-checks';
import { prisma } from '@/lib/db';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

type RouteContext = { params: Promise<{ productId: string }> };

export async function GET(request: Request, context: RouteContext) {
  let user: SessionUser;
  try {
    user = await requireAuth(request);
  } catch (response) {
    return response as Response;
  }

  const { productId } = await context.params;
  const product = await prisma.shopProduct.findFirst({
    where: { id: productId, userId: user.id, isArchived: false },
    select: {
      id: true,
      ownUrl: true,
      competitorUrls: true,
      minPriceCents: true,
      maxPriceCents: true,
    },
  });
  if (!product) return NextResponse.json({ error: 'not_found' }, { status: 404 });

  const storedRuns = await prisma.competitorCheckRun.findMany({
    where: { productId: product.id },
    orderBy: { startedAt: 'desc' },
    include: { measurements: { orderBy: { createdAt: 'asc' } } },
  });
  const runs = storedRuns.map(toCompetitorCheckRun);
  const suggestion = selectCompetitorPriceSuggestion({
    competitorUrls: product.competitorUrls,
    minPriceCents: product.minPriceCents,
    maxPriceCents: product.maxPriceCents,
    runs,
  });
  const priceSuggestion = suggestion
    ? (() => {
        const limitEffect = getPriceSuggestionLimitEffect(
          suggestion.observation.priceValue,
          product.minPriceCents,
          product.maxPriceCents,
        );
        if (limitEffect === 'minimum') {
          return { ...suggestion, limitEffect, limitPriceCents: product.minPriceCents };
        }
        if (limitEffect === 'maximum') {
          return { ...suggestion, limitEffect, limitPriceCents: product.maxPriceCents };
        }
        return { ...suggestion, limitEffect, limitPriceCents: null };
      })()
    : null;

  return NextResponse.json(
    LatestCompetitorCheckResponse.parse({
      ownUrl: product.ownUrl,
      run: runs[0] ?? null,
      runs,
      priceSuggestion,
    }),
  );
}

export async function POST(request: Request, context: RouteContext) {
  let user: SessionUser;
  try {
    user = await requireAuth(request);
  } catch (response) {
    return response as Response;
  }

  const { productId } = await context.params;
  const product = await prisma.shopProduct.findFirst({
    where: { id: productId, userId: user.id },
    select: { id: true, isArchived: true, ownUrl: true, competitorUrls: true },
  });
  if (!product) return NextResponse.json({ error: 'not_found' }, { status: 404 });
  if (product.isArchived) {
    return NextResponse.json({ error: 'product_archived' }, { status: 409 });
  }

  const run = await prisma.competitorCheckRun.create({
    data: {
      productId: product.id,
      measurements: {
        create: [
          { targetType: 'own', competitorUrl: product.ownUrl },
          ...product.competitorUrls.map((competitorUrl) => ({
            targetType: 'competitor',
            competitorUrl,
          })),
        ],
      },
    },
    include: { measurements: { orderBy: { createdAt: 'asc' } } },
  });

  return NextResponse.json(CompetitorCheckResponse.parse({ run: toCompetitorCheckRun(run) }), {
    status: 201,
  });
}
