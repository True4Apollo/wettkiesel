// @polsia:user-owned — returns only a product owned by the signed-in user.
import 'server-only';
import { NextResponse } from 'next/server';
import { getShopProductOverviewItem } from '@/lib/business/shop-product-overview';
import { ShopProductOverviewResponse } from '@/lib/contracts/shop-product-overview';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

export async function GET(
  request: Request,
  { params }: { params: Promise<{ productId: string }> },
) {
  let user: SessionUser;
  try {
    user = await requireAuth(request);
  } catch (response) {
    return response as Response;
  }

  const { productId } = await params;
  const item = await getShopProductOverviewItem(user.id, productId);
  if (!item) {
    return NextResponse.json({ error: 'not_found' }, { status: 404 });
  }

  return NextResponse.json(ShopProductOverviewResponse.parse({ item }));
}
