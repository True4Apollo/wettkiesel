// @polsia:user-owned — owner-scoped processing of one saved competitor measurement.
import 'server-only';
import { NextResponse } from 'next/server';
import { persistCompetitorMeasurement } from '@/lib/business/competitor-check-persistence';
import { toCompetitorMeasurement } from '@/lib/business/competitor-check-wire';
import { readCompetitorPage } from '@/lib/business/competitor-page-reader';
import { CompetitorMeasurementResponse } from '@/lib/contracts/competitor-checks';
import { prisma } from '@/lib/db';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

type RouteContext = { params: Promise<{ productId: string; measurementId: string }> };
const STALE_PROCESSING_MS = 120_000;
const FINISHED_STATUSES = [
  'not_checked',
  'observed',
  'partial',
  'no_data',
  'inconsistent',
  'incomplete',
  'unreadable',
  'invalid_target',
  'error',
];

export async function POST(request: Request, context: RouteContext) {
  let user: SessionUser;
  try {
    user = await requireAuth(request);
  } catch (response) {
    return response as Response;
  }

  const { productId, measurementId } = await context.params;
  const measurement = await prisma.competitorCheckMeasurement.findFirst({
    where: {
      id: measurementId,
      run: { productId, product: { userId: user.id } },
    },
    include: {
      run: { select: { id: true, product: { select: { name: true, isArchived: true } } } },
    },
  });
  if (!measurement) return NextResponse.json({ error: 'not_found' }, { status: 404 });
  if (measurement.run.product.isArchived) {
    return NextResponse.json({ error: 'product_archived' }, { status: 409 });
  }

  if (FINISHED_STATUSES.includes(measurement.status)) {
    const run = await prisma.competitorCheckRun.findUnique({ where: { id: measurement.run.id } });
    if (!run) return NextResponse.json({ error: 'not_found' }, { status: 404 });
    return NextResponse.json(
      CompetitorMeasurementResponse.parse({
        measurement: toCompetitorMeasurement(measurement),
        runStatus: run.status,
      }),
    );
  }

  const attemptedAt = new Date();
  const staleBefore = new Date(Date.now() - STALE_PROCESSING_MS);
  const claim = await prisma.competitorCheckMeasurement.updateMany({
    where: {
      id: measurement.id,
      ...(measurement.status === 'pending'
        ? { status: 'pending' }
        : {
            status: 'processing',
            OR: [{ processingAt: null }, { processingAt: { lte: staleBefore } }],
          }),
    },
    data: { status: 'processing', processingAt: attemptedAt, attemptedAt },
  });
  if (claim.count === 0) {
    return NextResponse.json({ error: 'already_processing' }, { status: 409 });
  }

  const result = await readCompetitorPage({
    url: measurement.competitorUrl,
    productName: measurement.run.product.name,
    targetType: measurement.targetType === 'own' ? 'own' : 'competitor',
  });
  const saved = await persistCompetitorMeasurement({
    measurementId: measurement.id,
    runId: measurement.run.id,
    attemptedAt,
    result,
  });

  return NextResponse.json(
    CompetitorMeasurementResponse.parse({
      measurement: toCompetitorMeasurement(saved.measurement),
      runStatus: saved.runStatus,
    }),
  );
}
