// @polsia:user-owned — signed-in shop owners can read their own daily movements.
import 'server-only';
import { NextResponse } from 'next/server';
import { getShopDailyMarketReport } from '@/lib/business/shop-daily-market-report';
import { MarketReportDate, ShopDailyMarketReport } from '@/lib/contracts/market-reports';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(request);
  } catch (response) {
    return response as Response;
  }

  const requestedDate = new URL(request.url).searchParams.get('date');
  const date = requestedDate ?? new Date().toISOString().slice(0, 10);
  const parsedDate = MarketReportDate.safeParse(date);
  if (!parsedDate.success) {
    return NextResponse.json({ error: 'invalid_date' }, { status: 400 });
  }

  const report = await getShopDailyMarketReport(user.id, parsedDate.data);
  return NextResponse.json(ShopDailyMarketReport.parse(report));
}
