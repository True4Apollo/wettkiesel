// Öffentliche Startseite von Wettkiesel.

import { ArrowDown, ArrowRight, Check, Database, Eye, Lightbulb, ShieldCheck } from 'lucide-react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { BrandMark } from '@/components/custom/brand-mark';
import { MotionKitProvider, Reveal } from '@/components/custom/motion-kit';
import { Button } from '@/components/ui/button';
import {
  founder,
  founderDiscount,
  pilotOffer,
  pricingIsProposal,
  pricingTiers,
} from '@/lib/wettkiesel-config';

export const metadata: Metadata = {
  title: {
    absolute: 'Preisüberwachung für kleine Onlineshops – Wettbewerberpreise im Blick | Wettkiesel',
  },
  description:
    'Wettkiesel beobachtet täglich Preise und Verfügbarkeit deiner Wettbewerber und fasst Änderungen in einem verständlichen Tagesbericht zusammen. 14 Tage kostenlos testen, ohne Zugangsdaten.',
  alternates: { canonical: '/' },
};

const availableFeatures = [
  {
    icon: Eye,
    number: '01',
    title: 'Preise & Verfügbarkeit täglich geprüft',
    text: 'Wettkiesel prüft die öffentlichen Produktseiten deiner wichtigsten Wettbewerber – du musst nicht mehr selbst durch zehn Tabs klicken.',
  },
  {
    icon: Database,
    number: '02',
    title: 'Verlauf mit Zeitpunkt und Beleg',
    text: 'Jede Messung wird gespeichert. Du siehst, ob eine Änderung wirklich neu ist – und wann zuletzt geprüft wurde. Fehlende Daten werden als solche markiert.',
  },
  {
    icon: Lightbulb,
    number: '03',
    title: 'Tagesbericht & Preisvorschläge',
    text: 'Ein klarer Bericht zeigt, was sich bewegt hat. Unverbindliche Vorschläge bleiben innerhalb deiner Preisgrenzen – du entscheidest.',
  },
];

const roadmap = [
  'E-Mail-Hinweise bei wichtigen Preis- oder Verfügbarkeitsänderungen',
  'Automatische Preisanpassung innerhalb fester Grenzen – zuerst gemeinsam mit Pilotpartnern',
];

const pilotSteps = [
  {
    number: '01',
    title: 'Shop & Wettbewerber nennen',
    text: 'Shop-URL, Shopsystem und – wenn du magst – 3 bis 5 Wettbewerber. Keine Zugangsdaten.',
  },
  {
    number: '02',
    title: 'Wir richten es ein',
    text: 'Wir ordnen bis zu 25 deiner Produkte den passenden Wettbewerberangeboten zu.',
  },
  {
    number: '03',
    title: '14 Tage Tagesberichte',
    text: 'Du bekommst echte Berichte. Danach entscheidest du, ob es dir das Geld wert ist.',
  },
];

const faqItems = [
  {
    question: 'Was beobachtet Wettkiesel heute?',
    answer:
      'Öffentlich erreichbare Wettbewerberpreise und Produktverfügbarkeiten. Die Messungen werden gespeichert, damit Preisbewegungen nachvollziehbar bleiben.',
  },
  {
    question: 'Ändert Wettkiesel automatisch Preise in meinem Shop?',
    answer:
      'Nein, heute nicht. Automatische Anpassungen innerhalb fester Grenzen sind geplant und werden zuerst mit Pilotpartnern umgesetzt.',
  },
  {
    question: 'Brauche ich Zugangsdaten zu meinem Shop?',
    answer:
      'Nein. Für die Beobachtung reichen öffentliche Produktseiten. Bitte teile im Formular keine Passwörter oder API-Schlüssel.',
  },
  {
    question: 'Was kostet Wettkiesel nach dem Pilot?',
    answer:
      'Die Tarife findest du oben im Abschnitt Preise. Der Pilot ist kostenlos und endet automatisch – ohne Abo-Falle.',
  },
];

function MarketPreview() {
  return (
    <figure className="wk-preview-shell" aria-label="Illustrative Marktübersicht mit Beispieldaten">
      <div className="wk-preview-orbit wk-preview-orbit-one" aria-hidden="true" />
      <div className="wk-preview-orbit wk-preview-orbit-two" aria-hidden="true" />
      <div className="wk-preview-card">
        <div className="wk-preview-header">
          <div className="wk-preview-brand">
            <BrandMark small />
            <span>Wettkiesel · Marktübersicht</span>
          </div>
          <span className="wk-example-badge">Beispieldaten</span>
        </div>
        <div className="wk-preview-title-row">
          <div>
            <span className="wk-preview-kicker">ILLUSTRATIVE VORSCHAU</span>
            <h2>Marktbewegungen auf einen Blick</h2>
          </div>
          <span className="wk-preview-date">Beispielansicht</span>
        </div>
        <div className="wk-preview-stats">
          <div>
            <span>Beobachtete Angebote</span>
            <strong className="wk-preview-stat-value">24</strong>
            <small>Beispielwert · nicht live</small>
          </div>
          <div>
            <span>Neue Bewegungen</span>
            <strong className="wk-preview-stat-value">3</strong>
            <small>Beispielwert · nicht live</small>
          </div>
        </div>
        <div className="wk-preview-list-label">BEISPIELHAFTE MESSUNGEN</div>
        <div className="wk-preview-list">
          <div className="wk-preview-row">
            <span className="wk-preview-signal wk-preview-signal-down">−</span>
            <span>
              <strong className="wk-preview-row-title">Beispielprodukt A</strong>
              <small className="wk-preview-row-detail">Beispielshop · Preisbewegung</small>
            </span>
            <b>−6 %</b>
          </div>
          <div className="wk-preview-row">
            <span className="wk-preview-signal wk-preview-signal-up">+</span>
            <span>
              <strong className="wk-preview-row-title">Beispielprodukt B</strong>
              <small className="wk-preview-row-detail">Beispielshop · wieder verfügbar</small>
            </span>
            <b>Auf Lager</b>
          </div>
          <div className="wk-preview-row">
            <span className="wk-preview-signal wk-preview-signal-neutral">→</span>
            <span>
              <strong className="wk-preview-row-title">Beispielprodukt C</strong>
              <small className="wk-preview-row-detail">Beispielshop · Vorschlag begrenzt</small>
            </span>
            <b>Hinweis</b>
          </div>
        </div>
        <div className="wk-preview-foot">
          <span>
            <ShieldCheck size={14} aria-hidden="true" /> Keine Echtzeit- oder Kundendaten
          </span>
          <span>VORSCHAU</span>
        </div>
      </div>
    </figure>
  );
}

export default function HomePage() {
  return (
    <MotionKitProvider>
      <main className="wk-page">
        <header className="wk-header" id="start">
          <a href="#start" className="wk-brand" aria-label="Wettkiesel – zur Startseite">
            <BrandMark />
            <span>
              wettkiesel<span className="wk-brand-period">.</span>
            </span>
          </a>
          <nav className="wk-nav" aria-label="Hauptnavigation">
            <a href="#umfang">Funktionen</a>
            <a href="#preise">Preise</a>
            <Link href="/beispielbericht">Beispielbericht</Link>
            <a href="#fragen">FAQ</a>
            <Link href="/login">Login</Link>
          </nav>
          <Button asChild className="wk-header-cta">
            <Link href="/pilot">
              Kostenlos testen <ArrowRight size={15} aria-hidden="true" />
            </Link>
          </Button>
          <Button asChild variant="outline" className="wk-mobile-cta">
            <Link href="/pilot" aria-label="Kostenlos testen">
              Testen <ArrowRight size={14} aria-hidden="true" />
            </Link>
          </Button>
        </header>

        <section className="wk-hero" aria-labelledby="hero-title">
          <Reveal trigger="load" variant="fade-up" className="wk-hero-copy">
            <p className="wk-eyebrow">
              <span aria-hidden="true" /> PREISÜBERWACHUNG FÜR KLEINE ONLINESHOPS
            </p>
            <h1 id="hero-title">
              Wisse jeden Morgen,
              <br />
              <span>was deine Konkurrenz</span>
              <br />
              <strong>an Preisen geändert hat.</strong>
            </h1>
            <p className="wk-hero-lede">
              Wettkiesel beobachtet die Produktseiten deiner wichtigsten Wettbewerber und fasst
              Preis- und Verfügbarkeitsänderungen in einem klaren Tagesbericht zusammen – mit
              Verlauf, Zeitstempel und Beleg. Du entscheidest über deine Preise.
            </p>
            <div className="wk-hero-actions">
              <Button asChild className="wk-button wk-button-dark">
                <Link href="/pilot">
                  14 Tage kostenlos testen <ArrowRight size={16} aria-hidden="true" />
                </Link>
              </Button>
              <Link href="/beispielbericht" className="wk-text-link">
                Beispielbericht ansehen <ArrowDown size={15} aria-hidden="true" />
              </Link>
            </div>
            <p className="wk-hero-note">
              <span aria-hidden="true">
                <Check size={12} />
              </span>
              Keine Zugangsdaten nötig · Pilot endet automatisch · Begrenzt auf 10 Shops
            </p>
          </Reveal>
          <Reveal trigger="load" variant="scale" delay={0.08} className="wk-hero-preview">
            <MarketPreview />
          </Reveal>
        </section>

        <section className="wk-section wk-available" id="umfang" aria-labelledby="umfang-title">
          <Reveal className="wk-section-heading">
            <div>
              <p className="wk-eyebrow">
                <span aria-hidden="true" /> WAS DU HEUTE BEKOMMST
              </p>
              <h2 id="umfang-title">
                Weniger Tabs.
                <br />
                <span>Bessere Preisentscheidungen.</span>
              </h2>
            </div>
            <p>
              Statt Wettbewerberseiten manuell zu prüfen, siehst du auf einen Blick, was sich
              geändert hat – und was nicht.
            </p>
          </Reveal>
          <div className="wk-feature-grid">
            {availableFeatures.map(({ icon: Icon, number, title, text }) => (
              <Reveal as="article" className="wk-feature-card" key={number}>
                <div className="wk-feature-top">
                  <span className="wk-feature-icon">
                    <Icon size={19} strokeWidth={1.8} aria-hidden="true" />
                  </span>
                  <span className="wk-feature-number">{number}</span>
                </div>
                <h3>{title}</h3>
                <p>{text}</p>
              </Reveal>
            ))}
          </div>

          <div className="wk-roadmap-box" id="roadmap">
            <div>
              <p className="wk-roadmap-label wk-roadmap-label-now">HEUTE VERFÜGBAR</p>
              <ul>
                <li>
                  <Check size={14} aria-hidden="true" /> Preis- & Verfügbarkeitsbeobachtung
                </li>
                <li>
                  <Check size={14} aria-hidden="true" /> Messverlauf & Tagesbericht
                </li>
                <li>
                  <Check size={14} aria-hidden="true" /> Unverbindliche Preisvorschläge
                </li>
              </ul>
            </div>
            <div>
              <p className="wk-roadmap-label">ROADMAP · NOCH NICHT VERFÜGBAR</p>
              <ul>
                {roadmap.map((item) => (
                  <li key={item}>
                    <span aria-hidden="true">→</span> {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        <section className="wk-section wk-pilot-path" id="pilot" aria-labelledby="pilot-title">
          <Reveal className="wk-section-heading wk-pilot-heading">
            <div>
              <p className="wk-eyebrow">
                <span aria-hidden="true" /> SO LÄUFT DER PILOT
              </p>
              <h2 id="pilot-title">
                In drei Schritten
                <br />
                <span>zum ersten Tagesbericht.</span>
              </h2>
            </div>
            <p>{pilotOffer}</p>
          </Reveal>
          <div className="wk-steps">
            {pilotSteps.map((step) => (
              <Reveal as="article" className="wk-step" key={step.number}>
                <span className="wk-step-number">{step.number}</span>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        <section className="wk-section" id="preise" aria-labelledby="preise-title">
          <Reveal className="wk-section-heading">
            <div>
              <p className="wk-eyebrow">
                <span aria-hidden="true" /> PREISE
              </p>
              <h2 id="preise-title">
                Einfach und monatlich kündbar.
                <br />
                <span>Erst testen, dann entscheiden.</span>
              </h2>
            </div>
            <p>
              {pilotOffer}
              {pricingIsProposal ? ' Die Tarife sind ein vorläufiger Vorschlag.' : ''}
            </p>
          </Reveal>
          <div className="wk-pricing-grid">
            {pricingTiers.map((tier) => (
              <article
                key={tier.name}
                className={`wk-price-card${'highlighted' in tier && tier.highlighted ? ' wk-price-card-highlight' : ''}`}
              >
                <h3>{tier.name}</h3>
                <p className="wk-price-tagline">{tier.tagline}</p>
                <p className="wk-price-amount">
                  {tier.priceEur} €<small> / Monat</small>
                </p>
                <ul>
                  {tier.features.map((feature) => (
                    <li key={feature}>
                      <Check size={14} aria-hidden="true" /> {feature}
                    </li>
                  ))}
                </ul>
                <Button asChild className="wk-button wk-button-dark">
                  <Link href={`/pilot?tarif=${tier.name.toLowerCase()}`}>Kostenlos testen</Link>
                </Button>
              </article>
            ))}
          </div>
          {founderDiscount.enabled ? <p className="wk-price-note">{founderDiscount.text}</p> : null}
          {pricingIsProposal ? (
            <p className="wk-price-note">
              Hinweis: Preise sind ein Vorschlag (Stand Pilotphase) und können sich noch ändern.
            </p>
          ) : null}
        </section>

        <section className="wk-section wk-founder" aria-labelledby="founder-title">
          <div className="wk-founder-card">
            {founder.photo ? (
              // biome-ignore lint/performance/noImgElement: einfaches statisches Foto
              <img src={founder.photo} alt={founder.name} className="wk-founder-photo" />
            ) : (
              <div className="wk-founder-photo wk-founder-photo-empty" aria-hidden="true">
                <ShieldCheck size={28} />
              </div>
            )}
            <div>
              <p className="wk-eyebrow">
                <span aria-hidden="true" /> WER DAHINTER STEHT
              </p>
              <h2 id="founder-title">{founder.name}</h2>
              <p className="wk-founder-role">{founder.role}</p>
              <p>{founder.text}</p>
            </div>
          </div>
        </section>

        <section className="wk-faq" id="fragen" aria-labelledby="fragen-title">
          <div className="wk-faq-intro">
            <p className="wk-eyebrow">
              <span aria-hidden="true" /> HÄUFIGE FRAGEN
            </p>
            <h2 id="fragen-title">
              Kurz und
              <br />
              <span>ehrlich beantwortet.</span>
            </h2>
            <Link href="/faq" className="wk-faq-link">
              Alle FAQ ansehen <ArrowRight size={14} aria-hidden="true" />
            </Link>
          </div>
          <div className="wk-faq-list">
            {faqItems.map((item) => (
              <details className="wk-faq-item" key={item.question}>
                <summary>
                  <span>{item.question}</span>
                  <span className="wk-faq-plus" aria-hidden="true">
                    +
                  </span>
                </summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </section>

        <footer className="wk-footer">
          <div className="wk-footer-main">
            <Link href="/" className="wk-brand wk-footer-brand">
              <BrandMark small />
              <span>
                wettkiesel<span className="wk-brand-period">.</span>
              </span>
            </Link>
            <p>Preisüberwachung für kleine Onlineshops.</p>
          </div>
          <div className="wk-footer-links">
            <Link href="/pilot">Kostenlos testen</Link>
            <Link href="/beispielbericht">Beispielbericht</Link>
            <Link href="/faq">FAQ</Link>
            <Link href="/impressum">Impressum</Link>
            <Link href="/datenschutz">Datenschutz</Link>
          </div>
        </footer>
      </main>
    </MotionKitProvider>
  );
}
