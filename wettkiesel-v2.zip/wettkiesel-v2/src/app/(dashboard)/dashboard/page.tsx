// @polsia:user-owned
'use client';

import { PackageSearch, ShieldCheck } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { useIsAdmin } from '@/lib/auth-client';

export default function DashboardPage() {
  const isAdmin = useIsAdmin();

  return (
    <div className="grid gap-6">
      <header className="grid gap-2">
        <p className="text-sm font-medium uppercase tracking-[0.12em] text-primary">Wettkiesel</p>
        <h1 className="text-3xl font-semibold tracking-tight text-foreground">Dein Konto</h1>
        <p className="max-w-2xl text-sm leading-6 text-muted-foreground">
          Hier siehst du den Berechtigungsumfang deines Wettkiesel-Kontos.
        </p>
      </header>

      <section className="grid gap-4 md:grid-cols-[minmax(0,1fr)_minmax(260px,0.7fr)]">
        <div className="grid content-start gap-3 rounded-xl border border-border bg-card p-5 sm:p-6">
          <div className="flex items-center gap-3">
            <ShieldCheck aria-hidden="true" className="size-5 text-primary" />
            <h2 className="font-semibold text-card-foreground">
              {isAdmin ? 'Owner-Zugang' : 'Kundenzugang'}
            </h2>
          </div>
          <p className="text-sm leading-6 text-muted-foreground">
            {isAdmin
              ? 'Dieses bestätigte Konto kann die eigene Produktübersicht und den geschützten Owner-Shopbereich öffnen.'
              : 'Dieses Konto kann die geschützte Übersicht der eigenen Produkte öffnen. Die Shopverwaltung bleibt dem bestätigten Inhaberkonto vorbehalten.'}
          </p>
          <div className="mt-2 flex flex-wrap gap-2">
            <Button asChild className="w-fit">
              <Link href="/dashboard/products">
                <PackageSearch aria-hidden="true" className="size-4" />
                Meine Produkte ansehen
              </Link>
            </Button>
            {isAdmin ? (
              <Button asChild variant="outline" className="w-fit">
                <Link href="/admin">Shopbereich öffnen</Link>
              </Button>
            ) : null}
          </div>
        </div>

        <div className="grid content-start gap-2 rounded-xl border border-border bg-secondary/60 p-5 sm:p-6">
          <h2 className="font-semibold text-card-foreground">Produkte sind keine Voraussetzung</h2>
          <p className="text-sm leading-6 text-muted-foreground">
            Ein Konto lässt sich auch dann anlegen und verwenden, wenn noch keine Produktdaten
            vorhanden sind.
          </p>
        </div>
      </section>
    </div>
  );
}
