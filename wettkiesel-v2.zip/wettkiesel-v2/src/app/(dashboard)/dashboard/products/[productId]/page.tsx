// @polsia:user-owned
import { ShopProductDetail } from '@/components/custom/dashboard/shop-product-detail';

export const metadata = {
  title: 'Produktdetails',
  description: 'Gespeicherte Wettbewerbermessungen für dein Produkt ansehen.',
};

export default async function DashboardProductDetailPage({
  params,
}: {
  params: Promise<{ productId: string }>;
}) {
  const { productId } = await params;
  return <ShopProductDetail productId={productId} />;
}
