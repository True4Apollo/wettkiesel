// @polsia:user-owned
import { ShopProductOverview } from '@/components/custom/dashboard/shop-product-overview';

export const metadata = {
  title: 'Meine Produkte',
  description: 'Produkte und gespeicherte Prüfergebnisse im Wettkiesel-Konto ansehen.',
};

export default function DashboardProductsPage() {
  return <ShopProductOverview />;
}
