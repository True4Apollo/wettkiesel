// @polsia:user-owned
import { ShopProductForm } from '@/components/custom/admin/shop-product-form';

export const metadata = {
  title: 'Erstes Produkt anlegen',
  description: 'Produktseite und Preisgrenzen für dein Konto speichern.',
};

export default function NewShopProductPage() {
  return <ShopProductForm createAsShopUser />;
}
