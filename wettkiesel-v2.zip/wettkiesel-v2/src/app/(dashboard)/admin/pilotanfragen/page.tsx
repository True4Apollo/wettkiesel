// @polsia:user-owned
import type { Metadata } from 'next';
import { PilotRequests } from '@/components/custom/dashboard/pilot-requests';

export const metadata: Metadata = {
  title: 'Pilotanfragen',
  description:
    'Eingegangene Antworten zur unverbindlichen Zahlungsbereitschaft im Wettkiesel-Pilot.',
};

export default function PilotRequestsPage() {
  return <PilotRequests />;
}
