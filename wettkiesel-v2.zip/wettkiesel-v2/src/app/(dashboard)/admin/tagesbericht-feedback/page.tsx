// @polsia:user-owned — Adminansicht gespeicherter Bewertungen zu Marktberichten.
import type { Metadata } from 'next';
import { MarketReportFeedbackSummary } from '@/components/custom/admin/market-report-feedback-summary';

export const metadata: Metadata = {
  title: 'Tagesbericht-Feedback',
  description: 'Übersicht der gespeicherten Nützlichkeitsbewertungen zu Marktberichten.',
};

export default function AdminMarketReportFeedbackPage() {
  return (
    <div className="mx-auto grid w-full max-w-5xl gap-6">
      <header className="grid gap-2">
        <p className="text-sm font-medium uppercase tracking-[0.12em] text-primary">
          Owner-Shopbereich
        </p>
        <h1 className="text-3xl font-semibold tracking-tight text-foreground">
          Tagesbericht-Feedback
        </h1>
        <p className="max-w-2xl text-sm leading-6 text-muted-foreground">
          Verteilung und optionale Gründe aus bereits gespeicherten Bewertungen zu Marktberichten.
        </p>
      </header>
      <MarketReportFeedbackSummary />
    </div>
  );
}
