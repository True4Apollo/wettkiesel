// @polsia:user-owned
import { ShopProductForm } from '@/components/custom/admin/shop-product-form';

export const metadata = {
  title: 'Erstes Produkt anlegen',
  description: 'Produktseite, Wettbewerber und Preisgrenzen speichern.',
};

export default function NewAdminProductPage() {
  return <ShopProductForm />;
}
