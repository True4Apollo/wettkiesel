// @polsia:user-owned
import { ShopProductForm } from '@/components/custom/admin/shop-product-form';

export const metadata = {
  title: 'Produkt bearbeiten',
  description: 'Produktangaben und Preisgrenzen aktualisieren.',
};

export default async function EditAdminProductPage({
  params,
}: {
  params: Promise<{ productId: string }>;
}) {
  const { productId } = await params;
  return <ShopProductForm productId={productId} />;
}
