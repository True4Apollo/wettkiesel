// @polsia:user-owned
import { ShopProductList } from '@/components/custom/admin/shop-product-list';

export const metadata = {
  title: 'Produkte verwalten',
  description: 'Produkte und Preisgrenzen für Wettkiesel verwalten.',
};

export default function AdminProductsPage() {
  return <ShopProductList />;
}
