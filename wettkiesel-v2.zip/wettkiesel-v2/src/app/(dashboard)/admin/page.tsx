// @polsia:user-owned
import { CircleSlash2, PackageSearch, ShieldCheck, Store } from 'lucide-react';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

export default function AdminPage() {
  return (
    <div className="grid gap-6">
      <header className="grid gap-2">
        <p className="text-sm font-medium uppercase tracking-[0.12em] text-primary">
          Owner-Shopbereich
        </p>
        <h1 className="text-3xl font-semibold tracking-tight text-foreground">Shopübersicht</h1>
        <p className="max-w-2xl text-sm leading-6 text-muted-foreground">
          Verwalte Produkte und Preisgrenzen im geschützten Wettkiesel-Shopbereich.
        </p>
      </header>

      <section aria-label="Shopstatus" className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        <Card className="border-border/70 shadow-sm">
          <CardHeader className="flex flex-row items-start justify-between gap-4 space-y-0">
            <div className="grid gap-1">
              <CardTitle className="text-base">Owner-Zugang</CardTitle>
              <CardDescription>Bestätigtes Inhaberkonto</CardDescription>
            </div>
            <ShieldCheck aria-hidden="true" className="size-5 text-primary" />
          </CardHeader>
          <CardContent>
            <p className="font-medium text-foreground">Aktiv</p>
            <p className="mt-2 text-sm leading-6 text-muted-foreground">
              Kundenkonten erhalten keinen Zugriff auf diesen Bereich.
            </p>
          </CardContent>
        </Card>

        <Card className="border-border/70 shadow-sm">
          <CardHeader className="flex flex-row items-start justify-between gap-4 space-y-0">
            <div className="grid gap-1">
              <CardTitle className="text-base">Produktverwaltung</CardTitle>
              <CardDescription>Interne Verwaltung ist verfügbar</CardDescription>
            </div>
            <Store aria-hidden="true" className="size-5 text-primary" />
          </CardHeader>
          <CardContent>
            <p className="font-medium text-foreground">Verfügbar</p>
            <p className="mt-2 text-sm leading-6 text-muted-foreground">
              Produktdaten und Preisgrenzen lassen sich intern pflegen. Eine Shopplattform ist nicht
              verbunden.
            </p>
          </CardContent>
        </Card>

        <Card className="border-border/70 shadow-sm md:col-span-2 xl:col-span-1">
          <CardHeader className="flex flex-row items-start justify-between gap-4 space-y-0">
            <div className="grid gap-1">
              <CardTitle className="text-base">Automatische Preisänderungen</CardTitle>
              <CardDescription>Einrichtung nicht abgeschlossen</CardDescription>
            </div>
            <CircleSlash2 aria-hidden="true" className="size-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="font-semibold text-foreground">Deaktiviert</p>
            <dl className="mt-3 grid gap-2 text-sm">
              <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between sm:gap-3">
                <dt className="text-muted-foreground">Shopplattform</dt>
                <dd>
                  <Badge variant="outline">Nicht verbunden</Badge>
                </dd>
              </div>
              <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between sm:gap-3">
                <dt className="text-muted-foreground">Betreiber-API-Zugangsdaten</dt>
                <dd>
                  <Badge variant="outline">Nicht hinterlegt</Badge>
                </dd>
              </div>
            </dl>
            <p className="mt-3 text-sm leading-6 text-muted-foreground">
              Preisgrenzen bleiben interne Angaben. Ohne beide Voraussetzungen werden Shoppreise
              nicht geändert; hier gibt es keine Verbindungs- oder Änderungsaktion.
            </p>
          </CardContent>
        </Card>
      </section>

      <section
        aria-labelledby="setup-heading"
        className="rounded-xl border border-border bg-card p-5 sm:p-6"
      >
        <div className="flex items-start gap-3">
          <PackageSearch aria-hidden="true" className="mt-0.5 size-5 shrink-0 text-primary" />
          <div className="grid gap-2">
            <h2 id="setup-heading" className="font-semibold text-card-foreground">
              Produktverwaltung
            </h2>
            <p className="max-w-2xl text-sm leading-6 text-muted-foreground">
              Ein Produkt lässt sich direkt hier anlegen, später wieder öffnen und bearbeiten.
            </p>
            <p className="text-sm font-medium text-foreground">
              Mindest- und Höchstpreise kannst du unabhängig davon jederzeit anpassen.
            </p>
            <Button asChild className="mt-2 w-fit">
              <Link href="/admin/products">Produkte verwalten</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
