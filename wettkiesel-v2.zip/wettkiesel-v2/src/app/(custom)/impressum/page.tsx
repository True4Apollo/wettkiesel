import type { Metadata } from 'next';
import { legal } from '@/lib/wettkiesel-config';

export const metadata: Metadata = {
  title: 'Impressum',
  description: 'Impressum von Wettkiesel – Angaben gemäß § 5 DDG.',
  alternates: { canonical: '/impressum' },
};

export default function ImpressumPage() {
  return (
    <main className="wk-legal">
      <h1>Impressum</h1>
      <p className="wk-placeholder-note">
        <strong>Entwurf:</strong> Alle Angaben in eckigen Klammern sind Platzhalter und müssen in
        <code> src/lib/wettkiesel-config.ts</code> durch echte Daten ersetzt werden. Bitte rechtlich
        prüfen lassen.
      </p>
      <h2>Angaben gemäß § 5 DDG</h2>
      <p>
        {legal.name}
        <br />
        {legal.street}
        <br />
        {legal.city}
        <br />
        {legal.country}
      </p>
      <h2>Kontakt</h2>
      <p>
        E-Mail: {legal.email}
        <br />
        Telefon: {legal.phone}
      </p>
      <h2>Umsatzsteuer-ID</h2>
      <p>{legal.vatId}</p>
      <h2>Verantwortlich für den Inhalt (§ 18 Abs. 2 MStV)</h2>
      <p>{legal.responsibleForContent}</p>
      <h2>Verbraucherstreitbeilegung</h2>
      <p>
        Wir sind nicht bereit oder verpflichtet, an Streitbeilegungsverfahren vor einer
        Verbraucherschlichtungsstelle teilzunehmen. [PLATZHALTER: prüfen und ggf. anpassen]
      </p>
    </main>
  );
}
