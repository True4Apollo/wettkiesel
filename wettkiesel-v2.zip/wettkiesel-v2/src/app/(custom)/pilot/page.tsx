import type { Metadata } from 'next';
import Link from 'next/link';
import { ContactForm } from '@/components/custom/contact-form';
import styles from '@/components/custom/pilot-interest.module.css';
import { pilotOffer } from '@/lib/wettkiesel-config';

export const metadata: Metadata = {
  title: 'Preisüberwachung 14 Tage kostenlos testen',
  description:
    'Fordere deinen kostenlosen 14-Tage-Pilot an: Wettkiesel beobachtet Preise und Verfügbarkeit deiner Wettbewerber und schickt dir Tagesberichte. Ohne Zugangsdaten.',
  alternates: { canonical: '/pilot' },
};

export default async function PilotPage({
  searchParams,
}: {
  searchParams: Promise<{ tarif?: string }>;
}) {
  const { tarif } = await searchParams;
  return (
    <main className={styles.page}>
      <div className={styles.layout}>
        <section className={styles.intro} aria-labelledby="pilot-title">
          <p className={styles.eyebrow}>
            <span aria-hidden="true" /> WETTKIESEL · KOSTENLOSER PILOT
          </p>
          <h1 id="pilot-title">14 Tage Preisüberwachung – kostenlos.</h1>
          <p className={styles.lede}>
            {pilotOffer} Danach bekommst du täglich einen Bericht, was sich bei deinen Wettbewerbern
            an Preisen und Verfügbarkeit geändert hat.
          </p>
          <div className={styles.boundary}>
            <span aria-hidden="true">i</span>
            <p>
              Keine Zugangsdaten nötig. Wettkiesel ändert heute keine Preise automatisch – du
              entscheidest. Der Pilot endet automatisch, ohne Abo.
            </p>
          </div>
          <Link className={styles.backLink} href="/">
            Zurück zu Wettkiesel <span aria-hidden="true">↗</span>
          </Link>
        </section>

        <section className={styles.formPanel} id="pilot-form" aria-labelledby="pilot-form-title">
          <div className={styles.formHeading}>
            <p>PILOT ANFRAGEN</p>
            <h2 id="pilot-form-title">Dauert unter einer Minute</h2>
            <span>Pflicht sind nur Name, E-Mail, Shop-URL und Shopsystem.</span>
          </div>
          <ContactForm tarif={tarif} />
        </section>
      </div>
    </main>
  );
}
