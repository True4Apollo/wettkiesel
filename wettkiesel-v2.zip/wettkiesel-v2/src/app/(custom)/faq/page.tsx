// @polsia:user-owned — the FAQ page. Restyle it freely: change the layout, the
// classes, the copy, swap <FaqAccordion/> for cards, add sections, etc. Keep two
// things for SEO: (1) stay a Server Component (no 'use client') so `metadata`
// renders, and (2) keep <FaqJsonLd items={faqContent.items} /> on the page so the
// FAQPage structured data ships. Edit the questions/answers + CTA in
// src/lib/faq/content.ts.
import type { Metadata } from 'next';
import Link from 'next/link';
import { FaqAccordion } from '@/components/custom/faq-accordion';
import { Button } from '@/components/ui/button';
import { faqContent } from '@/lib/faq/content';
import { siteDescription, siteName } from '@/lib/site';
import { FaqJsonLd } from '@/modules/faq-page/faq-jsonld';

export const metadata: Metadata = {
  title: 'FAQ zu Preisbeobachtung und Shop-Verbindung',
  description: `Antworten zur aktuellen Preisbeobachtung und zu Shop-Verbindungen bei ${siteName}. ${siteDescription}`,
  alternates: { canonical: '/faq' },
};

export default function FaqPage() {
  return (
    <main className="mx-auto flex w-full max-w-3xl flex-col gap-8 px-6 py-16 sm:py-20">
      {/* SEO structured data — keep this when restyling (see FaqJsonLd). */}
      <FaqJsonLd items={faqContent.items} />

      <header className="flex flex-col gap-3">
        <p className="text-sm font-medium uppercase tracking-[0.18em] text-muted-foreground">
          Wettkiesel erklärt
        </p>
        <h1 className="font-display text-3xl font-semibold tracking-tight sm:text-4xl">
          Häufige Fragen zu Preisbeobachtung und Shop-Verbindung
        </h1>
        {faqContent.intro ? <p className="text-muted-foreground">{faqContent.intro}</p> : null}
      </header>

      <FaqAccordion items={faqContent.items} />

      {faqContent.cta ? (
        <div className="flex flex-col items-start gap-3 rounded-lg border bg-muted/40 p-6">
          <Button asChild>
            <Link href={faqContent.cta.href}>{faqContent.cta.label}</Link>
          </Button>
        </div>
      ) : null}
    </main>
  );
}
