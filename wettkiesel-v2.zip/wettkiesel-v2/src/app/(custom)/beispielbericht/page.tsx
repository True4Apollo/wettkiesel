import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Beispiel-Tagesbericht – so sieht Preisüberwachung mit Wettkiesel aus',
  description:
    'Ein Beispiel-Tagesbericht von Wettkiesel mit fiktiven Daten: Preisänderungen, Verfügbarkeit, fehlende Messungen und unverbindliche Preisvorschläge.',
  alternates: { canonical: '/beispielbericht' },
};

const rows = [
  {
    product: 'Espressomühle „Modell A“',
    competitor: 'Shop Nord',
    before: '249,00 €',
    after: '229,00 €',
    change: '−8,0 %',
    stock: 'verfügbar',
  },
  {
    product: 'Espressomühle „Modell A“',
    competitor: 'Shop Süd',
    before: '245,00 €',
    after: '245,00 €',
    change: 'unverändert',
    stock: 'verfügbar',
  },
  {
    product: 'Milchkännchen 350 ml',
    competitor: 'Shop Nord',
    before: '19,90 €',
    after: '19,90 €',
    change: 'unverändert',
    stock: 'nicht verfügbar (neu)',
  },
  {
    product: 'Tamper 58 mm',
    competitor: 'Shop West',
    before: '34,90 €',
    after: '–',
    change: 'keine Messung',
    stock: 'Seite nicht erreichbar',
  },
];

export default function BeispielberichtPage() {
  return (
    <main className="wk-legal">
      <p className="wk-placeholder-note">
        <strong>Beispieldaten:</strong> Produkte, Shops und Preise auf dieser Seite sind frei
        erfunden und dienen nur der Veranschaulichung. Es sind keine echten Messwerte.
      </p>
      <h1>Tagesbericht (Beispiel)</h1>
      <p>Dein Shop: Beispiel-Kaffeeshop · 3 Produkte · 3 Wettbewerber</p>

      <h2>Auf einen Blick</h2>
      <ul>
        <li>1 Preissenkung bei einem Wettbewerber</li>
        <li>1 Produkt beim Wettbewerber neu ausverkauft</li>
        <li>1 Seite konnte nicht geprüft werden – das heißt nicht „unverändert“</li>
      </ul>

      <h2>Messungen</h2>
      <table className="wk-report-table">
        <thead>
          <tr>
            <th>Produkt</th>
            <th>Wettbewerber</th>
            <th>Vorher</th>
            <th>Heute</th>
            <th>Änderung</th>
            <th>Verfügbarkeit</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.product + r.competitor}>
              <td>{r.product}</td>
              <td>{r.competitor}</td>
              <td>{r.before}</td>
              <td>{r.after}</td>
              <td>{r.change}</td>
              <td>{r.stock}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>Unverbindlicher Preisvorschlag</h2>
      <p>
        Espressomühle „Modell A“: Dein Preis 239,00 €. Deine Untergrenze: 225,00 €. Vorschlag:
        229,00 € – innerhalb deiner Grenzen. Wettkiesel ändert nichts automatisch; du entscheidest.
      </p>

      <p>
        <Link href="/pilot">Eigenen Bericht 14 Tage kostenlos testen →</Link>
      </p>
    </main>
  );
}
