import type { Metadata } from 'next';
import { legal } from '@/lib/wettkiesel-config';

export const metadata: Metadata = {
  title: 'Datenschutzerklärung',
  description: 'Datenschutzerklärung von Wettkiesel.',
  alternates: { canonical: '/datenschutz' },
};

export default function DatenschutzPage() {
  return (
    <main className="wk-legal">
      <h1>Datenschutzerklärung</h1>
      <p className="wk-placeholder-note">
        <strong>Entwurf / Gerüst – keine Rechtsberatung.</strong> Platzhalter in eckigen Klammern
        ersetzen und den Text vor dem Livegang mit einem Generator (z. B. eRecht24, Dr. Schwenke)
        oder anwaltlich prüfen lassen.
      </p>

      <h2>1. Verantwortlicher</h2>
      <p>
        {legal.name}, {legal.street}, {legal.city}, {legal.country}. E-Mail: {legal.email}
      </p>

      <h2>2. Hosting</h2>
      <p>
        Diese Website wird gehostet bei: {legal.hosting}. Beim Aufruf werden technisch notwendige
        Daten (z. B. IP-Adresse, Zeitpunkt, aufgerufene Seite, Browser) in Server-Logfiles
        verarbeitet (Art. 6 Abs. 1 lit. f DSGVO).
      </p>

      <h2>3. Datenbank</h2>
      <p>Formular- und Kontodaten werden gespeichert bei: {legal.database}.</p>

      <h2>4. Pilot- und Kontaktformular</h2>
      <p>
        Wenn du das Pilotformular nutzt, speichern wir Name, E-Mail-Adresse, Shop-URL, Shopsystem,
        optionale Wettbewerber-URLs und optionale Angaben zur Zahlungsbereitschaft, um deine Anfrage
        zu bearbeiten und den Pilot einzurichten (Art. 6 Abs. 1 lit. b DSGVO). Löschung:
        [PLATZHALTER: Speicherdauer festlegen, z. B. 12 Monate nach Ende des Kontakts].
      </p>

      <h2>5. Benutzerkonto</h2>
      <p>
        Für den Login speichern wir E-Mail-Adresse, Name und ein gehashtes Passwort sowie
        Sitzungsdaten (technisch notwendige Cookies).
      </p>

      <h2>6. Beobachtung öffentlicher Wettbewerberseiten</h2>
      <p>
        Wettkiesel ruft öffentlich zugängliche Produktseiten ab und speichert Preis, Verfügbarkeit
        und Zeitpunkt. Dabei werden keine personenbezogenen Daten von Endkunden erhoben.
      </p>

      <h2>7. Analyse</h2>
      <p>
        [PLATZHALTER: Falls ein Analyse-Tool eingesetzt wird (z. B. Plausible, Umami), hier
        benennen. Standardmäßig ist in dieser Version keines aktiv.]
      </p>

      <h2>8. Deine Rechte</h2>
      <ul>
        <li>Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung</li>
        <li>Datenübertragbarkeit und Widerspruch</li>
        <li>Beschwerde bei einer Datenschutz-Aufsichtsbehörde</li>
      </ul>
      <p>Anfragen bitte an: {legal.email}</p>
      <p>Stand: [PLATZHALTER: Datum]</p>
    </main>
  );
}
