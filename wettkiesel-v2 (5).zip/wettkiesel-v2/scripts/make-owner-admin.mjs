// Schaltet den Inhaber-Account frei (E-Mail bestätigt + Admin), solange kein
// E-Mail-Dienst für Bestätigungsmails eingerichtet ist.
// Aufruf (z. B. in der Render-Shell): node scripts/make-owner-admin.mjs
// Nutzt POLSIA_OWNER_EMAIL (oder das erste Argument) und DATABASE_URL.
import { PrismaClient } from '@prisma/client';

const email = (process.argv[2] ?? process.env.POLSIA_OWNER_EMAIL ?? '').trim().toLowerCase();
if (!email) {
  console.error('Keine Inhaber-E-Mail angegeben.');
  process.exit(1);
}
const prisma = new PrismaClient();
const res = await prisma.user.updateMany({
  where: { email },
  data: { emailVerified: true, role: 'admin' },
});
console.log(
  res.count
    ? `Freigeschaltet: ${email}`
    : `Kein Konto mit ${email} gefunden – zuerst registrieren.`,
);
await prisma.$disconnect();
