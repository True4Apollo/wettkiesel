// @polsia:user-owned — seeded by polsia/modules/better-auth; restyle freely.
'use client';

import Link from 'next/link';
import { EmailVerification } from '@/components/custom/email-verification';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { signOut, useIsAdmin, useSession } from '@/lib/auth-client';

export default function ProfilePage() {
  const { data: session, isPending } = useSession();
  const isAdmin = useIsAdmin();

  if (isPending) {
    return (
      <main className="min-h-dvh flex items-center justify-center px-gutter bg-[var(--background)]">
        <p className="text-muted-foreground">Konto wird geladen …</p>
      </main>
    );
  }

  if (!session?.user) {
    return (
      <main className="min-h-dvh flex items-center justify-center px-gutter py-section bg-[var(--background)]">
        <Card className="w-full max-w-md shadow-brand border border-border/60 bg-card/95 backdrop-blur-sm">
          <CardHeader className="text-center pb-2">
            <CardTitle className="text-h4">Nicht angemeldet</CardTitle>
            <CardDescription>Melde dich an, um dein Konto zu öffnen.</CardDescription>
          </CardHeader>
          <CardContent className="pt-4">
            <Button asChild className="w-full">
              <Link href="/login">Anmelden</Link>
            </Button>
          </CardContent>
        </Card>
      </main>
    );
  }

  return (
    <main className="min-h-dvh px-gutter py-section bg-[var(--background)]">
      <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
        <div className="absolute top-[-20%] right-[-5%] w-[600px] h-[600px] rounded-full bg-[var(--brand-100)] opacity-30 blur-3xl" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[400px] h-[400px] rounded-full bg-[var(--brand-200)] opacity-20 blur-3xl" />
      </div>

      <div className="relative max-w-lg mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-16 h-16 rounded-full bg-[var(--brand-200)] flex items-center justify-center text-h3 font-bold text-brand-700 select-none">
            {session.user.name?.charAt(0).toUpperCase() ?? '?'}
          </div>
          <div>
            <h1 className="text-h3 font-bold text-foreground">{session.user.name}</h1>
            <p className="text-muted-foreground text-body">{session.user.email}</p>
          </div>
        </div>

        <Separator className="my-6" />

        {/* Bestätigungsmails nur, wenn ein E-Mail-Dienst eingerichtet ist (NEXT_PUBLIC_EMAIL_VERIFICATION=true). */}
        {process.env.NEXT_PUBLIC_EMAIL_VERIFICATION !== 'true' ? null : !session.user
            .emailVerified ? (
          <div className="mb-6 rounded-lg border border-border bg-card p-6">
            <EmailVerification email={session.user.email} />
          </div>
        ) : (
          <output className="mb-6 block text-sm text-muted-foreground">
            Deine E-Mail-Adresse ist bestätigt.
          </output>
        )}

        <Card className="shadow-brand border border-border/60 bg-card/95 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-h4">Kontodaten</CardTitle>
            <CardDescription>Deine Wettkiesel-Anmeldedaten</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
            <div className="flex justify-between items-center py-2">
              <span className="text-muted-foreground text-body">Name</span>
              <span className="font-medium text-foreground">{session.user.name}</span>
            </div>
            <Separator />
            <div className="flex justify-between items-center py-2">
              <span className="text-muted-foreground text-body">E-Mail</span>
              <span className="font-medium text-foreground">{session.user.email}</span>
            </div>
          </CardContent>
        </Card>

        <div className="mt-6 flex flex-wrap justify-end gap-2">
          <Button asChild variant="outline">
            <Link href={isAdmin ? '/admin' : '/dashboard'}>
              {isAdmin ? 'Shopbereich öffnen' : 'Zum Kundenkonto'}
            </Link>
          </Button>
          <Button
            variant="secondary"
            onClick={async () => {
              await signOut();
              window.location.assign('/login');
            }}
          >
            Abmelden
          </Button>
        </div>
      </div>
    </main>
  );
}
