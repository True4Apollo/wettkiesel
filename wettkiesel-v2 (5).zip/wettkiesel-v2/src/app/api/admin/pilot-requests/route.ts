// @polsia:user-owned
import 'server-only';
import { headers } from 'next/headers';
import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { PilotRequestList } from '@/lib/contracts/pilot-requests';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

const willingnessMarker = '\n\nZahlungsbereitschaft (unverbindlich): ';
const pilotMarker = 'Zahlungsbereitschaft (unverbindlich):';
const privateHeaders = { 'Cache-Control': 'private, no-store' };

export async function GET() {
  try {
    const session = await auth.api.getSession({ headers: await headers() });
    if (!session) {
      return NextResponse.json(
        { error: 'Nicht angemeldet.' },
        { status: 401, headers: privateHeaders },
      );
    }
    if (session.user.role !== 'admin') {
      return NextResponse.json(
        { error: 'Kein Adminzugriff.' },
        { status: 403, headers: privateHeaders },
      );
    }

    const messages = await prisma.contactMessage.findMany({
      where: { message: { contains: pilotMarker } },
      select: { id: true, name: true, email: true, createdAt: true, message: true },
      orderBy: { createdAt: 'desc' },
    });

    const items = messages.map(({ id, name, email, createdAt, message }) => {
      const markerIndex = message.lastIndexOf(willingnessMarker);
      const answers = markerIndex < 0 ? message.trim() : message.slice(0, markerIndex).trim();
      const willingness =
        markerIndex < 0
          ? null
          : message.slice(markerIndex + willingnessMarker.length).trim() || null;

      return { id, name, email, createdAt: createdAt.toISOString(), willingness, answers };
    });

    const users = await prisma.user.findMany({
      where: { NOT: { role: 'admin' } },
      select: { id: true, name: true, email: true, emailVerified: true, createdAt: true },
      orderBy: { createdAt: 'desc' },
      take: 200,
    });
    const signups = users.map((u) => ({ ...u, createdAt: u.createdAt.toISOString() }));

    return NextResponse.json(PilotRequestList.parse({ items, signups }), {
      headers: privateHeaders,
    });
  } catch {
    return NextResponse.json(
      { error: 'Pilotanfragen konnten nicht geladen werden.' },
      { status: 500, headers: privateHeaders },
    );
  }
}
