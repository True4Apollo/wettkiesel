// GET /api/cron/leads?since=<ISO-Datum> – neue Pilotanfragen und Konten als JSON.
// Für eine tägliche, automatische Prüfung (z. B. Erinnerung/Agent), ohne E-Mail-Dienst.
// Geschützt über CRON_SECRET (Header: Authorization: Bearer <CRON_SECRET>).
import 'server-only';
import { timingSafeEqual } from 'node:crypto';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

function authorized(req: Request, secret: string): boolean {
  const header = req.headers.get('authorization') ?? '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  const a = Buffer.from(token);
  const b = Buffer.from(secret);
  return a.length === b.length && timingSafeEqual(a, b);
}

export async function GET(req: Request) {
  const secret = process.env.CRON_SECRET;
  if (!secret) return NextResponse.json({ error: 'cron_disabled' }, { status: 503 });
  if (!authorized(req, secret))
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 });

  const sinceParam = new URL(req.url).searchParams.get('since');
  const parsed = sinceParam ? new Date(sinceParam) : null;
  const since =
    parsed && !Number.isNaN(parsed.getTime()) ? parsed : new Date(Date.now() - 24 * 3600 * 1000);

  const [pilotRequests, signups] = await Promise.all([
    prisma.contactMessage.findMany({
      where: { createdAt: { gte: since } },
      select: { id: true, name: true, email: true, message: true, createdAt: true },
      orderBy: { createdAt: 'desc' },
    }),
    prisma.user.findMany({
      where: { createdAt: { gte: since }, NOT: { role: 'admin' } },
      select: { id: true, name: true, email: true, createdAt: true },
      orderBy: { createdAt: 'desc' },
    }),
  ]);

  return NextResponse.json(
    { since: since.toISOString(), pilotRequests, signups },
    { headers: { 'Cache-Control': 'private, no-store' } },
  );
}
