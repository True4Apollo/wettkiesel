// @polsia:user-owned
//
// POST /api/contact — plain REST route handler that writes a ContactMessage and
// then surfaces it in the founder's Polsia dashboard, so a submission is actually
// READ by someone — and can be answered.
// Lives under /api, which proxy.ts's matcher excludes (no CSP/nonce, not proxied).
// PUBLIC — no auth check.
//
// Requires the `email` module (@/lib/email/submissions + send + templates).

import 'server-only';
import { NextResponse } from 'next/server';
import { contactSchema } from '@/lib/contact/schema';
import { prisma } from '@/lib/db';
import { sendEmail } from '@/lib/email/send';
import { recordSubmission } from '@/lib/email/submissions';
import { notificationEmail } from '@/lib/email/templates';
import { env } from '@/lib/env';

export const dynamic = 'force-dynamic';

export async function POST(req: Request) {
  const body = await req.json();
  const result = contactSchema.safeParse({
    name: body.name,
    email: body.email,
    message: body.message,
    willingness: body.willingness || undefined,
    fields: body.fields,
  });
  if (!result.success) {
    const fieldErrors = result.error.flatten().fieldErrors;
    return NextResponse.json(
      {
        errors: {
          name: fieldErrors.name?.[0],
          email: fieldErrors.email?.[0],
          message: fieldErrors.message?.[0] ?? fieldErrors.fields?.[0],
          willingness: fieldErrors.willingness?.[0],
        },
      },
      { status: 400 },
    );
  }

  const willingnessLabel = 'Zahlungsbereitschaft (unverbindlich)';
  const submission = {
    ...result.data,
    message: `${result.data.message}\n\n${willingnessLabel}: ${result.data.willingness ?? 'Keine Angabe'}`,
    fields: {
      ...(result.data.fields ?? {}),
      [willingnessLabel]: result.data.willingness ?? 'Keine Angabe',
    },
  };

  let saved: { id: string };
  try {
    saved = await prisma.contactMessage.create({
      data: {
        name: submission.name,
        email: submission.email,
        message: submission.message,
      },
    });
  } catch {
    return NextResponse.json(
      { errors: { message: 'Etwas ist schiefgelaufen. Bitte versuche es erneut.' } },
      { status: 500 },
    );
  }

  await notifyCompany(submission, saved.id);

  return NextResponse.json({ ok: true }, { status: 201 });
}

/**
 * Surface the message to the founder. The row above is already committed and is
 * the source of truth, so this whole function is best-effort by design: a
 * rate-limited or failing call must never turn a captured message into an error
 * for the visitor.
 *
 * Two paths, in order:
 *
 *  1. `recordSubmission` — the good one. Records the message in the Polsia
 *     dashboard as a message FROM the visitor, so it lands in the dashboard's
 *     contact-form view and the founder can REPLY to the person who wrote it.
 *  2. The email fallback, used only when step 1 recorded nothing (`recorded:
 *     false` = company not ramped, or a deployment older than the endpoint) or
 *     threw. Mails the company's own inbox (`{slug}@polsia.app`). The founder
 *     still hears about the message, but cannot reply from the dashboard: the
 *     proxy sets no custom Reply-To, so the mail arrives From the company
 *     itself. That is why the sender's address goes in the BODY.
 *
 * Never a made-up brand address (`contact@brand.com`) or a placeholder — both go
 * nowhere.
 */
async function notifyCompany(
  input: { name: string; email: string; message: string; fields?: Record<string, string> },
  submissionId: string,
) {
  // Ohne Polsia-E-Mail-Proxy: Anfrage liegt nur in der Datenbank (sichtbar unter
  // /admin/pilotanfragen). Siehe README, Abschnitt „E-Mail-Benachrichtigung“.
  if (!env.POLSIA_EMAIL_PROXY_URL) return;
  try {
    const { recorded } = await recordSubmission({
      source: 'contact_form',
      email: input.email,
      name: input.name,
      message: input.message,
      fields: input.fields,
      // The row id — dedupes a retried submission on the platform side.
      idempotencyKey: submissionId,
    });
    if (recorded) return;
  } catch {
    // Anomaly (validation, cap, transport). Fall through to the email fallback
    // rather than lose the notification.
  }

  // Absent when the company has no inbox address yet — nothing to fall back to.
  const to = env.POLSIA_COMPANY_EMAIL;
  if (!to) return;

  try {
    await sendEmail({
      to,
      ...notificationEmail({
        subject: `Neues Pilotinteresse von ${input.name}`,
        title: 'Neue Pilotanfrage',
        lines: [`Von: ${input.name} <${input.email}>`, input.message],
      }),
    });
  } catch {
    // Deliberately swallowed — see the best-effort note above.
  }
}
