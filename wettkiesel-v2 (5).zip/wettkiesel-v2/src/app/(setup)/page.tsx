// Öffentliche Startseite von Wettkiesel.
import { ArrowRight, Bell, Check, Clock, FileText, LineChart, ShieldCheck, X } from 'lucide-react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { BrandMark } from '@/components/custom/brand-mark';
import { PricingSection } from '@/components/custom/pricing-section';
import { ReportMockup } from '@/components/custom/report-mockup';
import { founder } from '@/lib/wettkiesel-config';

export const metadata: Metadata = {
  title: {
    absolute: 'Preisüberwachung für kleine Onlineshops – Wettbewerberpreise im Blick | Wettkiesel',
  },
  description:
    'Wettkiesel prüft täglich Preise und Verfügbarkeit deiner Wettbewerber und fasst Änderungen in einem klaren Tagesbericht zusammen. 14 Tage kostenlos testen, ohne Zugangsdaten.',
  alternates: { canonical: '/' },
  openGraph: {
    url: '/',
    title: 'Wettkiesel – Preisüberwachung für kleine Onlineshops',
    description:
      'Täglich Preise und Verfügbarkeit deiner Wettbewerber im Blick. 14 Tage kostenlos testen, ohne Zugangsdaten.',
  },
};

const benefits = [
  {
    icon: Clock,
    title: 'Schluss mit Tab-Hopping',
    text: 'Wettkiesel prüft die Produktseiten deiner Wettbewerber jeden Tag. Du liest nur noch das Ergebnis.',
  },
  {
    icon: LineChart,
    title: 'Änderungen statt Rauschen',
    text: 'Der Tagesbericht zeigt, was sich wirklich verändert hat – mit Verlauf, Zeitpunkt und Quelle.',
  },
  {
    icon: ShieldCheck,
    title: 'Du behältst die Kontrolle',
    text: 'Preisvorschläge bleiben innerhalb deiner Grenzen. Wettkiesel ändert nichts in deinem Shop.',
  },
];

const steps = [
  {
    n: '1',
    title: 'Shop & Wettbewerber nennen',
    text: 'Shop-URL, Shopsystem, bis zu 5 Wettbewerber. Keine Zugangsdaten.',
  },
  {
    n: '2',
    title: 'Wir richten es ein',
    text: 'Wir ordnen bis zu 25 deiner Produkte den passenden Angeboten zu.',
  },
  {
    n: '3',
    title: 'Jeden Morgen informiert',
    text: '14 Tage echte Tagesberichte. Danach entscheidest du.',
  },
];

const objections = [
  {
    q: '„Ich schaue doch eh selbst nach.“',
    a: 'Bei 20 Produkten und 3 Wettbewerbern sind das 60 Seiten – jeden Tag. Wettkiesel macht das in Sekunden und vergisst nichts.',
  },
  {
    q: '„Ich will nicht, dass ein Tool meine Preise ändert.“',
    a: 'Tut es nicht. Du bekommst Fakten und Vorschläge innerhalb deiner Grenzen. Jeder Preis bleibt deine Entscheidung.',
  },
  {
    q: '„Das ist doch nur was für große Händler.“',
    a: 'Gerade kleine Shops spüren jeden Euro Marge. Ab 29 € im Monat – weniger als eine Stunde deiner Zeit.',
  },
];

const faq = [
  {
    q: 'Was beobachtet Wettkiesel genau?',
    a: 'Öffentlich sichtbare Preise und Verfügbarkeiten auf den Produktseiten, die du uns nennst. Wir lesen dafür die strukturierten Produktdaten, die Shops ohnehin für Google bereitstellen.',
  },
  {
    q: 'Ändert Wettkiesel Preise in meinem Shop?',
    a: 'Nein. Heute gibt es Hinweise und unverbindliche Vorschläge – entscheiden und ändern tust du. Automatische Anpassung innerhalb fester Grenzen ist geplant und kommt zuerst für Pilotpartner.',
  },
  {
    q: 'Brauche ich Zugangsdaten oder eine Integration?',
    a: 'Nein. Für die Beobachtung reichen öffentliche Produktseiten. Bitte teile keine Passwörter oder API-Schlüssel.',
  },
  {
    q: 'Was, wenn eine Seite nicht ausgelesen werden kann?',
    a: 'Dann steht das im Bericht – als „keine Messung“, nicht als „unverändert“. Wir sagen dir ehrlich, welche Seiten funktionieren.',
  },
  {
    q: 'Was kostet es nach dem Test?',
    a: 'Ab 29 € im Monat, monatlich kündbar. Der Test endet automatisch – ohne Abo-Falle.',
  },
];

export default function HomePage() {
  return (
    <main className="lp">
      <header className="lp-header">
        <div className="lp-container lp-header-inner">
          <Link href="/" className="lp-logo" aria-label="Wettkiesel – Startseite">
            <BrandMark small />
            <span>wettkiesel</span>
          </Link>
          <nav className="lp-nav" aria-label="Hauptnavigation">
            <a href="#vorteile">Vorteile</a>
            <a href="#ablauf">Ablauf</a>
            <a href="#preise">Preise</a>
            <Link href="/beispielbericht">Beispielbericht</Link>
            <a href="#faq">FAQ</a>
          </nav>
          <div className="lp-header-actions">
            <Link href="/login" className="lp-link">
              Login
            </Link>
            <Link href="/pilot" className="lp-btn lp-btn-primary lp-btn-sm">
              Kostenlos testen
            </Link>
          </div>
        </div>
      </header>

      <section className="lp-hero">
        <div className="lp-container lp-hero-grid">
          <div className="lp-hero-copy">
            <p className="lp-pill">
              <span aria-hidden="true">●</span> Preisüberwachung für kleine Onlineshops
            </p>
            <h1>
              Wisse jeden Morgen, was deine Konkurrenz <em>über Nacht</em> geändert hat.
            </h1>
            <p className="lp-lede">
              Wettkiesel prüft jeden Tag Preise und Lagerstatus deiner wichtigsten Wettbewerber und
              fasst alles in einem kurzen Bericht zusammen. Du sparst die Handrecherche, reagierst
              schneller – und entscheidest selbst.
            </p>
            <div className="lp-cta-row">
              <Link href="/pilot" className="lp-btn lp-btn-primary lp-btn-lg">
                14 Tage kostenlos testen <ArrowRight size={18} aria-hidden="true" />
              </Link>
              <Link href="/beispielbericht" className="lp-btn lp-btn-ghost lp-btn-lg">
                Echten Bericht ansehen
              </Link>
            </div>
            <ul className="lp-hero-points">
              <li>
                <Check size={16} aria-hidden="true" /> Keine Zugangsdaten
              </li>
              <li>
                <Check size={16} aria-hidden="true" /> Einrichtung inklusive
              </li>
              <li>
                <Check size={16} aria-hidden="true" /> Endet automatisch
              </li>
            </ul>
          </div>
          <ReportMockup />
        </div>
      </section>

      <section className="lp-proof" aria-label="Echtes Messbeispiel">
        <div className="lp-container lp-proof-inner">
          <p>
            <strong>Echtes Beispiel vom 20.10.2026:</strong> Dieselbe Comandante-Handmühle kostete
            in drei deutschen Shops zwischen <strong>204,99 €</strong> und <strong>229,00 €</strong>{' '}
            – ein Unterschied von 24 €. Wer das nicht sieht, verschenkt Marge oder Umsatz.
          </p>
          <Link href="/beispielbericht" className="lp-link-strong">
            Zum Bericht <ArrowRight size={16} aria-hidden="true" />
          </Link>
        </div>
      </section>

      <section className="lp-section" id="vorteile" aria-labelledby="vorteile-title">
        <div className="lp-container">
          <div className="lp-heading">
            <p className="lp-eyebrow">Warum Wettkiesel</p>
            <h2 id="vorteile-title">
              Preisentscheidungen auf Basis von Fakten, nicht Bauchgefühl.
            </h2>
          </div>
          <div className="lp-cards">
            {benefits.map(({ icon: Icon, title, text }) => (
              <article key={title} className="lp-card">
                <span className="lp-icon">
                  <Icon size={20} aria-hidden="true" />
                </span>
                <h3>{title}</h3>
                <p>{text}</p>
              </article>
            ))}
          </div>

          <div className="lp-scope">
            <div>
              <p className="lp-scope-label lp-scope-now">Heute verfügbar</p>
              <ul className="lp-checks">
                <li>
                  <Check size={16} aria-hidden="true" /> Tägliche Preis- & Verfügbarkeitsprüfung
                </li>
                <li>
                  <Check size={16} aria-hidden="true" /> Messverlauf mit Zeitpunkt und Quelle
                </li>
                <li>
                  <Check size={16} aria-hidden="true" /> Tagesbericht & unverbindliche
                  Preisvorschläge
                </li>
              </ul>
            </div>
            <div>
              <p className="lp-scope-label">Roadmap · noch nicht verfügbar</p>
              <ul className="lp-checks lp-checks-muted">
                <li>
                  <Bell size={16} aria-hidden="true" /> E-Mail-Alarm bei wichtigen Änderungen
                </li>
                <li>
                  <ArrowRight size={16} aria-hidden="true" /> Automatische Preisanpassung in festen
                  Grenzen (zuerst mit Pilotpartnern)
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="lp-section lp-section-alt" id="ablauf" aria-labelledby="ablauf-title">
        <div className="lp-container">
          <div className="lp-heading lp-heading-center">
            <p className="lp-eyebrow">So läuft der Test</p>
            <h2 id="ablauf-title">In drei Schritten zum ersten Tagesbericht.</h2>
          </div>
          <ol className="lp-steps">
            {steps.map((s) => (
              <li key={s.n}>
                <span className="lp-step-n">{s.n}</span>
                <h3>{s.title}</h3>
                <p>{s.text}</p>
              </li>
            ))}
          </ol>
          <div className="lp-center">
            <Link href="/beispielbericht" className="lp-link-strong">
              <FileText size={16} aria-hidden="true" /> So sieht ein Bericht mit echten Daten aus
            </Link>
          </div>
        </div>
      </section>

      <PricingSection />

      <section className="lp-section lp-section-alt" aria-labelledby="vergleich-title">
        <div className="lp-container lp-compare">
          <div className="lp-heading">
            <p className="lp-eyebrow">Ehrlicher Vergleich</p>
            <h2 id="vergleich-title">Für wen Wettkiesel passt – und für wen nicht.</h2>
          </div>
          <div className="lp-compare-grid">
            <div className="lp-card">
              <h3>Passt gut, wenn du …</h3>
              <ul className="lp-checks">
                <li>
                  <Check size={16} aria-hidden="true" /> einen kleinen Shop mit vergleichbarer
                  Markenware führst
                </li>
                <li>
                  <Check size={16} aria-hidden="true" /> 3–5 Wettbewerber im Blick behalten willst
                </li>
                <li>
                  <Check size={16} aria-hidden="true" /> persönliche Einrichtung auf Deutsch schätzt
                </li>
              </ul>
            </div>
            <div className="lp-card">
              <h3>Eher nicht, wenn du …</h3>
              <ul className="lp-checks lp-checks-muted">
                <li>
                  <X size={16} aria-hidden="true" /> heute schon vollautomatisches Repricing
                  brauchst
                </li>
                <li>
                  <X size={16} aria-hidden="true" /> zehntausende Artikel oder Amazon-Repricing
                  suchst
                </li>
                <li>
                  <X size={16} aria-hidden="true" /> nur Eigenmarken ohne Vergleichsprodukte
                  verkaufst
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="lp-section" aria-labelledby="einwaende-title">
        <div className="lp-container">
          <div className="lp-heading">
            <p className="lp-eyebrow">Berechtigte Einwände</p>
            <h2 id="einwaende-title">Klingt gut – aber …</h2>
          </div>
          <div className="lp-cards">
            {objections.map((o) => (
              <article key={o.q} className="lp-card">
                <h3>{o.q}</h3>
                <p>{o.a}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="lp-section lp-section-alt" aria-labelledby="founder-title">
        <div className="lp-container">
          <div className="lp-founder">
            {founder.photo ? (
              // biome-ignore lint/performance/noImgElement: statisches Foto
              <img src={founder.photo} alt={founder.name} className="lp-founder-photo" />
            ) : (
              <div className="lp-founder-photo" aria-hidden="true">
                <BrandMark small />
              </div>
            )}
            <div>
              <p className="lp-eyebrow">Wer dahinter steht</p>
              <h2 id="founder-title">{founder.name}</h2>
              <p className="lp-muted">{founder.role}</p>
              {founder.text ? <p>{founder.text}</p> : null}
            </div>
          </div>
        </div>
      </section>

      <section className="lp-section" id="faq" aria-labelledby="faq-title">
        <div className="lp-container lp-faq">
          <div className="lp-heading">
            <p className="lp-eyebrow">FAQ</p>
            <h2 id="faq-title">Häufige Fragen</h2>
            <Link href="/faq" className="lp-link-strong">
              Alle Fragen ansehen <ArrowRight size={16} aria-hidden="true" />
            </Link>
          </div>
          <div className="lp-faq-list">
            {faq.map((item) => (
              <details key={item.q}>
                <summary>{item.q}</summary>
                <p>{item.a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="lp-final">
        <div className="lp-container lp-final-inner">
          <h2>Morgen früh wissen, was sich geändert hat.</h2>
          <p>
            14 Tage kostenlos, Einrichtung inklusive, keine Zugangsdaten. Wir nehmen nur 10 Shops in
            den Pilot auf, damit jede Einrichtung persönlich bleibt.
          </p>
          <Link href="/pilot" className="lp-btn lp-btn-accent lp-btn-lg">
            Kostenlosen Test starten <ArrowRight size={18} aria-hidden="true" />
          </Link>
        </div>
      </section>

      <footer className="lp-footer">
        <div className="lp-container lp-footer-inner">
          <div>
            <Link href="/" className="lp-logo">
              <BrandMark small />
              <span>wettkiesel</span>
            </Link>
            <p className="lp-muted">Preisüberwachung für kleine Onlineshops.</p>
          </div>
          <nav aria-label="Footer" className="lp-footer-links">
            <Link href="/pilot">Kostenlos testen</Link>
            <Link href="/beispielbericht">Beispielbericht</Link>
            <Link href="/faq">FAQ</Link>
            <Link href="/impressum">Impressum</Link>
            <Link href="/datenschutz">Datenschutz</Link>
          </nav>
        </div>
      </footer>
    </main>
  );
}
