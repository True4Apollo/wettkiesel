import type { Metadata } from 'next';
import Link from 'next/link';
import { legal } from '@/lib/wettkiesel-config';

export const metadata: Metadata = {
  title: 'Allgemeine Geschäftsbedingungen (AGB)',
  description:
    'AGB von Wettkiesel: Preisüberwachung für Onlineshops, ausschließlich für Unternehmer, monatlich kündbar, 14-Tage-Test endet automatisch.',
  alternates: { canonical: '/agb' },
};

export default function AgbPage() {
  return (
    <main className="wk-legal">
      <h1>Allgemeine Geschäftsbedingungen</h1>

      <h2>§ 1 Geltungsbereich und Anbieter</h2>
      <p>
        Diese AGB gelten für alle Verträge über die Nutzung des Dienstes „Wettkiesel“ zwischen{' '}
        {legal.name}, {legal.street}, {legal.city} (nachfolgend „Anbieter“) und dem Kunden.
        Abweichende Bedingungen des Kunden gelten nur, wenn der Anbieter ihnen ausdrücklich in
        Textform zustimmt.
      </p>

      <h2>§ 2 Nur für Unternehmer</h2>
      <p>
        Das Angebot richtet sich ausschließlich an Unternehmer im Sinne des § 14 BGB, also an
        Personen, die bei Vertragsschluss in Ausübung ihrer gewerblichen oder selbständigen
        beruflichen Tätigkeit handeln (z. B. Betreiber von Onlineshops). Mit der Anfrage bzw.
        Registrierung bestätigt der Kunde, als Unternehmer zu handeln. Verträge mit Verbrauchern
        werden nicht geschlossen.
      </p>

      <h2>§ 3 Leistungen</h2>
      <p>
        Wettkiesel ruft öffentlich zugängliche Produktseiten von Wettbewerbern ab, die der Kunde
        benennt, erfasst dort angezeigte Preise und Verfügbarkeiten und stellt die Ergebnisse als
        Bericht bereit. Der Dienst gibt die zum Abrufzeitpunkt öffentlich angezeigten Angaben
        wieder. Der Anbieter schuldet keine bestimmte Vollständigkeit oder Aktualität, da
        Wettbewerberseiten sich ändern, zeitweise nicht erreichbar sein oder den Abruf verhindern
        können. Wettkiesel ändert keine Preise im Shop des Kunden; Entscheidungen über Preise trifft
        allein der Kunde.
      </p>

      <h2>§ 4 Kostenloser 14-Tage-Test</h2>
      <p>
        Der Anbieter kann einen kostenlosen Test über 14 Tage anbieten. Der Test endet automatisch
        nach Ablauf von 14 Tagen, ohne dass es einer Kündigung bedarf. Ein kostenpflichtiger Vertrag
        entsteht nur, wenn der Kunde nach dem Test ausdrücklich einen kostenpflichtigen Tarif bucht.
        Für den Test werden keine Zahlungsdaten benötigt.
      </p>

      <h2>§ 5 Vertragsschluss</h2>
      <p>
        Die Darstellung der Tarife auf der Website ist kein bindendes Angebot. Ein Vertrag über
        einen kostenpflichtigen Tarif kommt zustande, wenn der Kunde den Tarif bucht und der
        Anbieter die Buchung bestätigt oder mit der Leistung beginnt.
      </p>

      <h2>§ 6 Preise und Zahlung</h2>
      <p>
        Es gelten die zum Zeitpunkt der Buchung auf der Website angegebenen Preise, zuzüglich
        gegebenenfalls anfallender gesetzlicher Umsatzsteuer. Die Vergütung ist monatlich im Voraus
        fällig. Die Zahlung erfolgt über den bei der Buchung angebotenen Zahlungsdienst.
      </p>

      <h2>§ 7 Laufzeit und Kündigung</h2>
      <p>
        Kostenpflichtige Tarife laufen jeweils einen Monat und verlängern sich automatisch um einen
        weiteren Monat, wenn sie nicht gekündigt werden. Beide Seiten können jederzeit zum Ende des
        laufenden Abrechnungsmonats kündigen. Eine Kündigung in Textform (z. B. per E-Mail an{' '}
        {legal.email}) genügt. Das Recht zur außerordentlichen Kündigung aus wichtigem Grund bleibt
        unberührt.
      </p>

      <h2>§ 8 Pflichten des Kunden</h2>
      <p>
        Der Kunde benennt nur Seiten, deren Beobachtung zulässig ist, hält seine Zugangsdaten geheim
        und nutzt die Berichte nicht für rechtswidrige Zwecke. Die Weitergabe des Zugangs an Dritte
        außerhalb des eigenen Unternehmens ist nicht gestattet.
      </p>

      <h2>§ 9 Verfügbarkeit</h2>
      <p>
        Der Anbieter bemüht sich um eine hohe Verfügbarkeit des Dienstes. Wartungsarbeiten und
        Störungen, die außerhalb des Einflussbereichs des Anbieters liegen (z. B. beim
        Hosting-Anbieter), können zu Unterbrechungen führen.
      </p>

      <h2>§ 10 Haftung</h2>
      <p>
        Der Anbieter haftet unbeschränkt bei Vorsatz und grober Fahrlässigkeit, bei Verletzung von
        Leben, Körper oder Gesundheit sowie nach dem Produkthaftungsgesetz. Bei leicht fahrlässiger
        Verletzung wesentlicher Vertragspflichten ist die Haftung auf den vertragstypischen,
        vorhersehbaren Schaden begrenzt, höchstens auf die vom Kunden in den letzten zwölf Monaten
        gezahlte Vergütung. Im Übrigen ist die Haftung für leichte Fahrlässigkeit ausgeschlossen.
        Für Entscheidungen, die der Kunde auf Grundlage der Berichte trifft, haftet der Anbieter
        nicht, soweit die Berichte die öffentlich angezeigten Angaben korrekt wiedergeben.
      </p>

      <h2>§ 11 Daten</h2>
      <p>
        Informationen zur Verarbeitung personenbezogener Daten enthält die{' '}
        <Link href="/datenschutz">Datenschutzerklärung</Link>. Nach Vertragsende werden die Daten
        des Kunden gelöscht, soweit keine gesetzlichen Aufbewahrungspflichten bestehen.
      </p>

      <h2>§ 12 Änderungen der AGB</h2>
      <p>
        Der Anbieter kann diese AGB mit Wirkung für die Zukunft ändern. Änderungen werden dem Kunden
        mindestens vier Wochen vorher in Textform mitgeteilt. Widerspricht der Kunde nicht innerhalb
        dieser Frist, gelten die Änderungen als angenommen; auf diese Folge wird in der Mitteilung
        hingewiesen. Bei Widerspruch kann jede Seite zum Wirksamwerden der Änderung kündigen.
      </p>

      <h2>§ 13 Schlussbestimmungen</h2>
      <p>
        Es gilt deutsches Recht unter Ausschluss des UN-Kaufrechts. Gerichtsstand für alle
        Streitigkeiten ist, soweit gesetzlich zulässig, der Sitz des Anbieters. Sollte eine
        Bestimmung unwirksam sein, bleibt die Wirksamkeit der übrigen Bestimmungen unberührt.
      </p>
      <p>Stand: Oktober 2026</p>
    </main>
  );
}
