import type { Metadata } from 'next';
import { legal } from '@/lib/wettkiesel-config';

export const metadata: Metadata = {
  title: 'Datenschutzerklärung',
  description:
    'Datenschutzerklärung von Wettkiesel: Hosting in Frankfurt, Datenbank, Cookies, Pilotformular und Benutzerkonto.',
  alternates: { canonical: '/datenschutz' },
};

export default function DatenschutzPage() {
  return (
    <main className="wk-legal">
      <h1>Datenschutzerklärung</h1>

      <h2>1. Verantwortlicher</h2>
      <p>
        {legal.name}, {legal.street}, {legal.city}, {legal.country}. E-Mail: {legal.email}
      </p>
      <p>
        Ein Datenschutzbeauftragter ist nicht bestellt, da die gesetzlichen Voraussetzungen dafür
        nicht vorliegen.
      </p>

      <h2>2. Hosting</h2>
      <p>
        Diese Website wird bei Render Services, Inc., 525 Brannan Street, Suite 300, San Francisco,
        CA 94107, USA gehostet. Die Server stehen in der Rechenzentrumsregion Frankfurt am Main
        (Deutschland). Beim Aufruf der Website verarbeitet der Server technisch notwendige Daten wie
        IP-Adresse, Datum und Uhrzeit, aufgerufene Seite, übertragene Datenmenge, Referrer und
        Browserangaben in Server-Logfiles. Das ist nötig, um die Website sicher und stabil
        auszuliefern (Art. 6 Abs. 1 lit. f DSGVO). Mit Render besteht ein Vertrag zur
        Auftragsverarbeitung. Da Render ein Unternehmen mit Sitz in den USA ist, kann ein Zugriff
        aus den USA nicht ausgeschlossen werden; Render stützt Übermittlungen auf die
        EU-Standardvertragsklauseln und, soweit zertifiziert, auf das EU-U.S. Data Privacy
        Framework.
      </p>

      <h2>3. Datenbank</h2>
      <p>
        Formular- und Kontodaten werden in einer PostgreSQL-Datenbank gespeichert, die ebenfalls von
        Render in der Region Frankfurt am Main betrieben wird. Es gelten die Angaben unter Punkt 2.
      </p>

      <h2>4. Cookies</h2>
      <p>
        Wettkiesel setzt nur technisch notwendige Cookies. Wenn du dich anmeldest, speichert das
        Anmeldesystem (better-auth) ein Sitzungs-Cookie (z. B. „better-auth.session_token“), damit
        du angemeldet bleibst. Es enthält eine zufällige Sitzungskennung und wird beim Abmelden bzw.
        nach Ablauf der Sitzung ungültig. Rechtsgrundlage ist § 25 Abs. 2 Nr. 2 TDDDG sowie Art. 6
        Abs. 1 lit. b DSGVO. Cookies zu Werbe- oder Analysezwecken setzen wir nicht.
      </p>

      <h2>5. Pilot- und Kontaktformular</h2>
      <p>
        Wenn du das Formular „Kostenlos testen“ nutzt, speichern wir Name, E-Mail-Adresse, Shop-URL,
        Shopsystem, optional genannte Wettbewerber-URLs, den gewählten Tarif und deine optionale
        Angabe zur Zahlungsbereitschaft. Wir nutzen diese Daten, um deine Anfrage zu bearbeiten,
        dich zu kontaktieren und den Test einzurichten (Art. 6 Abs. 1 lit. b DSGVO). Die Daten
        werden gelöscht, wenn sie dafür nicht mehr nötig sind, spätestens 12 Monate nach dem letzten
        Kontakt, sofern kein Vertrag zustande kommt und keine gesetzlichen Aufbewahrungspflichten
        bestehen.
      </p>

      <h2>6. Benutzerkonto</h2>
      <p>
        Für ein Konto speichern wir Name, E-Mail-Adresse, ein verschlüsselt (gehasht) gespeichertes
        Passwort sowie Sitzungsdaten wie Zeitpunkt, IP-Adresse und Browserangaben der Anmeldung
        (Art. 6 Abs. 1 lit. b DSGVO). Außerdem speichern wir die Produkte und Wettbewerber-URLs, die
        du anlegst. Die Daten werden gelöscht, wenn du dein Konto löschen lässt oder der Vertrag
        endet, soweit keine Aufbewahrungspflichten bestehen.
      </p>

      <h2>7. Beobachtung öffentlicher Wettbewerberseiten</h2>
      <p>
        Wettkiesel ruft öffentlich zugängliche Produktseiten ab und speichert Preis, Verfügbarkeit,
        Quelle und Zeitpunkt. Dabei werden keine personenbezogenen Daten von Endkunden erhoben.
      </p>

      <h2>8. Kommunikation per E-Mail</h2>
      <p>
        Wenn du uns per E-Mail schreibst oder wir dir zu deiner Anfrage antworten, nutzen wir dafür
        Google Gmail (Google Ireland Limited, Gordon House, Barrow Street, Dublin 4, Irland). Dabei
        werden deine E-Mail-Adresse und der Inhalt der Nachricht verarbeitet (Art. 6 Abs. 1 lit. b
        bzw. f DSGVO).
      </p>

      <h2>9. Zahlungsabwicklung (geplant)</h2>
      <p>
        Für kostenpflichtige Tarife ist die Zahlungsabwicklung über Stripe (Stripe Payments Europe,
        Ltd., 1 Grand Canal Street Lower, Dublin 2, Irland) geplant. Derzeit ist sie noch nicht
        aktiv. Sobald sie aktiv ist, werden bei einer Buchung die für die Zahlung nötigen Daten (z.
        B. Name, E-Mail-Adresse, Zahlungsdaten) direkt an Stripe übermittelt (Art. 6 Abs. 1 lit. b
        DSGVO). Diese Erklärung wird dann entsprechend ergänzt.
      </p>

      <h2>10. Schriftarten und Analyse</h2>
      <p>
        Schriftarten werden von unserem eigenen Server geladen, nicht von Google oder anderen
        Drittanbietern. Analyse- oder Tracking-Tools setzen wir nicht ein.
      </p>

      <h2>11. Deine Rechte</h2>
      <ul>
        <li>Auskunft (Art. 15 DSGVO), Berichtigung (Art. 16), Löschung (Art. 17)</li>
        <li>Einschränkung der Verarbeitung (Art. 18) und Datenübertragbarkeit (Art. 20)</li>
        <li>Widerspruch gegen Verarbeitungen auf Grundlage berechtigter Interessen (Art. 21)</li>
        <li>
          Beschwerde bei einer Aufsichtsbehörde, z. B. beim Landesbeauftragten für den Datenschutz
          und die Informationsfreiheit Baden-Württemberg
        </li>
      </ul>
      <p>Anfragen bitte an: {legal.email}</p>
      <p>Stand: Oktober 2026</p>
    </main>
  );
}
