import type { Metadata } from 'next';
import Link from 'next/link';
import { legal } from '@/lib/wettkiesel-config';

export const metadata: Metadata = {
  title: 'Hinweis zum Widerrufsrecht',
  description:
    'Wettkiesel richtet sich ausschließlich an Unternehmer. Ein gesetzliches Widerrufsrecht für Verbraucher besteht daher nicht.',
  alternates: { canonical: '/widerruf' },
};

export default function WiderrufPage() {
  return (
    <main className="wk-legal">
      <h1>Hinweis zum Widerrufsrecht</h1>
      <p>
        Wettkiesel richtet sich ausschließlich an Unternehmer im Sinne des § 14 BGB, insbesondere an
        Betreiber von Onlineshops (siehe <Link href="/agb">AGB, § 2</Link>). Das gesetzliche
        Widerrufsrecht gilt nur für Verbraucher. Für Verträge über Wettkiesel besteht daher kein
        gesetzliches Widerrufsrecht.
      </p>
      <h2>Trotzdem flexibel</h2>
      <p>
        Der kostenlose 14-Tage-Test endet automatisch, ohne Kündigung und ohne Kosten.
        Kostenpflichtige Tarife sind monatlich kündbar, jeweils zum Ende des laufenden
        Abrechnungsmonats. Eine kurze E-Mail an {legal.email} genügt.
      </p>
    </main>
  );
}
