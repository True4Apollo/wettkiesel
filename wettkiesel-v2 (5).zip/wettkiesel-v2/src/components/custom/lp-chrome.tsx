import Link from 'next/link';
import { BrandMark } from '@/components/custom/brand-mark';

/** Heller Header im Design der Startseite – für alle öffentlichen Unterseiten. */
export function LpHeader() {
  return (
    <header className="lp-header">
      <div className="lp-container lp-header-inner">
        <Link href="/" className="lp-logo" aria-label="Wettkiesel – Startseite">
          <BrandMark small />
          <span>wettkiesel</span>
        </Link>
        <nav className="lp-nav" aria-label="Hauptnavigation">
          <Link href="/#vorteile">Vorteile</Link>
          <Link href="/#ablauf">Ablauf</Link>
          <Link href="/#preise">Preise</Link>
          <Link href="/beispielbericht">Beispielbericht</Link>
          <Link href="/faq">FAQ</Link>
        </nav>
        <div className="lp-header-actions">
          <Link href="/login" className="lp-link">
            Login
          </Link>
          <Link href="/pilot" className="lp-btn lp-btn-primary lp-btn-sm">
            Kostenlos testen
          </Link>
        </div>
      </div>
    </header>
  );
}

export function LpFooter() {
  return (
    <footer className="lp-footer">
      <div className="lp-container lp-footer-inner">
        <div>
          <Link href="/" className="lp-logo">
            <BrandMark small />
            <span>wettkiesel</span>
          </Link>
          <p className="lp-muted">Preisüberwachung für kleine Onlineshops.</p>
        </div>
        <nav aria-label="Footer" className="lp-footer-links">
          <Link href="/pilot">Kostenlos testen</Link>
          <Link href="/beispielbericht">Beispielbericht</Link>
          <Link href="/faq">FAQ</Link>
          <Link href="/impressum">Impressum</Link>
          <Link href="/datenschutz">Datenschutz</Link>
          <Link href="/agb">AGB</Link>
          <Link href="/widerruf">Widerruf</Link>
        </nav>
      </div>
    </footer>
  );
}
