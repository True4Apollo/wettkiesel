// @polsia:user-owned
// Shared contract for the admin-only view of pilot submissions.
import { z } from 'zod';

export const PilotRequest = z.object({
  id: z.string().min(1),
  name: z.string(),
  email: z.string(),
  createdAt: z.string().datetime(),
  willingness: z.string().nullable(),
  answers: z.string(),
});

export const Signup = z.object({
  id: z.string().min(1),
  name: z.string(),
  email: z.string(),
  emailVerified: z.boolean(),
  createdAt: z.string().datetime(),
});

export const PilotRequestList = z.object({
  items: z.array(PilotRequest),
  signups: z.array(Signup).default([]),
});

export type PilotRequest = z.infer<typeof PilotRequest>;
export type PilotRequestList = z.infer<typeof PilotRequestList>;
